import React, { useState } from 'react';
import { Upload, Trash2, FileText, Check, Loader2, AlertCircle, Download, LogOut } from 'lucide-react';
import type { AppState } from '../types';
import { cn } from '../lib/utils';
import { signOut } from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { useAuth } from '../hooks/useAuth';
import ThemeSettings from './ThemeSettings';
import UserSupportChat from './UserSupportChat';

interface SettingsSectionProps {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
}

export default function SettingsSection({ state, setState }: SettingsSectionProps) {
  const [isProcessingMenu, setIsProcessingMenu] = useState(false);
  const [isProcessingSchedule, setIsProcessingSchedule] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const adminEmails = [
    'desarrolohub@colegiolitterator.com', 
    'desarrollohub@colegiolitterator.com',
    'lcdfernando2017@gmail.com'
  ];
  const isAdmin = user?.email && adminEmails.includes(user.email.toLowerCase());

  const handleFileUpload = async (type: 'menu' | 'schedule', e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (type === 'menu') setIsProcessingMenu(true);
    else setIsProcessingSchedule(true);
    setError(null);

    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64 = (event.target?.result as string).split(',')[1];
      
      try {
        const endpoint = type === 'menu' ? '/api/process-menu' : '/api/process-schedule';
        const response = await fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pdfBase64: base64 }),
        });

        const contentType = response.headers.get('content-type');
        
        if (!response.ok) {
          if (contentType && contentType.includes('application/json')) {
            const errorData = await response.json();
            throw new Error(errorData.error || `Error ${response.status}: El servidor no pudo procesar el archivo.`);
          } else {
            const text = await response.text();
            console.error('Server error (non-JSON):', text);
            throw new Error(`Error ${response.status}: El servidor devolvió un formato inesperado. Inténtalo de nuevo.`);
          }
        }

        if (!contentType || !contentType.includes('application/json')) {
          const text = await response.text();
          console.error('Unexpected response format:', text);
          throw new Error('El servidor no devolvió una respuesta válida. Por favor, refresca la página.');
        }

        const data = await response.json();
        
        // If admin and it's the menu, push to global shared resources
        if (isAdmin && type === 'menu') {
          try {
            await setDoc(doc(db, 'shared_resources', 'menu'), data);
            alert('Menú publicado masivamente a todos los usuarios.');
          } catch (e) {
            console.error('Error publicando el menú global:', e);
            setError('Error al publicar el menú globalmente.');
          }
        }

        setState(prev => ({
          ...prev,
          [type]: data
        }));
      } catch (err: any) {
        console.error(err);
        setError(err.message || 'Error al conectar con el servidor.');
      } finally {
        setIsProcessingMenu(false);
        setIsProcessingSchedule(false);
      }
    };
    reader.onerror = () => {
      setError('Error al leer el archivo.');
      setIsProcessingMenu(false);
      setIsProcessingSchedule(false);
    };
    reader.readAsDataURL(file);
  };

  const exportData = () => {
    const dataStr = JSON.stringify(state, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = 'litterator-hub-backup.json';
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const importData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const importedState = JSON.parse(event.target?.result as string);
        setState(importedState);
        alert('Datos importados correctamente.');
      } catch (err) {
        setError('El archivo no tiene un formato válido.');
      }
    };
    reader.readAsText(file);
  };

  const clearData = () => {
    if (window.confirm('¿Estás seguro de que quieres borrar todos los datos? Esta acción no se puede deshacer.')) {
      const newState: AppState = {
        menu: null,
        schedule: null,
        assignments: [],
        grades: []
      };
      setState(newState);
      localStorage.removeItem('litterator-hub-state');
    }
  };

  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-black text-slate-900 dark:text-white font-display">Ajustes</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1 text-sm">Configura tu centro de estudios, personalización y sube tus horarios.</p>
        </div>
        <button 
          onClick={() => signOut(auth)}
          className="flex items-center gap-2 px-5 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 font-bold rounded-2xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-all text-sm shadow-sm"
        >
          <LogOut className="w-5 h-5 text-red-500" />
          <span>Cerrar sesión</span>
        </button>
      </header>

      {error && (
        <div className="bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 p-4 rounded-2xl flex items-center gap-3 text-red-600 dark:text-red-300">
          <AlertCircle className="w-5 h-5" />
          <p className="text-sm font-medium">{error}</p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Menu Upload */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-orange-50 dark:bg-orange-950/40 text-orange-600 rounded-2xl">
              <Upload className="w-6 h-6" />
            </div>
            <h2 className="font-bold text-xl text-slate-800 dark:text-white">Menú Comedor</h2>
          </div>

          <div className="p-8 border-2 border-dashed border-slate-100 dark:border-slate-800 rounded-2xl flex flex-col items-center justify-center text-center">
            {isProcessingMenu ? (
              <div className="flex flex-col items-center gap-3">
                <Loader2 className="w-10 h-10 text-indigo-500 animate-spin" />
                <p className="text-sm font-medium text-slate-600 dark:text-slate-300">Procesando con IA...</p>
              </div>
            ) : state.menu ? (
              <div className="flex flex-col items-center gap-3">
                <div className="w-12 h-12 bg-green-50 dark:bg-green-950/40 text-green-600 rounded-full flex items-center justify-center">
                  <Check className="w-6 h-6" />
                </div>
                <p className="text-sm font-bold text-slate-800 dark:text-slate-200">Menú de {state.menu.month} cargado</p>
                <label className="cursor-pointer text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline">
                  Actualizar PDF
                  <input type="file" accept="application/pdf" className="hidden" onChange={(e) => handleFileUpload('menu', e)} />
                </label>
              </div>
            ) : (
              <label className="cursor-pointer group flex flex-col items-center gap-3">
                <FileText className="w-12 h-12 text-slate-200 dark:text-slate-700 group-hover:text-indigo-300 transition-colors" />
                <p className="text-sm font-medium text-slate-500 dark:text-slate-400">{isAdmin ? 'Subida masiva de PDFs' : 'Sube el PDF del menú mensual'}</p>
                <span className="bg-indigo-600 text-white px-6 py-2 rounded-xl text-sm font-bold group-hover:bg-indigo-700 transition-colors">Seleccionar</span>
                <input type="file" accept="application/pdf" className="hidden" onChange={(e) => handleFileUpload('menu', e)} />
              </label>
            )}
          </div>
        </div>

        {/* Schedule Upload */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 rounded-2xl">
              <Upload className="w-6 h-6" />
            </div>
            <h2 className="font-bold text-xl text-slate-800 dark:text-white">Horario Clases</h2>
          </div>

          <div className="p-8 border-2 border-dashed border-slate-100 dark:border-slate-800 rounded-2xl flex flex-col items-center justify-center text-center">
            {isProcessingSchedule ? (
              <div className="flex flex-col items-center gap-3">
                <Loader2 className="w-10 h-10 text-indigo-500 animate-spin" />
                <p className="text-sm font-medium text-slate-600 dark:text-slate-300">Procesando con IA...</p>
              </div>
            ) : state.schedule ? (
              <div className="flex flex-col items-center gap-3">
                <div className="w-12 h-12 bg-green-50 dark:bg-green-950/40 text-green-600 rounded-full flex items-center justify-center">
                  <Check className="w-6 h-6" />
                </div>
                <p className="text-sm font-bold text-slate-800 dark:text-slate-200">Horario escolar cargado</p>
                <label className="cursor-pointer text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline">
                  Actualizar PDF
                  <input type="file" accept="application/pdf" className="hidden" onChange={(e) => handleFileUpload('schedule', e)} />
                </label>
              </div>
            ) : (
              <label className="cursor-pointer group flex flex-col items-center gap-3">
                <FileText className="w-12 h-12 text-slate-200 dark:text-slate-700 group-hover:text-indigo-300 transition-colors" />
                <p className="text-sm font-medium text-slate-500 dark:text-slate-400">Sube el PDF de tu horario semanal</p>
                <span className="bg-indigo-600 text-white px-6 py-2 rounded-xl text-sm font-bold group-hover:bg-indigo-700 transition-colors">Seleccionar</span>
                <input type="file" accept="application/pdf" className="hidden" onChange={(e) => handleFileUpload('schedule', e)} />
              </label>
            )}
          </div>
        </div>

        {/* Import/Export Section */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 rounded-2xl">
              <Download className="w-6 h-6" />
            </div>
            <h2 className="font-bold text-xl text-slate-800 dark:text-white">Copia de Seguridad</h2>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={exportData}
              className="flex flex-col items-center gap-2 p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-750 transition-all border border-slate-100 dark:border-slate-700 group"
            >
              <Download className="w-6 h-6 text-indigo-600 group-hover:scale-110 transition-transform" />
              <span className="text-xs font-bold text-slate-600 dark:text-slate-300">Exportar Datos</span>
            </button>
            
            <label className="flex flex-col items-center gap-2 p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-750 transition-all border border-slate-100 dark:border-slate-700 group cursor-pointer">
              <Upload className="w-6 h-6 text-indigo-600 group-hover:scale-110 transition-transform" />
              <span className="text-xs font-bold text-slate-600 dark:text-slate-300">Importar Datos</span>
              <input type="file" accept=".json" className="hidden" onChange={importData} />
            </label>
          </div>
        </div>

        {/* Clear Data Section */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-red-100 dark:border-red-950/50 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-800 dark:text-white">Borrar todos los datos</h3>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">Elimina todo el contenido guardado localmente.</p>
            </div>
            <button
              onClick={clearData}
              className="p-3 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-2xl transition-all"
            >
              <Trash2 className="w-6 h-6" />
            </button>
          </div>
        </div>
        
        <ThemeSettings state={state} setState={setState} />
        {!isAdmin && <UserSupportChat />}
      </div>
    </div>
  );
}
