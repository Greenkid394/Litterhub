import React, { useMemo, useState, useEffect } from 'react';
import { 
  Utensils, 
  Calendar, 
  BookOpen, 
  Clock, 
  ChevronRight, 
  Megaphone, 
  CloudSun, 
  Sparkles, 
  CalendarDays,
  Thermometer,
  Droplets,
  Wind,
  CheckCircle2,
  X,
  Hourglass
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import type { AppState, SchoolAnnouncement } from '../types';
import { db } from '../lib/firebase';
import { doc, onSnapshot } from 'firebase/firestore';
import { getWeatherInfo } from './WeatherSection';

interface DashboardProps {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
  onNavigate?: (tab: any) => void;
}

export default function Dashboard({ state, setState, onNavigate }: DashboardProps) {
  const today = new Date();
  const dayOfMonth = today.getDate();
  const dayOfWeek = today.getDay(); // 0 is Sunday, 1 is Monday...

  const [announcement, setAnnouncement] = useState<SchoolAnnouncement | null>(null);
  const [timeTick, setTimeTick] = useState(Date.now());
  
  // Weather state for quick dashboard card
  const [weather, setWeather] = useState<{
    city: string;
    temp: number;
    weatherCode: number;
    isDay: boolean;
    humidity: number;
    windSpeed: number;
  } | null>(null);

  // Live timer tick every 30s to update class status and countdown
  useEffect(() => {
    const interval = setInterval(() => setTimeTick(Date.now()), 30000);
    return () => clearInterval(interval);
  }, []);

  // Fetch announcement
  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'shared_resources', 'announcement'), (snap) => {
      if (snap.exists()) {
        const data = snap.data() as SchoolAnnouncement;
        if (data.active) {
          setAnnouncement(data);
        } else {
          setAnnouncement(null);
        }
      } else {
        setAnnouncement(null);
      }
    });
    return () => unsub();
  }, []);

  // Check persistent dismissal of announcement
  const announcementKey = useMemo(() => {
    if (!announcement) return '';
    return announcement.id || `${announcement.title}_${announcement.date}`;
  }, [announcement]);

  const isAnnouncementDismissed = useMemo(() => {
    if (!announcement || !announcementKey) return true;
    try {
      const stored = localStorage.getItem('litterator_dismissed_announcements');
      const localList: string[] = stored ? JSON.parse(stored) : [];
      const stateList = state.dismissedAnnouncementIds || [];
      return localList.includes(announcementKey) || stateList.includes(announcementKey);
    } catch {
      return false;
    }
  }, [announcement, announcementKey, state.dismissedAnnouncementIds]);

  const handleDismissAnnouncement = () => {
    if (!announcementKey) return;
    try {
      const stored = localStorage.getItem('litterator_dismissed_announcements');
      const localList: string[] = stored ? JSON.parse(stored) : [];
      if (!localList.includes(announcementKey)) {
        localList.push(announcementKey);
        localStorage.setItem('litterator_dismissed_announcements', JSON.stringify(localList));
      }
    } catch (e) {
      console.warn('LocalStorage note:', e);
    }

    setState(prev => ({
      ...prev,
      dismissedAnnouncementIds: Array.from(new Set([...(prev.dismissedAnnouncementIds || []), announcementKey]))
    }));
  };

  // Weather fetch
  useEffect(() => {
    const fetchWeather = async () => {
      try {
        const res = await fetch(
          'https://api.open-meteo.com/v1/forecast?latitude=40.0333&longitude=-3.6028&current=temperature_2m,relative_humidity_2m,is_day,weather_code,wind_speed_10m&timezone=Europe%2FMadrid'
        );
        if (res.ok) {
          const data = await res.json();
          setWeather({
            city: 'Aranjuez (Colegio Litterator)',
            temp: Math.round(data.current.temperature_2m),
            weatherCode: data.current.weather_code,
            isDay: data.current.is_day === 1,
            humidity: data.current.relative_humidity_2m,
            windSpeed: Math.round(data.current.wind_speed_10m)
          });
        }
      } catch (e) {
        console.warn('Weather fetch error:', e);
      }
    };
    fetchWeather();
  }, []);

  // Today's Menu
  const todayMenu = useMemo(() => {
    if (!state.menu) return null;
    return state.menu.items.find(item => item.day === dayOfMonth);
  }, [state.menu, dayOfMonth]);

  // Current & Next Class Calculation
  const currentAndNextClass = useMemo(() => {
    if (!state.schedule) return { current: null, next: null };
    const daySchedule = state.schedule.days.find(d => d.dayOfWeek === dayOfWeek);
    if (!daySchedule) return { current: null, next: null };

    const now = new Date();
    const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    let current = null;
    let next = null;

    for (const c of daySchedule.classes) {
      if (currentTime >= c.startTime && currentTime <= c.endTime) {
        current = c;
      } else if (currentTime < c.startTime && !next) {
        next = c;
      }
    }

    return { current, next };
  }, [state.schedule, dayOfWeek, timeTick]);

  // NEW FEATURE FOR NORMAL USERS: Live Real-Time Class Status and Countdown
  const liveClassStatus = useMemo(() => {
    if (!state.schedule?.days || state.schedule.days.length === 0) {
      return {
        type: 'no_schedule',
        badge: 'Sin Horario',
        title: 'Horario escolar no asignado aún',
        subtitle: 'Configura o solicita tu horario para ver tus clases en tiempo real.',
        actionLabel: 'Subir horario'
      };
    }

    // Weekend check
    if (dayOfWeek === 0 || dayOfWeek === 6) {
      return {
        type: 'weekend',
        badge: 'Fin de Semana',
        title: '🎉 ¡Fin de semana!',
        subtitle: 'No hay clases programadas para hoy. Próxima jornada el lunes a las 08:30h.',
        actionLabel: 'Ver semana'
      };
    }

    const daySchedule = state.schedule.days.find(d => d.dayOfWeek === dayOfWeek);
    if (!daySchedule || !daySchedule.classes || daySchedule.classes.length === 0) {
      return {
        type: 'free_day',
        badge: 'Día Libre',
        title: 'Hoy no tienes clases lectivas',
        subtitle: 'Disfruta de la jornada o aprovecha para adelantar tareas.',
        actionLabel: 'Ver horario'
      };
    }

    const now = new Date();
    const currentMinutes = now.getHours() * 60 + now.getMinutes();

    const parsedClasses = daySchedule.classes.map(c => {
      const [sh, sm] = c.startTime.split(':').map(Number);
      const [eh, em] = c.endTime.split(':').map(Number);
      return {
        ...c,
        startMin: (sh || 0) * 60 + (sm || 0),
        endMin: (eh || 0) * 60 + (em || 0),
      };
    }).sort((a, b) => a.startMin - b.startMin);

    const activeClass = parsedClasses.find(c => currentMinutes >= c.startMin && currentMinutes < c.endMin);

    if (activeClass) {
      const remainingMin = activeClass.endMin - currentMinutes;
      const totalDuration = Math.max(1, activeClass.endMin - activeClass.startMin);
      const progress = Math.min(100, Math.max(0, Math.round(((currentMinutes - activeClass.startMin) / totalDuration) * 100)));
      return {
        type: 'in_class',
        badge: 'En Clase Ahora',
        title: activeClass.subject,
        room: activeClass.room || 'Aula asignada',
        timeRange: `${activeClass.startTime} - ${activeClass.endTime}`,
        remainingMin,
        progress,
        subtitle: `Quedan ${remainingMin} minutos de sesión (termina a las ${activeClass.endTime})`,
        actionLabel: 'Ver horario'
      };
    }

    // Between classes or before school
    const upcomingClass = parsedClasses.find(c => currentMinutes < c.startMin);
    if (upcomingClass) {
      const minutesUntil = upcomingClass.startMin - currentMinutes;
      const isRecess = currentMinutes >= parsedClasses[0].startMin;
      return {
        type: isRecess ? 'recess' : 'before_school',
        badge: isRecess ? 'Recreo / Descanso' : 'Antes de Empezar',
        title: isRecess ? '🥪 Tiempo de Recreo Escolar' : `⏰ Próxima: ${upcomingClass.subject}`,
        room: upcomingClass.room || 'Aula asignada',
        timeRange: `Inicio: ${upcomingClass.startTime}`,
        minutesUntil,
        subtitle: isRecess 
          ? `Siguiente clase (${upcomingClass.subject}) empieza a las ${upcomingClass.startTime} (en ${minutesUntil} min)`
          : `Tu jornada comienza a las ${upcomingClass.startTime} (en ${minutesUntil} minutos)`,
        actionLabel: 'Ver horario'
      };
    }

    // After school finished
    return {
      type: 'finished',
      badge: 'Jornada Finalizada',
      title: '✨ ¡Clases de hoy finalizadas!',
      subtitle: 'Has completado todas tus sesiones de hoy. ¡Buen descanso y hasta mañana!',
      actionLabel: 'Ver horario'
    };
  }, [state.schedule, dayOfWeek, timeTick]);

  // Upcoming Assignments
  const upcomingAssignments = useMemo(() => {
    return state.assignments
      .filter(a => !a.completed)
      .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
      .slice(0, 3);
  }, [state.assignments]);

  const greeting = useMemo(() => {
    const hour = today.getHours();
    if (hour < 12) return "¡Buenos días!";
    if (hour < 20) return "¡Buenas tardes!";
    return "¡Buenas noches!";
  }, [today]);

  const weatherInfo = weather ? getWeatherInfo(weather.weatherCode, weather.isDay) : null;
  const WeatherIcon = weatherInfo ? weatherInfo.icon : CloudSun;

  return (
    <div className="space-y-6 md:space-y-8 pb-10">
      {/* 1. DISCREET, SUBTLE OFFICIAL SCHOOL ANNOUNCEMENT (Not screaming, non-distracting) */}
      {announcement && !isAnnouncementDismissed && (
        <motion.div
          initial={{ opacity: 0, y: -6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -6 }}
          className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 rounded-2xl p-4 shadow-sm flex items-center justify-between gap-4 transition-all"
        >
          <div className="flex items-center gap-3.5 min-w-0">
            <span className={cn(
              "w-2.5 h-2.5 rounded-full flex-shrink-0",
              announcement.priority === 'alert' 
                ? "bg-rose-500 animate-pulse" 
                : announcement.priority === 'important' 
                ? "bg-amber-500" 
                : "bg-indigo-500"
            )} />
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  Aviso Oficial • {announcement.date}
                </span>
                {announcement.priority === 'alert' && (
                  <span className="px-1.5 py-0.2 text-[9px] font-black uppercase bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 rounded">
                    Urgente
                  </span>
                )}
              </div>
              <p className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate mt-0.5">
                {announcement.title}
                <span className="font-normal text-slate-500 dark:text-slate-400 ml-2">
                  — {announcement.message}
                </span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            {onNavigate && (
              <button
                type="button"
                onClick={() => onNavigate('announcements')}
                className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline px-2 py-1"
              >
                Ver más
              </button>
            )}
            <button
              type="button"
              onClick={handleDismissAnnouncement}
              className="text-xs text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 px-2.5 py-1 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center gap-1"
              title="Cerrar aviso y no volver a mostrar"
            >
              <span>Entendido</span>
              <X className="w-3 h-3" />
            </button>
          </div>
        </motion.div>
      )}

      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl md:text-4xl font-black text-slate-900 dark:text-white tracking-tight font-display">
            {greeting} 👋
          </h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1.5 text-base md:text-lg font-medium">
            Resumen diario escolar en el Colegio Litterator.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="flex items-center gap-3 bg-white dark:bg-slate-900 px-5 py-3 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800">
            <Calendar className="w-5 h-5 text-indigo-500" />
            <span className="font-bold text-slate-700 dark:text-slate-300 capitalize text-sm">
              {new Date().toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' })}
            </span>
          </div>
        </div>
      </header>

      {/* 2. LIVE REAL-TIME CLASS STATUS BANNER (1 more feature for normal users) */}
      <div className="bg-gradient-to-br from-indigo-600 via-indigo-700 to-slate-900 rounded-[28px] p-5 md:p-6 text-white shadow-xl shadow-indigo-500/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -mr-20 -mt-20 blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-widest bg-white/20 text-white backdrop-blur-md">
                {liveClassStatus.badge}
              </span>
              {liveClassStatus.type === 'in_class' && (
                <span className="flex items-center gap-1 text-[11px] text-indigo-200 font-bold">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  En curso
                </span>
              )}
            </div>

            <div>
              <h2 className="text-2xl md:text-3xl font-black font-display tracking-tight">
                {liveClassStatus.title}
              </h2>
              <p className="text-sm text-indigo-100/90 font-medium mt-1">
                {liveClassStatus.subtitle}
              </p>
            </div>

            {/* In-class progress bar */}
            {liveClassStatus.type === 'in_class' && typeof liveClassStatus.progress === 'number' && (
              <div className="pt-2 max-w-md">
                <div className="flex justify-between text-[11px] font-mono text-indigo-200 mb-1">
                  <span>{liveClassStatus.timeRange}</span>
                  <span className="font-bold">{liveClassStatus.progress}% completado</span>
                </div>
                <div className="w-full h-2 bg-white/20 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-emerald-400 rounded-full transition-all duration-500" 
                    style={{ width: `${liveClassStatus.progress}%` }} 
                  />
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center gap-3">
            {onNavigate && (
              <button
                type="button"
                onClick={() => onNavigate('schedule')}
                className="px-4 py-2.5 bg-white/15 hover:bg-white/25 backdrop-blur-md text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shadow-sm"
              >
                <span>{liveClassStatus.actionLabel}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Quick Weather Banner Card */}
      {weather && weatherInfo && (
        <div 
          onClick={() => onNavigate && onNavigate('weather')}
          className="cursor-pointer bg-gradient-to-r from-sky-500 via-indigo-600 to-indigo-700 p-5 md:p-6 rounded-[28px] text-white shadow-lg shadow-indigo-500/15 flex flex-col sm:flex-row sm:items-center justify-between gap-4 group transition-all hover:scale-[1.005]"
        >
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-md flex items-center justify-center flex-shrink-0 group-hover:rotate-6 transition-transform">
              <WeatherIcon className="w-8 h-8 text-white drop-shadow-sm" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl md:text-3xl font-black font-display tracking-tight">{weather.temp}°C</span>
                <span className="text-sm font-bold text-sky-100">• {weatherInfo.label}</span>
              </div>
              <p className="text-xs text-sky-100/90 font-medium mt-0.5">
                {weather.city}: {weatherInfo.advice}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 self-end sm:self-center">
            <div className="flex items-center gap-3 text-xs text-sky-100 font-medium">
              <span className="flex items-center gap-1">
                <Droplets className="w-3.5 h-3.5 text-sky-200" /> {weather.humidity}%
              </span>
              <span className="flex items-center gap-1">
                <Wind className="w-3.5 h-3.5 text-sky-200" /> {weather.windSpeed} km/h
              </span>
            </div>
            <span className="text-xs font-bold bg-white/20 hover:bg-white/30 px-3 py-1.5 rounded-xl transition-colors flex items-center gap-1">
              Pronóstico <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Schedule & Menu */}
        <div className="lg:col-span-2 space-y-8">
          {/* Dashboard Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div 
              onClick={() => onNavigate && onNavigate('agenda')}
              className="cursor-pointer bg-white dark:bg-slate-900 p-5 rounded-[24px] border border-slate-100 dark:border-slate-800 shadow-sm flex flex-col items-center text-center hover:border-indigo-200 dark:hover:border-indigo-800 transition-colors"
            >
              <span className="text-3xl font-black text-rose-600 dark:text-rose-400 font-display">
                {upcomingAssignments.filter(a => a.type === 'examen').length}
              </span>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Exámenes</span>
            </div>

            <div 
              onClick={() => onNavigate && onNavigate('agenda')}
              className="cursor-pointer bg-white dark:bg-slate-900 p-5 rounded-[24px] border border-slate-100 dark:border-slate-800 shadow-sm flex flex-col items-center text-center hover:border-indigo-200 dark:hover:border-indigo-800 transition-colors"
            >
              <span className="text-3xl font-black text-indigo-600 dark:text-indigo-400 font-display">
                {upcomingAssignments.length}
              </span>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Tareas Pendientes</span>
            </div>

            <div 
              onClick={() => onNavigate && onNavigate('menu')}
              className="cursor-pointer bg-white dark:bg-slate-900 p-5 rounded-[24px] border border-slate-100 dark:border-slate-800 shadow-sm flex flex-col items-center text-center hover:border-indigo-200 dark:hover:border-indigo-800 transition-colors"
            >
              <span className="text-3xl font-black text-emerald-600 dark:text-emerald-400 font-display">
                {state.menu ? 'Listo' : 'Pendiente'}
              </span>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Menú Escolar</span>
            </div>

            <div 
              onClick={() => onNavigate && onNavigate('schedule')}
              className="cursor-pointer bg-white dark:bg-slate-900 p-5 rounded-[24px] border border-slate-100 dark:border-slate-800 shadow-sm flex flex-col items-center text-center hover:border-indigo-200 dark:hover:border-indigo-800 transition-colors"
            >
              <span className="text-3xl font-black text-amber-600 dark:text-amber-400 font-display">
                {state.schedule ? 'Cargado' : 'Sin subir'}
              </span>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Horario</span>
            </div>
          </div>

          {/* Quick Schedule */}
          <section className="bg-white dark:bg-slate-900 rounded-[32px] p-6 md:p-8 border border-slate-100 dark:border-slate-800 shadow-xl shadow-slate-200/40 dark:shadow-none relative overflow-hidden transition-colors">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 rounded-2xl">
                  <Calendar className="w-6 h-6" />
                </div>
                <h2 className="text-2xl font-bold text-slate-800 dark:text-white font-display">Sesiones de Hoy</h2>
              </div>
              {onNavigate && (
                <button
                  onClick={() => onNavigate('schedule')}
                  className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 flex items-center gap-1"
                >
                  Ver horario completo <ChevronRight className="w-4 h-4" />
                </button>
              )}
            </div>

            {currentAndNextClass.current ? (
              <div className="space-y-6">
                <div className="bg-indigo-600 rounded-3xl p-6 md:p-8 text-white shadow-lg shadow-indigo-200 dark:shadow-none relative overflow-hidden group">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-3xl transition-transform group-hover:scale-110" />
                  <div className="relative z-10">
                    <span className="text-indigo-100 font-bold text-xs uppercase tracking-widest">Ahora mismo</span>
                    <h3 className="text-3xl md:text-4xl font-black mt-2 mb-4 tracking-tight font-display">{currentAndNextClass.current.subject}</h3>
                    <div className="flex flex-wrap items-center gap-4 text-indigo-100 font-medium">
                      <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1 rounded-full text-xs">
                        <Clock className="w-3.5 h-3.5" />
                        <span>{currentAndNextClass.current.startTime} - {currentAndNextClass.current.endTime}</span>
                      </div>
                      {currentAndNextClass.current.room && (
                        <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1 rounded-full text-xs">
                          <BookOpen className="w-3.5 h-3.5" />
                          <span>Aula: {currentAndNextClass.current.room}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {currentAndNextClass.next && (
                  <div className="flex items-center gap-4 md:gap-6 p-5 md:p-6 rounded-3xl border-2 border-slate-50 dark:border-slate-800/80 hover:border-indigo-100 dark:hover:border-slate-700 transition-colors group bg-slate-50/50 dark:bg-slate-850">
                    <div className="flex flex-col items-center justify-center p-3.5 bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 rounded-2xl font-bold text-xs min-w-[90px] group-hover:bg-indigo-50 dark:group-hover:bg-indigo-950/40 group-hover:text-indigo-600 transition-colors shadow-sm">
                      <span>Próxima</span>
                      <span className="text-xs opacity-70 font-medium mt-0.5">{currentAndNextClass.next.startTime}</span>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg md:text-xl font-bold text-slate-800 dark:text-slate-100 font-display">{currentAndNextClass.next.subject}</h4>
                      <p className="text-slate-400 text-xs font-medium mt-1">Siguiente sesión lectiva</p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-slate-300 dark:text-slate-600" />
                  </div>
                )}
              </div>
            ) : (
              <div className="bg-slate-50 dark:bg-slate-800/50 rounded-3xl p-10 text-center border-2 border-dashed border-slate-200 dark:border-slate-700">
                <div className="w-14 h-14 bg-white dark:bg-slate-800 rounded-2xl flex items-center justify-center shadow-sm mx-auto mb-3 text-slate-300 dark:text-slate-500">
                  <Calendar className="w-7 h-7" />
                </div>
                <h3 className="text-slate-700 dark:text-slate-300 font-bold text-base">No hay clases en este momento</h3>
                <p className="text-slate-400 text-xs mt-1">Revisa tu horario completo para ver las sesiones de los próximos días.</p>
              </div>
            )}
          </section>

          {/* Today's Menu */}
          <section className="bg-white dark:bg-slate-900 rounded-[32px] p-6 md:p-8 border border-slate-100 dark:border-slate-800 shadow-xl shadow-slate-200/40 dark:shadow-none transition-colors">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 rounded-2xl">
                  <Utensils className="w-6 h-6" />
                </div>
                <h2 className="text-2xl font-bold text-slate-800 dark:text-white font-display">Menú de Hoy</h2>
              </div>
              {onNavigate && (
                <button
                  onClick={() => onNavigate('menu')}
                  className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 flex items-center gap-1"
                >
                  Ver menú mensual <ChevronRight className="w-4 h-4" />
                </button>
              )}
            </div>

            {todayMenu ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { label: 'Primer Plato', content: todayMenu.firstCourse, color: 'bg-emerald-50 dark:bg-emerald-950/30 text-emerald-800 dark:text-emerald-300 border border-emerald-100/60 dark:border-emerald-900/30' },
                  { label: 'Segundo Plato', content: todayMenu.secondCourse, color: 'bg-amber-50 dark:bg-amber-950/30 text-amber-800 dark:text-amber-300 border border-amber-100/60 dark:border-amber-900/30' },
                  { label: 'Postre', content: todayMenu.dessert, color: 'bg-rose-50 dark:bg-rose-950/30 text-rose-800 dark:text-rose-300 border border-rose-100/60 dark:border-rose-900/30' }
                ].map((item, idx) => (
                  <div key={idx} className={cn("p-5 md:p-6 rounded-3xl flex flex-col justify-between", item.color)}>
                    <span className="text-[10px] font-black uppercase tracking-[0.2em] opacity-70 mb-3">{item.label}</span>
                    <p className="font-bold text-base md:text-lg leading-snug">{item.content}</p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-slate-50 dark:bg-slate-800/50 rounded-3xl p-10 text-center border-2 border-dashed border-slate-200 dark:border-slate-700">
                <p className="text-slate-600 dark:text-slate-300 font-bold text-sm">Menú no disponible para hoy</p>
                <p className="text-xs text-slate-400 mt-1">El menú global mensual se sincroniza automáticamente desde dirección.</p>
              </div>
            )}
          </section>
        </div>

        {/* Right Column: Assignments & Agenda */}
        <div className="space-y-8">
          <section className="bg-slate-900 dark:bg-slate-950 rounded-[32px] p-6 md:p-8 text-white shadow-2xl shadow-slate-900/20 border border-slate-800 h-full">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-white/10 rounded-xl">
                  <CalendarDays className="w-5 h-5 text-indigo-300" />
                </div>
                <h2 className="text-xl font-bold font-display">Agenda y Tareas</h2>
              </div>
              {onNavigate && (
                <button
                  onClick={() => onNavigate('agenda')}
                  className="text-xs text-indigo-300 hover:text-white font-bold transition-colors"
                >
                  Abrir Agenda →
                </button>
              )}
            </div>

            <div className="space-y-3.5">
              {upcomingAssignments.map((task) => (
                <div key={task.id} className="p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-colors group">
                  <div className="flex justify-between items-start mb-1.5">
                    <span className={cn(
                      "text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded",
                      task.type === 'examen' ? 'bg-rose-500/20 text-rose-300' : 'bg-amber-500/20 text-amber-300'
                    )}>
                      {task.type === 'examen' ? 'Examen' : 'Trabajo'}
                    </span>
                    <span className="text-[10px] text-white/40 font-bold">
                      {new Date(task.dueDate.replace(/-/g, '/')).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })}
                    </span>
                  </div>
                  <h4 className="font-bold text-sm text-white group-hover:text-indigo-300 transition-colors">{task.title}</h4>
                  {task.description && <p className="text-xs text-white/50 mt-1 line-clamp-2">{task.description}</p>}
                </div>
              ))}
              
              {upcomingAssignments.length === 0 && (
                <div className="text-center py-12">
                  <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-3">
                    <BookOpen className="w-6 h-6 text-white/20" />
                  </div>
                  <p className="text-white/30 font-bold text-sm italic">¡Todo al día en la agenda!</p>
                </div>
              )}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
