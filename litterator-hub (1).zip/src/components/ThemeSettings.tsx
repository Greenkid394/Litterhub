import React, { useRef, useState } from 'react';
import { 
  Palette, 
  Image as ImageIcon, 
  Moon, 
  Sun, 
  Upload, 
  Trash2, 
  Sliders, 
  Check, 
  Sparkles,
  Eye
} from 'lucide-react';
import type { AppState } from '../types';
import { cn } from '../lib/utils';

interface ThemeSettingsProps {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
}

const PRESET_BACKGROUNDS = [
  {
    id: 'clean',
    name: 'Por defecto',
    url: '',
    preview: 'linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%)'
  },
  {
    id: 'litterator-campus',
    name: 'Colegio Litterator',
    url: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=1920&q=80',
    preview: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=300&q=60'
  },
  {
    id: 'library-focus',
    name: 'Biblioteca de Estudio',
    url: 'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=1920&q=80',
    preview: 'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=300&q=60'
  },
  {
    id: 'aurora-dark',
    name: 'Aurora Nocturna',
    url: 'https://images.unsplash.com/photo-1517411032315-54ef2cb783bb?auto=format&fit=crop&w=1920&q=80',
    preview: 'https://images.unsplash.com/photo-1517411032315-54ef2cb783bb?auto=format&fit=crop&w=300&q=60'
  },
  {
    id: 'geometry-modern',
    name: 'Minimal Geométrico',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1920&q=80',
    preview: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=300&q=60'
  }
];

export default function ThemeSettings({ state, setState }: ThemeSettingsProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  const isDark = Boolean(state.theme?.darkMode);
  const currentBgUrl = state.theme?.backgroundImageUrl || '';
  const currentBlur = state.theme?.bgBlur ?? 0;
  const currentOpacity = state.theme?.bgOpacity ?? 30;

  const updateTheme = (updates: Partial<NonNullable<AppState['theme']>>) => {
    setState(prev => {
      const newTheme = {
        ...(prev.theme || {}),
        ...updates
      };
      
      // Keep root class in sync immediately
      if (typeof updates.darkMode === 'boolean') {
        document.documentElement.classList.toggle('dark', updates.darkMode);
      }
      
      return {
        ...prev,
        theme: newTheme
      };
    });
  };

  const handleToggleDarkMode = () => {
    const nextDark = !isDark;
    updateTheme({ 
      darkMode: nextDark,
      // Default background color based on mode if no custom image
      backgroundColor: nextDark ? '#0b0f19' : '#f8fafc'
    });
  };

  // Upload own custom background image from disk
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check size limit: max 6MB to prevent localStorage overflow
    if (file.size > 6 * 1024 * 1024) {
      setUploadError('La imagen es demasiado pesada. Elige una menor a 6MB para un rendimiento óptimo.');
      return;
    }

    setUploadError(null);
    setIsUploading(true);

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        updateTheme({ 
          backgroundImageUrl: dataUrl,
          bgOpacity: state.theme?.bgOpacity ?? 35,
          bgBlur: state.theme?.bgBlur ?? 2
        });
      }
      setIsUploading(false);
    };

    reader.onerror = () => {
      setUploadError('Error al procesar la imagen seleccionada.');
      setIsUploading(false);
    };

    reader.readAsDataURL(file);
  };

  const removeBackgroundImage = () => {
    updateTheme({ 
      backgroundImageUrl: '',
      backgroundColor: isDark ? '#0b0f19' : '#f8fafc'
    });
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 p-6 md:p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-8 transition-colors">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-5">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-pink-50 dark:bg-pink-950/40 text-pink-600 dark:text-pink-400 rounded-2xl">
            <Palette className="w-6 h-6" />
          </div>
          <div>
            <h2 className="font-black text-xl text-slate-900 dark:text-white font-display">
              Apariencia y Fondos
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Personaliza el tema oscuro, colores y tus propias imágenes de fondo.
            </p>
          </div>
        </div>

        {/* Quick Dark Mode Pill */}
        <button
          type="button"
          onClick={handleToggleDarkMode}
          className={cn(
            "flex items-center gap-2.5 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all shadow-sm border",
            isDark 
              ? "bg-slate-800 border-slate-700 text-amber-300 hover:bg-slate-700" 
              : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200"
          )}
        >
          {isDark ? (
            <>
              <Moon className="w-4 h-4 fill-amber-300 text-amber-300" />
              <span>Modo Oscuro</span>
            </>
          ) : (
            <>
              <Sun className="w-4 h-4 text-amber-500" />
              <span>Modo Claro</span>
            </>
          )}
        </button>
      </div>

      {/* 1. MODO OSCURO / MODO CLARO SELECTION CARDS */}
      <div className="space-y-3">
        <label className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest block">
          Modo de Visualización
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button
            type="button"
            onClick={() => updateTheme({ darkMode: false, backgroundColor: '#f8fafc' })}
            className={cn(
              "p-4 rounded-2xl border text-left flex items-center justify-between transition-all group",
              !isDark
                ? "border-indigo-600 ring-2 ring-indigo-500/20 bg-indigo-50/40 dark:bg-slate-800"
                : "border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60 opacity-70 hover:opacity-100"
            )}
          >
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-amber-100 text-amber-600 rounded-xl">
                <Sun className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-900 dark:text-white">Modo Claro Escolar</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">Fondos limpios para el día a día</p>
              </div>
            </div>
            {!isDark && <Check className="w-5 h-5 text-indigo-600" />}
          </button>

          <button
            type="button"
            onClick={() => updateTheme({ darkMode: true, backgroundColor: '#0b0f19' })}
            className={cn(
              "p-4 rounded-2xl border text-left flex items-center justify-between transition-all group",
              isDark
                ? "border-indigo-500 ring-2 ring-indigo-500/20 bg-slate-800 text-white"
                : "border-slate-200 bg-white opacity-70 hover:opacity-100"
            )}
          >
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-indigo-950 text-indigo-400 rounded-xl">
                <Moon className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-900 dark:text-white">Modo Oscuro Litterator</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">Descanso visual y bajo brillo</p>
              </div>
            </div>
            {isDark && <Check className="w-5 h-5 text-indigo-400" />}
          </button>
        </div>
      </div>

      {/* 2. SUBIR IMAGEN PROPIA DE FONDO */}
      <div className="space-y-4 pt-2">
        <div className="flex items-center justify-between">
          <div>
            <label className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest block">
              Fondo Personalizado
            </label>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Sube una foto propia desde tu ordenador o móvil para aplicarla como fondo.
            </p>
          </div>
          {currentBgUrl && (
            <button
              type="button"
              onClick={removeBackgroundImage}
              className="flex items-center gap-1.5 text-xs font-bold text-rose-500 hover:text-rose-600 p-2 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-xl transition-all"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Quitar fondo</span>
            </button>
          )}
        </div>

        {uploadError && (
          <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 rounded-2xl text-xs text-rose-700 dark:text-rose-300 font-bold">
            {uploadError}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* File Upload Trigger */}
          <div
            onClick={() => fileInputRef.current?.click()}
            className={cn(
              "border-2 border-dashed rounded-3xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-all relative overflow-hidden group",
              currentBgUrl 
                ? "border-indigo-300 dark:border-indigo-800 bg-indigo-50/20 dark:bg-indigo-950/20" 
                : "border-slate-200 dark:border-slate-800 hover:border-indigo-400 hover:bg-slate-50 dark:hover:bg-slate-800/40"
            )}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleImageFileChange}
            />
            <div className="p-3.5 bg-indigo-50 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 rounded-2xl mb-3 group-hover:scale-110 transition-transform">
              <Upload className="w-6 h-6" />
            </div>
            <p className="text-sm font-bold text-slate-800 dark:text-slate-200">
              {isUploading ? 'Cargando imagen...' : 'Subir foto propia de fondo'}
            </p>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
              JPG, PNG o WebP desde tu dispositivo
            </p>
          </div>

          {/* Current Preview or URL input */}
          <div className="p-5 bg-slate-50 dark:bg-slate-800/60 rounded-3xl border border-slate-100 dark:border-slate-800 flex flex-col justify-between space-y-4">
            <div>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block mb-2">
                O introduce una URL de internet
              </span>
              <div className="flex gap-2">
                <input
                  type="url"
                  placeholder="https://ejemplo.com/fondo.jpg"
                  value={currentBgUrl.startsWith('data:') ? 'Imagen subida desde tu equipo' : currentBgUrl}
                  disabled={currentBgUrl.startsWith('data:')}
                  onChange={(e) => updateTheme({ backgroundImageUrl: e.target.value })}
                  className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
                {currentBgUrl && (
                  <button
                    onClick={removeBackgroundImage}
                    className="px-3 py-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold hover:bg-rose-100 hover:text-rose-600 transition-colors"
                  >
                    Quitar
                  </button>
                )}
              </div>
            </div>

            {currentBgUrl && (
              <div className="flex items-center gap-3 pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
                <div 
                  className="w-16 h-10 rounded-xl border border-white dark:border-slate-700 shadow-sm bg-cover bg-center flex-shrink-0"
                  style={{ backgroundImage: `url(${currentBgUrl})` }}
                />
                <div className="text-xs">
                  <p className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                    <span>Fondo activo</span>
                  </p>
                  <p className="text-slate-400 text-[10px]">Ajusta el desenfoque y contraste abajo</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Controles de Desenfoque y Capa Protectora para que el texto se lea siempre perfectamente */}
        {currentBgUrl && (
          <div className="p-5 bg-indigo-50/40 dark:bg-indigo-950/20 rounded-3xl border border-indigo-100 dark:border-indigo-900/40 space-y-4">
            <div className="flex items-center gap-2 text-indigo-900 dark:text-indigo-300">
              <Sliders className="w-4 h-4" />
              <h4 className="text-xs font-bold uppercase tracking-wider">
                Ajustes de Legibilidad del Fondo
              </h4>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Overlay Opacity */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-semibold text-slate-600 dark:text-slate-400">
                  <span>Capa Protectora de Contraste</span>
                  <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">{currentOpacity}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="80"
                  step="5"
                  value={currentOpacity}
                  onChange={(e) => updateTheme({ bgOpacity: Number(e.target.value) })}
                  className="w-full accent-indigo-600 cursor-pointer"
                />
                <p className="text-[10px] text-slate-400">Oscurece suavemente la foto para leer con total claridad.</p>
              </div>

              {/* Blur */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-semibold text-slate-600 dark:text-slate-400">
                  <span>Desenfoque Suave (Efecto Cristal)</span>
                  <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">{currentBlur}px</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="16"
                  step="2"
                  value={currentBlur}
                  onChange={(e) => updateTheme({ bgBlur: Number(e.target.value) })}
                  className="w-full accent-indigo-600 cursor-pointer"
                />
                <p className="text-[10px] text-slate-400">Evita que los detalles de la foto distraigan del contenido.</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 3. GALERÍA DE FONDOS PREDEFINIDOS */}
      <div className="space-y-3 pt-2">
        <label className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest block">
          Colección de Fondos Escolares
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {PRESET_BACKGROUNDS.map((preset) => {
            const isSelected = (!currentBgUrl && preset.url === '') || currentBgUrl === preset.url;
            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => {
                  if (preset.url) {
                    updateTheme({ 
                      backgroundImageUrl: preset.url,
                      bgOpacity: isDark ? 40 : 25,
                      bgBlur: 2
                    });
                  } else {
                    removeBackgroundImage();
                  }
                }}
                className={cn(
                  "flex flex-col text-left rounded-2xl overflow-hidden border p-1 transition-all group relative",
                  isSelected
                    ? "border-indigo-600 ring-2 ring-indigo-500/30 shadow-md"
                    : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700"
                )}
              >
                <div 
                  className="w-full h-16 rounded-xl bg-cover bg-center mb-2 relative overflow-hidden"
                  style={{
                    background: preset.preview.startsWith('http') ? `url(${preset.preview}) center/cover` : preset.preview
                  }}
                >
                  {isSelected && (
                    <div className="absolute inset-0 bg-indigo-600/40 backdrop-blur-[1px] flex items-center justify-center text-white">
                      <Check className="w-5 h-5 drop-shadow" />
                    </div>
                  )}
                </div>
                <span className="text-[11px] font-bold text-slate-800 dark:text-slate-200 px-1 truncate">
                  {preset.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 4. COLORES SÓLIDOS DE FONDO */}
      <div className="space-y-3 pt-2">
        <label className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest block">
          Colores Sólidos Clásicos
        </label>
        <div className="flex flex-wrap gap-2.5">
          {[
            { label: 'Blanco Nieve', color: '#f8fafc' },
            { label: 'Crema Cálido', color: '#fefce8' },
            { label: 'Menta Fresco', color: '#f0fdfa' },
            { label: 'Lavanda Suave', color: '#f5f3ff' },
            { label: 'Rosa Claro', color: '#fff1f2' },
            { label: 'Pizarra Oscura', color: '#1e293b' },
            { label: 'Noche Litterator', color: '#0b0f19' },
            { label: 'Gris Grafito', color: '#18181b' }
          ].map(item => {
            const isSelected = (!currentBgUrl && state.theme?.backgroundColor === item.color);
            return (
              <button
                key={item.color}
                type="button"
                onClick={() => updateTheme({ backgroundColor: item.color, backgroundImageUrl: '' })}
                className={cn(
                  "flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold border transition-all",
                  isSelected
                    ? "border-indigo-600 ring-2 ring-indigo-500/20 bg-indigo-50/30 dark:bg-indigo-950/40 text-indigo-900 dark:text-indigo-200"
                    : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-900"
                )}
              >
                <span 
                  className="w-4 h-4 rounded-full border border-black/10 dark:border-white/20 shadow-sm"
                  style={{ backgroundColor: item.color }}
                />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
