import React, { useState } from 'react';
import { Calculator } from 'lucide-react';

export default function CalculatorSection() {
  const [display, setDisplay] = useState('0');
  const [equation, setEquation] = useState('');

  const handlePress = (val: string) => {
    if (display === '0' && val !== '.') {
      setDisplay(val);
    } else {
      setDisplay(display + val);
    }
  };

  const calculate = () => {
    try {
      // safe eval alternative for simple calculator
      const res = new Function(`return ${display}`)();
      setEquation(display + ' =');
      setDisplay(String(res));
    } catch {
      setDisplay('Error');
    }
  };

  const clear = () => {
    setDisplay('0');
    setEquation('');
  };

  return (
    <div className="space-y-8 max-w-md mx-auto">
      <header className="flex items-center gap-3 mb-8">
        <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl">
          <Calculator className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Calculadora</h1>
        </div>
      </header>

      <div className="bg-slate-900 p-6 rounded-[32px] shadow-2xl">
        <div className="bg-slate-800 rounded-2xl p-4 mb-6 text-right min-h-[80px] sm:min-h-[100px] flex flex-col justify-end">
          <p className="text-slate-400 text-xs sm:text-sm h-6">{equation}</p>
          <p className="text-white text-3xl sm:text-4xl font-display tracking-wider truncate">{display}</p>
        </div>

        <div className="grid grid-cols-4 gap-2 sm:gap-3">
          {['C', '(', ')', '/'].map(btn => (
            <button key={btn} onClick={() => btn === 'C' ? clear() : handlePress(btn)} className="bg-indigo-500/20 text-indigo-300 p-3 sm:p-4 rounded-xl sm:rounded-2xl font-bold text-lg sm:text-xl hover:bg-indigo-500/30">
              {btn}
            </button>
          ))}
          {['7', '8', '9', '*'].map(btn => (
            <button key={btn} onClick={() => handlePress(btn)} className={`p-3 sm:p-4 rounded-xl sm:rounded-2xl font-bold text-lg sm:text-xl ${btn === '*' ? 'bg-indigo-500/20 text-indigo-300' : 'bg-slate-800 text-white hover:bg-slate-700'}`}>
              {btn === '*' ? '×' : btn}
            </button>
          ))}
          {['4', '5', '6', '-'].map(btn => (
            <button key={btn} onClick={() => handlePress(btn)} className={`p-3 sm:p-4 rounded-xl sm:rounded-2xl font-bold text-lg sm:text-xl ${btn === '-' ? 'bg-indigo-500/20 text-indigo-300' : 'bg-slate-800 text-white hover:bg-slate-700'}`}>
              {btn}
            </button>
          ))}
          {['1', '2', '3', '+'].map(btn => (
            <button key={btn} onClick={() => handlePress(btn)} className={`p-3 sm:p-4 rounded-xl sm:rounded-2xl font-bold text-lg sm:text-xl ${btn === '+' ? 'bg-indigo-500/20 text-indigo-300' : 'bg-slate-800 text-white hover:bg-slate-700'}`}>
              {btn}
            </button>
          ))}
          {['0', '.', '=', '%'].map(btn => (
            <button 
              key={btn} 
              onClick={() => btn === '=' ? calculate() : handlePress(btn)} 
              className={`p-3 sm:p-4 rounded-xl sm:rounded-2xl font-bold text-lg sm:text-xl ${btn === '=' ? 'bg-indigo-600 text-white hover:bg-indigo-700 col-span-2' : btn === '%' ? 'bg-indigo-500/20 text-indigo-300 hover:bg-indigo-500/30' : 'bg-slate-800 text-white hover:bg-slate-700'}`}
            >
              {btn}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
