import React, { useState, useEffect } from 'react';
import { 
  CloudSun, 
  Search, 
  MapPin, 
  Wind, 
  Droplets, 
  Thermometer, 
  CloudRain, 
  Sun, 
  Cloud, 
  CloudLightning, 
  Snowflake, 
  CloudFog,
  Sparkles,
  Compass
} from 'lucide-react';
import { cn } from '../lib/utils';

interface WeatherData {
  city: string;
  country: string;
  region?: string;
  temperature: number;
  apparentTemperature: number;
  humidity: number;
  windSpeed: number;
  precipitation: number;
  weatherCode: number;
  isDay: boolean;
  daily: {
    dates: string[];
    codes: number[];
    maxTemps: number[];
    minTemps: number[];
    rainProbabilities: number[];
  };
}

export const getWeatherInfo = (code: number, isDay: boolean = true) => {
  switch (code) {
    case 0:
      return { 
        label: isDay ? 'Despejado / Soleado' : 'Cielo despejado', 
        icon: isDay ? Sun : Sun, 
        color: 'text-amber-500', 
        bg: 'from-amber-400 to-orange-500',
        advice: '☀️ Día perfecto para el recreo y actividades al aire libre.'
      };
    case 1:
    case 2:
      return { 
        label: 'Parcialmente nublado', 
        icon: CloudSun, 
        color: 'text-sky-500', 
        bg: 'from-sky-400 to-indigo-500',
        advice: '⛅ Temperatura agradable para el patio escolar.'
      };
    case 3:
      return { 
        label: 'Nublado', 
        icon: Cloud, 
        color: 'text-slate-500', 
        bg: 'from-slate-400 to-slate-600',
        advice: '☁️ Cielo encapotado, ideal para concentrarse en clase.'
      };
    case 45:
    case 48:
      return { 
        label: 'Niebla', 
        icon: CloudFog, 
        color: 'text-slate-400', 
        bg: 'from-slate-300 to-slate-500',
        advice: '🌫️ Precaución en el trayecto al colegio si hay poca visibilidad.'
      };
    case 51:
    case 53:
    case 55:
    case 61:
    case 63:
    case 65:
    case 80:
    case 81:
    case 82:
      return { 
        label: 'Lluvia / Chubascos', 
        icon: CloudRain, 
        color: 'text-blue-500', 
        bg: 'from-blue-500 to-indigo-600',
        advice: '☔ No olvides meter el paraguas y chubasquero en la mochila.'
      };
    case 71:
    case 73:
    case 75:
    case 85:
    case 86:
      return { 
        label: 'Nieve', 
        icon: Snowflake, 
        color: 'text-cyan-400', 
        bg: 'from-cyan-400 to-blue-500',
        advice: '❄️ ¡Nieve! Mucho abrigo, gorro y calzado impermeable.'
      };
    case 95:
    case 96:
    case 99:
      return { 
        label: 'Tormenta eléctrica', 
        icon: CloudLightning, 
        color: 'text-purple-500', 
        bg: 'from-purple-600 to-indigo-800',
        advice: '⛈️ Tormenta: el recreo probablemente será en pabellón cubierto.'
      };
    default:
      return { 
        label: 'Variable', 
        icon: CloudSun, 
        color: 'text-indigo-500', 
        bg: 'from-indigo-400 to-slate-600',
        advice: 'Disfruta de la jornada escolar en el Litterator.'
      };
  }
};

export default function WeatherSection() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [loadingSearch, setLoadingSearch] = useState(false);
  const [loadingWeather, setLoadingWeather] = useState(false);
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [error, setError] = useState<string | null>(null);

  const popularCities = [
    { name: 'Aranjuez', admin1: 'Comunidad de Madrid', country: 'España', lat: 40.033, lon: -3.603, isColegio: true },
    { name: 'Madrid', admin1: 'Comunidad de Madrid', country: 'España', lat: 40.4168, lon: -3.7038 },
    { name: 'Toledo', admin1: 'Castilla-La Mancha', country: 'España', lat: 39.8581, lon: -4.0226 },
    { name: 'Barcelona', admin1: 'Cataluña', country: 'España', lat: 41.3851, lon: 2.1734 },
    { name: 'Valencia', admin1: 'Comunidad Valenciana', country: 'España', lat: 39.4699, lon: -0.3763 },
    { name: 'Sevilla', admin1: 'Andalucía', country: 'España', lat: 37.3891, lon: -5.9845 },
    { name: 'Bilbao', admin1: 'País Vasco', country: 'España', lat: 43.263, lon: -2.935 },
    { name: 'Málaga', admin1: 'Andalucía', country: 'España', lat: 36.7213, lon: -4.4214 }
  ];

  const fetchWeather = async (city: string, country: string, region: string | undefined, lat: number, lon: number) => {
    setLoadingWeather(true);
    setError(null);
    try {
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto`;
      const res = await fetch(url);
      if (!res.ok) throw new Error('No se ha podido obtener la previsión del tiempo.');
      const data = await res.json();

      const current = data.current;
      const daily = data.daily;

      const structured: WeatherData = {
        city,
        country,
        region,
        temperature: Math.round(current.temperature_2m),
        apparentTemperature: Math.round(current.apparent_temperature),
        humidity: current.relative_humidity_2m,
        windSpeed: Math.round(current.wind_speed_10m),
        precipitation: current.precipitation,
        weatherCode: current.weather_code,
        isDay: Boolean(current.is_day),
        daily: {
          dates: daily.time || [],
          codes: daily.weather_code || [],
          maxTemps: (daily.temperature_2m_max || []).map((t: number) => Math.round(t)),
          minTemps: (daily.temperature_2m_min || []).map((t: number) => Math.round(t)),
          rainProbabilities: daily.precipitation_probability_max || []
        }
      };

      setWeatherData(structured);
      // Save last selected city
      localStorage.setItem('litterator-weather-city', JSON.stringify({ city, country, region, lat, lon }));
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Error al consultar el servicio meteorológico.');
    } finally {
      setLoadingWeather(false);
      setSearchResults([]);
    }
  };

  // Initial load from localStorage or default to Aranjuez (sede Litterator)
  useEffect(() => {
    const saved = localStorage.getItem('litterator-weather-city');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        fetchWeather(parsed.city, parsed.country, parsed.region, parsed.lat, parsed.lon);
        return;
      } catch (e) {
        // fallback
      }
    }
    // Default to Aranjuez
    const aranjuez = popularCities[0];
    fetchWeather(aranjuez.name, aranjuez.country, aranjuez.admin1, aranjuez.lat, aranjuez.lon);
  }, []);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setLoadingSearch(true);
    setError(null);
    try {
      const res = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(searchQuery.trim())}&count=6&language=es&format=json`);
      const data = await res.json();
      if (!data.results || data.results.length === 0) {
        setError(`No se encontraron ciudades con el nombre "${searchQuery}".`);
        setSearchResults([]);
      } else {
        setSearchResults(data.results);
      }
    } catch (err) {
      setError('Error al buscar ciudades. Comprueba la conexión.');
    } finally {
      setLoadingSearch(false);
    }
  };

  const weatherInfo = weatherData ? getWeatherInfo(weatherData.weatherCode, weatherData.isDay) : null;
  const WeatherIcon = weatherInfo ? weatherInfo.icon : Sun;

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-gradient-to-br from-sky-500 to-indigo-600 text-white rounded-2xl shadow-md shadow-sky-100">
            <CloudSun className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tight font-display">El Tiempo Escolar</h1>
            <p className="text-slate-500 text-sm">Consulta el clima en Aranjuez o en cualquier ciudad del mundo.</p>
          </div>
        </div>

        {/* Search City Form */}
        <div className="relative w-full md:w-80">
          <form onSubmit={handleSearch} className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar ciudad (ej. Madrid, Londres)..."
              className="w-full bg-white border border-slate-200 rounded-2xl pl-10 pr-10 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 shadow-sm"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            <button
              type="submit"
              disabled={loadingSearch}
              className="absolute right-2 top-2 px-3 py-1.5 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 transition-colors"
            >
              {loadingSearch ? '...' : 'Buscar'}
            </button>
          </form>

          {/* Autocomplete dropdown */}
          {searchResults.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl border border-slate-100 shadow-xl z-50 overflow-hidden max-h-64 overflow-y-auto">
              <div className="p-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Ciudades encontradas</div>
              {searchResults.map((city) => (
                <button
                  key={`${city.id}-${city.name}`}
                  onClick={() => {
                    fetchWeather(city.name, city.country, city.admin1, city.latitude, city.longitude);
                    setSearchQuery('');
                  }}
                  className="w-full text-left px-4 py-2.5 hover:bg-slate-50 transition-colors border-t border-slate-50 flex items-center justify-between"
                >
                  <div>
                    <p className="font-bold text-sm text-slate-800">{city.name}</p>
                    <p className="text-xs text-slate-400">{[city.admin1, city.country].filter(Boolean).join(', ')}</p>
                  </div>
                  <MapPin className="w-4 h-4 text-indigo-400" />
                </button>
              ))}
            </div>
          )}
        </div>
      </header>

      {/* Popular Cities Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide">
        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mr-1 flex-shrink-0">Frecuentes:</span>
        {popularCities.map((c) => {
          const isSelected = weatherData?.city === c.name;
          return (
            <button
              key={c.name}
              onClick={() => fetchWeather(c.name, c.country, c.admin1, c.lat, c.lon)}
              className={cn(
                "px-4 py-2 rounded-2xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap flex-shrink-0",
                isSelected 
                  ? "bg-slate-900 text-white shadow-md shadow-slate-200" 
                  : "bg-white text-slate-600 border border-slate-100 hover:bg-slate-50"
              )}
            >
              {c.isColegio && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />}
              <span>{c.name}</span>
              {c.isColegio && <span className="text-[10px] opacity-70">(Litterator)</span>}
            </button>
          );
        })}
      </div>

      {error && (
        <div className="bg-rose-50 border border-rose-100 p-4 rounded-2xl text-rose-600 text-sm font-medium">
          {error}
        </div>
      )}

      {loadingWeather && !weatherData && (
        <div className="bg-white p-12 rounded-[32px] border border-slate-100 shadow-sm flex flex-col items-center justify-center text-center">
          <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-4" />
          <p className="text-sm font-bold text-slate-600">Consultando satélites meteorológicos...</p>
        </div>
      )}

      {weatherData && weatherInfo && (
        <div className="space-y-6">
          {/* Main Weather Hero Card */}
          <div className="bg-gradient-to-br from-indigo-600 via-blue-600 to-sky-500 rounded-[32px] p-8 md:p-10 text-white shadow-2xl shadow-indigo-500/20 relative overflow-hidden">
            {/* Background elements */}
            <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full -mr-20 -mt-20 blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 left-1/3 w-64 h-64 bg-indigo-900/20 rounded-full blur-2xl pointer-events-none" />

            <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
              <div>
                <div className="flex items-center gap-2 text-indigo-100 font-bold text-sm uppercase tracking-wider mb-2">
                  <MapPin className="w-4 h-4 text-sky-200" />
                  <span>{weatherData.city}{weatherData.region ? `, ${weatherData.region}` : ''} ({weatherData.country})</span>
                </div>
                <div className="flex items-baseline gap-4">
                  <span className="text-6xl md:text-7xl font-black tracking-tight font-display">
                    {weatherData.temperature}°C
                  </span>
                  <div className="text-indigo-100">
                    <p className="text-lg font-bold">{weatherInfo.label}</p>
                    <p className="text-xs opacity-80">Sensación térmica: {weatherData.apparentTemperature}°C</p>
                  </div>
                </div>

                {/* School Advice Pill */}
                <div className="mt-6 inline-flex items-center gap-2 bg-white/15 backdrop-blur-md px-4 py-2 rounded-2xl border border-white/20 text-sm font-medium">
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>{weatherInfo.advice}</span>
                </div>
              </div>

              {/* Weather Icon Badge */}
              <div className="flex flex-col items-center justify-center p-6 bg-white/10 backdrop-blur-md rounded-3xl border border-white/10 text-center min-w-[160px]">
                <WeatherIcon className="w-20 h-20 text-white drop-shadow-md mb-2" />
                <span className="text-sm font-bold text-indigo-100">{weatherInfo.label}</span>
              </div>
            </div>

            {/* Metrics Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-8 pt-8 border-t border-white/15">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-white/10 rounded-xl">
                  <Droplets className="w-5 h-5 text-sky-200" />
                </div>
                <div>
                  <p className="text-xs text-indigo-100 font-medium">Humedad</p>
                  <p className="text-base font-bold">{weatherData.humidity}%</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-white/10 rounded-xl">
                  <Wind className="w-5 h-5 text-sky-200" />
                </div>
                <div>
                  <p className="text-xs text-indigo-100 font-medium">Viento</p>
                  <p className="text-base font-bold">{weatherData.windSpeed} km/h</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-white/10 rounded-xl">
                  <CloudRain className="w-5 h-5 text-sky-200" />
                </div>
                <div>
                  <p className="text-xs text-indigo-100 font-medium">Lluvia hoy</p>
                  <p className="text-base font-bold">{weatherData.precipitation} mm</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-white/10 rounded-xl">
                  <Thermometer className="w-5 h-5 text-sky-200" />
                </div>
                <div>
                  <p className="text-xs text-indigo-100 font-medium">Máx / Mín</p>
                  <p className="text-base font-bold">
                    {weatherData.daily.maxTemps[0] || weatherData.temperature}° / {weatherData.daily.minTemps[0] || weatherData.temperature}°
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* 5-Day Forecast Grid */}
          <div className="bg-white p-6 md:p-8 rounded-[32px] border border-slate-100 shadow-sm space-y-4">
            <h3 className="text-xl font-bold text-slate-800 font-display">Previsión para los próximos días</h3>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
              {weatherData.daily.dates.slice(0, 5).map((dateStr, idx) => {
                const dateObj = new Date(dateStr);
                const dayName = idx === 0 ? 'Hoy' : dateObj.toLocaleDateString('es-ES', { weekday: 'short' });
                const dayNum = dateObj.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' });
                const code = weatherData.daily.codes[idx] || 0;
                const info = getWeatherInfo(code, true);
                const DayIcon = info.icon;
                const max = weatherData.daily.maxTemps[idx];
                const min = weatherData.daily.minTemps[idx];
                const rainProb = weatherData.daily.rainProbabilities[idx] || 0;

                return (
                  <div
                    key={dateStr}
                    className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex flex-col items-center text-center hover:border-indigo-200 transition-colors"
                  >
                    <span className="font-bold text-sm text-slate-800 capitalize">{dayName}</span>
                    <span className="text-[10px] text-slate-400 font-medium mb-3">{dayNum}</span>
                    
                    <div className="w-12 h-12 rounded-2xl bg-white shadow-sm flex items-center justify-center mb-3">
                      <DayIcon className={cn("w-7 h-7", info.color)} />
                    </div>

                    <p className="text-xs font-bold text-slate-700 truncate max-w-full px-1 mb-2">{info.label}</p>

                    <div className="flex items-center gap-2 text-xs font-bold">
                      <span className="text-slate-900">{max}°</span>
                      <span className="text-slate-400 font-normal">{min}°</span>
                    </div>

                    {rainProb > 0 && (
                      <span className="text-[10px] font-bold text-sky-600 bg-sky-50 px-2 py-0.5 rounded-full mt-2">
                        💧 {rainProb}%
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
