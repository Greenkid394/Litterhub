import React, { useState, useEffect } from 'react';
import { MessageSquare, Send, Mail } from 'lucide-react';
import { db, auth } from '../lib/firebase';
import { collection, addDoc, query, orderBy, onSnapshot, serverTimestamp, where } from 'firebase/firestore';

export default function UserSupportChat() {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<any[]>([]);
  const [hasAutoRepliedSession, setHasAutoRepliedSession] = useState(false);
  const user = auth.currentUser;

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'support_messages'),
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      // Firestore orders by desc, so we reverse it for display
      setMessages(msgs.reverse());
    });
    return () => unsubscribe();
  }, [user]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !user) return;
    
    const isFirstMessage = messages.length === 0;
    const currentMessage = message;
    
    try {
      await addDoc(collection(db, 'support_messages'), {
        text: currentMessage,
        senderEmail: user.email || 'Alumno',
        userId: user.uid,
        isAdminReply: false,
        createdAt: serverTimestamp(),
      });
      setMessage('');

      // Auto-reply logic
      if ((isFirstMessage || !hasAutoRepliedSession)) {
        setHasAutoRepliedSession(true);
        setTimeout(async () => {
          await addDoc(collection(db, 'support_messages'), {
            text: '👋 ¡Hola! Hemos recibido tu mensaje. El equipo de Desarrollo Hub te responderá por aquí lo antes posible.',
            senderEmail: 'Soporte Automático',
            userId: user.uid,
            isAdminReply: true,
            createdAt: serverTimestamp(),
          });
        }, 1500); // 1.5 second delay for realism
      }

    } catch (err) {
      console.error(err);
      alert('Error al enviar mensaje');
    }
  };

  return (
    <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-6 md:col-span-2">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
            <MessageSquare className="w-6 h-6" />
          </div>
          <div>
            <h2 className="font-bold text-xl text-slate-800">Soporte Técnico</h2>
            <p className="text-xs text-slate-500 mt-0.5">Contacta con los desarrolladores de forma privada.</p>
          </div>
        </div>

        {user?.email && (
          <div className="flex items-center gap-2 bg-slate-50 px-3.5 py-1.5 rounded-xl border border-slate-100 text-xs font-bold text-slate-700">
            <Mail className="w-3.5 h-3.5 text-indigo-500 flex-shrink-0" />
            <span>Correo: {user.email}</span>
          </div>
        )}
      </div>

      <div className="space-y-4">
        <div className="h-64 overflow-y-auto bg-slate-50 rounded-2xl p-4 border border-slate-100 space-y-3 flex flex-col">
          {messages.length === 0 ? (
            <p className="text-sm text-slate-400 text-center m-auto font-medium">Envía un mensaje si necesitas ayuda o tienes sugerencias.</p>
          ) : (
            messages.map(msg => {
              const isMe = !msg.isAdminReply;
              return (
                <div key={msg.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                  <div className={`max-w-[80%] p-3 rounded-2xl ${isMe ? 'bg-indigo-600 text-white rounded-br-none' : 'bg-white border border-slate-200 text-slate-800 rounded-bl-none shadow-sm'}`}>
                    <p className="text-sm">{msg.text}</p>
                  </div>
                  <span className="text-[10px] text-slate-400 mt-1 mx-1 font-medium">
                    {isMe ? `Correo: ${user?.email || 'Tú'}` : '🛡️ Desarrollo Hub (Soporte)'}
                  </span>
                </div>
              );
            })
          )}
        </div>

        <form onSubmit={sendMessage} className="flex gap-2">
          <input
            type="text"
            value={message}
            onChange={e => setMessage(e.target.value)}
            placeholder="Escribe tu mensaje para soporte..."
            className="flex-1 bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-sm"
          />
          <button type="submit" className="bg-indigo-600 text-white px-5 py-3 rounded-xl hover:bg-indigo-700 transition-colors flex items-center justify-center">
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
}

