import React, { useState } from 'react';
import { 
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword, 
  sendPasswordResetEmail,
  signOut
} from 'firebase/auth';
import { auth } from '../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Lock, User, AlertCircle, CheckCircle2, ArrowRight, Loader2 } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Auth() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showReset, setShowReset] = useState(false);

  const handleResetPassword = async () => {
    if (!email) {
      setError('Introduce tu correo para restablecer la contraseña');
      return;
    }
    setLoading(true);
    try {
      await sendPasswordResetEmail(auth, email);
      setMessage('Se ha enviado un correo para restablecer tu contraseña a ' + email);
      setShowReset(false);
    } catch (err: any) {
      console.error(err);
      setError('Error al enviar el correo de restablecimiento');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setMessage(null);
    setLoading(true);

    // Validation
    if (!email.includes('@') || !email.includes('.')) {
      setError('Por favor introduce un correo electrónico válido');
      setLoading(false);
      return;
    }

    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, email, password);
      } else {
        await createUserWithEmailAndPassword(auth, email, password);
        setMessage('Cuenta creada con éxito. Ya puedes iniciar sesión.');
        setIsLogin(true);
      }
    } catch (err: any) {
      console.error('Firebase Auth Error:', err);
      const errorCode = err.code;
      
      if (errorCode === 'auth/user-not-found' || errorCode === 'auth/wrong-password' || errorCode === 'auth/invalid-credential') {
        setError('Correo o contraseña incorrectos');
      } else if (errorCode === 'auth/email-already-in-use') {
        setError('Este correo ya está registrado');
      } else if (errorCode === 'auth/weak-password') {
        setError('La contraseña debe tener al menos 6 caracteres');
      } else if (errorCode === 'auth/too-many-requests') {
        setError('Demasiados intentos. Tu cuenta ha sido temporalmente bloqueada por seguridad. Inténtalo más tarde.');
      } else if (errorCode === 'auth/invalid-email') {
        setError('El formato del correo electrónico no es válido');
      } else if (errorCode === 'auth/network-request-failed') {
        setError('Error de conexión. Revisa tu internet.');
      } else if (errorCode === 'auth/operation-not-allowed') {
        setError('El inicio de sesión con correo y contraseña no está habilitado en Firebase. Debes activarlo en la consola de Firebase.');
      } else {
        setError(`Error: ${errorCode || 'Error desconocido'}. Por favor, contacta con soporte o inténtalo de nuevo.`);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white rounded-[32px] shadow-2xl shadow-indigo-100 border border-slate-100 overflow-hidden"
      >
        <div className="p-10">
          <div className="flex justify-center mb-8">
            <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-200">
              <img 
                src="https://colegiolitterator.com/wp-content/uploads/2023/12/ColegioLitterator.svg" 
                alt="Litterator" 
                className="w-10 h-10 brightness-0 invert" 
              />
            </div>
          </div>

          <div className="text-center mb-10">
            <h2 className="text-3xl font-black tracking-tight text-slate-900 mb-2">
              {isLogin ? '¡Hola de nuevo!' : 'Crea tu cuenta'}
            </h2>
            <p className="text-slate-500 font-medium text-sm">
              {isLogin ? 'Accede a tu panel escolar de Litterator' : 'Regístrate con tu correo del colegio'}
            </p>
          </div>

          {error && (
            <motion.div 
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="mb-6 p-4 bg-red-50 border border-red-100 rounded-2xl flex items-start gap-3"
            >
              <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
              <p className="text-xs font-bold text-red-700 leading-tight">{error}</p>
            </motion.div>
          )}

          {message && (
            <motion.div 
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="mb-6 p-4 bg-emerald-50 border border-emerald-100 rounded-2xl flex items-start gap-3"
            >
              <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
              <p className="text-xs font-bold text-emerald-700 leading-tight">{message}</p>
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">Correo Electrónico</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input 
                  type="email"
                  required
                  placeholder="usuario@colegiolitterator.com o tu email"
                  className="w-full bg-slate-50 border-none rounded-2xl py-4 pl-12 pr-4 text-sm font-bold placeholder:text-slate-300 focus:ring-2 focus:ring-indigo-500 transition-all"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between ml-4">
                <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Contraseña</label>
                {isLogin && (
                  <button 
                    type="button"
                    onClick={() => setShowReset(true)}
                    className="text-[10px] font-bold text-indigo-600 hover:text-indigo-700"
                  >
                    ¿Olvidaste tu contraseña?
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input 
                  type="password"
                  required
                  placeholder="••••••••"
                  className="w-full bg-slate-50 border-none rounded-2xl py-4 pl-12 pr-4 text-sm font-bold placeholder:text-slate-300 focus:ring-2 focus:ring-indigo-500 transition-all"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </div>

            <button 
              type="submit"
              disabled={loading}
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-4 rounded-2xl shadow-xl shadow-slate-200 transition-all flex items-center justify-center gap-2 group disabled:opacity-70"
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <span>{isLogin ? 'Entrar' : 'Registrarse'}</span>
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>
          </form>

          <AnimatePresence>
            {showReset && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-6 p-6 bg-indigo-50 rounded-2xl border border-indigo-100"
              >
                <h3 className="text-sm font-bold text-indigo-900 mb-2">Restablecer contraseña</h3>
                <p className="text-xs text-indigo-600 mb-4">
                  Enviaremos un enlace a tu correo institucional para que puedas cambiar tu contraseña.
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={handleResetPassword}
                    disabled={loading}
                    className="flex-1 bg-indigo-600 text-white text-xs font-bold py-2 rounded-xl hover:bg-indigo-700 transition-colors disabled:opacity-50"
                  >
                    Enviar enlace
                  </button>
                  <button
                    onClick={() => setShowReset(false)}
                    className="px-4 py-2 text-xs font-bold text-slate-500 hover:bg-white rounded-xl transition-colors"
                  >
                    Cancelar
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="mt-8 pt-8 border-t border-slate-100 text-center">
            <button 
              onClick={() => setIsLogin(!isLogin)}
              className="text-sm font-bold text-indigo-600 hover:text-indigo-700 transition-colors"
            >
              {isLogin ? '¿No tienes cuenta? Regístrate' : '¿Ya tienes cuenta? Inicia sesión'}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
