import { useState, useEffect, useRef, useMemo } from 'react';
import { Play, Pause, RotateCcw, Coffee, Brain, Timer as TimerIcon, Bell, Plus, TimerReset, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

export default function StudySection() {
  // Timer State
  const [timerMode, setTimerMode] = useState<'pomodoro' | 'stopwatch'>('pomodoro');
  const [totalSeconds, setTotalSeconds] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [targetTime, setTargetTime] = useState<number | null>(null);
  const [pomodoroMode, setPomodoroMode] = useState<'work' | 'shortBreak' | 'longBreak'>('work');
  const [showNotification, setShowNotification] = useState(false);
  
  // Stopwatch State
  const [swTime, setSwTime] = useState(0); // in ms
  const [isSwActive, setIsSwActive] = useState(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Timer Logic
  const switchPomodoroMode = (newMode: 'work' | 'shortBreak' | 'longBreak') => {
    setPomodoroMode(newMode);
    setIsActive(false);
    setTargetTime(null);
    if (newMode === 'work') {
      setTotalSeconds(25 * 60);
    } else if (newMode === 'shortBreak') {
      setTotalSeconds(5 * 60);
    } else {
      setTotalSeconds(15 * 60);
    }
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isActive && timerMode === 'pomodoro' && targetTime) {
      interval = setInterval(() => {
        const remaining = Math.max(0, Math.ceil((targetTime - Date.now()) / 1000));
        setTotalSeconds(remaining);
        if (remaining === 0) {
          setIsActive(false);
          setShowNotification(true);
          setTargetTime(null);
          setTimeout(() => setShowNotification(false), 5000);
        }
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isActive, timerMode, targetTime]);

  const toggleTimer = () => {
    if (!isActive) {
      setTargetTime(Date.now() + totalSeconds * 1000);
    } else {
      setTargetTime(null);
    }
    setIsActive(!isActive);
  };

  // Stopwatch Logic
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isSwActive && timerMode === 'stopwatch') {
      const startTime = Date.now() - swTime;
      interval = setInterval(() => {
        setSwTime(Date.now() - startTime);
      }, 10);
    }
    return () => clearInterval(interval);
  }, [isSwActive, timerMode]);

  const toggleSw = () => setIsSwActive(!isSwActive);

  const resetTimer = () => {
    setIsActive(false);
    setTargetTime(null);
    switchPomodoroMode(pomodoroMode);
  };

  const resetSw = () => {
    setIsSwActive(false);
    setSwTime(0);
  };

  const progress = useMemo(() => {
    if (timerMode !== 'pomodoro') return 0;
    const total = pomodoroMode === 'work' ? 25 * 60 : pomodoroMode === 'shortBreak' ? 5 * 60 : 15 * 60;
    return ((total - totalSeconds) / total) * 100;
  }, [totalSeconds, pomodoroMode, timerMode]);

  const formatSwTime = (ms: number) => {
    const totalSecondsSw = Math.floor(ms / 1000);
    const mins = Math.floor(totalSecondsSw / 60);
    const secs = totalSecondsSw % 60;
    const milliseconds = Math.floor((ms % 1000) / 10);
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}.${String(milliseconds).padStart(2, '0')}`;
  };

  const displayMinutes = Math.floor(totalSeconds / 60);
  const displaySeconds = totalSeconds % 60;

  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Zona de Estudio</h1>
          <p className="text-slate-500 mt-1">Herramientas para mejorar tu concentración.</p>
        </div>
        
        <div className="flex bg-white border border-slate-200 p-1 rounded-2xl shadow-sm">
          <button 
            onClick={() => setTimerMode('pomodoro')}
            className={cn(
              "px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2",
              timerMode === 'pomodoro' ? "bg-slate-900 text-white" : "text-slate-400 hover:text-slate-600"
            )}
          >
            <TimerIcon className="w-4 h-4" />
            Pomodoro
          </button>
          <button 
            onClick={() => setTimerMode('stopwatch')}
            className={cn(
              "px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2",
              timerMode === 'stopwatch' ? "bg-slate-900 text-white" : "text-slate-400 hover:text-slate-600"
            )}
          >
            <Clock className="w-4 h-4" />
            Cronómetro
          </button>
        </div>
      </header>

      {showNotification && (
        <div className="bg-indigo-600 text-white p-4 rounded-2xl shadow-xl flex items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <Bell className="w-5 h-5" />
            <p className="font-bold">¡Tiempo terminado! Hora de cambiar de modo.</p>
          </div>
          <button onClick={() => setShowNotification(false)} className="opacity-70 hover:opacity-100">
            <Plus className="w-5 h-5 rotate-45" />
          </button>
        </div>
      )}

      <div className="max-w-xl mx-auto">
        <div className="bg-white rounded-[40px] p-8 md:p-12 border border-slate-100 shadow-xl shadow-indigo-100/50 flex flex-col items-center min-h-[500px] justify-center">
          {timerMode === 'pomodoro' ? (
            <>
              {/* Mode Switcher */}
              <div className="flex bg-slate-50 p-1.5 rounded-2xl mb-12 w-full max-w-sm">
                {(['work', 'shortBreak', 'longBreak'] as const).map((m) => (
                  <button
                    key={m}
                    onClick={() => switchPomodoroMode(m)}
                    className={cn(
                      "flex-1 py-2.5 rounded-xl text-xs font-bold transition-all",
                      pomodoroMode === m 
                        ? "bg-white text-indigo-600 shadow-sm" 
                        : "text-slate-400 hover:text-slate-600"
                    )}
                  >
                    {m === 'work' ? 'Pomodoro' : m === 'shortBreak' ? 'Descanso' : 'Descanso Largo'}
                  </button>
                ))}
              </div>

              {/* Timer Circle Container */}
              <div className="relative w-64 h-64 flex items-center justify-center mb-12">
                <svg className="w-full h-full -rotate-90">
                  <circle cx="128" cy="128" r="120" fill="none" stroke="currentColor" strokeWidth="8" className="text-slate-50" />
                  <motion.circle
                    cx="128" cy="128" r="120" fill="none" stroke="currentColor" strokeWidth="8"
                    strokeDasharray="754"
                    initial={{ strokeDashoffset: 754 }}
                    animate={{ strokeDashoffset: 754 - (754 * progress) / 100 }}
                    transition={{ duration: 0.5 }}
                    className="text-indigo-600"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-6xl font-black text-slate-800 tracking-tight tabular-nums">
                    {String(displayMinutes).padStart(2, '0')}:{String(displaySeconds).padStart(2, '0')}
                  </span>
                  <span className="text-sm font-bold text-slate-400 mt-2 uppercase tracking-widest">
                    {pomodoroMode === 'work' ? 'Enfocado' : 'Descansando'}
                  </span>
                </div>
              </div>

              {/* Controls */}
              <div className="flex items-center gap-6">
                <button onClick={resetTimer} className="p-4 bg-slate-50 text-slate-500 rounded-2xl hover:bg-slate-100 transition-all active:scale-95">
                  <RotateCcw className="w-6 h-6" />
                </button>
                <button
                  onClick={toggleTimer}
                  className={cn(
                    "w-20 h-20 rounded-[28px] flex items-center justify-center text-white shadow-lg transition-all active:scale-95",
                    isActive ? "bg-amber-500 shadow-amber-100" : "bg-indigo-600 shadow-indigo-100"
                  )}
                >
                  {isActive ? <Pause className="w-8 h-8" fill="currentColor" /> : <Play className="w-8 h-8 translate-x-0.5" fill="currentColor" />}
                </button>
                <div className="p-4 bg-slate-50 text-slate-300 rounded-2xl cursor-not-allowed">
                  <TimerIcon className="w-6 h-6" />
                </div>
              </div>
            </>
          ) : (
            <>
              {/* Stopwatch View */}
              <div className="relative w-72 h-72 flex items-center justify-center mb-12">
                 <div className="absolute inset-0 border-[8px] border-slate-50 rounded-full"></div>
                 <div className="text-5xl font-black text-slate-800 tracking-tighter tabular-nums">
                    {formatSwTime(swTime)}
                 </div>
              </div>

              {/* Controls */}
              <div className="flex items-center gap-6">
                <button onClick={resetSw} className="p-4 bg-slate-50 text-slate-500 rounded-2xl hover:bg-slate-100 transition-all active:scale-95">
                  <TimerReset className="w-6 h-6" />
                </button>
                <button
                  onClick={toggleSw}
                  className={cn(
                    "w-20 h-20 rounded-[28px] flex items-center justify-center text-white shadow-lg transition-all active:scale-95",
                    isSwActive ? "bg-red-500 shadow-red-100" : "bg-emerald-600 shadow-emerald-100"
                  )}
                >
                  {isSwActive ? <Pause className="w-8 h-8" fill="currentColor" /> : <Play className="w-8 h-8 translate-x-0.5" fill="currentColor" />}
                </button>
                <div className="p-4 bg-slate-50 text-slate-300 rounded-2xl cursor-not-allowed">
                  <TimerIcon className="w-6 h-6" />
                </div>
              </div>
            </>
          )}
        </div>

        {/* Study Tips */}
        <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="bg-indigo-50/50 p-6 rounded-3xl border border-indigo-100 flex gap-4">
            <div className="p-3 bg-indigo-100 text-indigo-600 rounded-2xl h-fit">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-slate-800 text-sm mb-1">Dato curioso</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                El cerebro humano puede concentrarse profundamente durante periodos de unos 25 a 45 minutos.
              </p>
            </div>
          </div>
          <div className="bg-amber-50/50 p-6 rounded-3xl border border-amber-100 flex gap-4">
            <div className="p-3 bg-amber-100 text-amber-600 rounded-2xl h-fit">
              <Coffee className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-slate-800 text-sm mb-1">Hidratación</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Beber agua regularmente mientras estudias mejora tu rendimiento cognitivo y memoria.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
