import { useMemo, useState } from 'react';
import { Calendar, Clock, MapPin } from 'lucide-react';
import type { AppState } from '../types';
import { cn } from '../lib/utils';

interface ScheduleSectionProps {
  state: AppState;
}

const dayNames = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];

export default function ScheduleSection({ state }: ScheduleSectionProps) {
  const [selectedDay, setSelectedDay] = useState(new Date().getDay() || 1); // Default to Monday if Sunday

  const scheduleForDay = useMemo(() => {
    if (!state.schedule) return null;
    return state.schedule.days.find(d => d.dayOfWeek === selectedDay);
  }, [state.schedule, selectedDay]);

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-slate-900">Horario Escolar</h1>
        <p className="text-slate-500 mt-1">Tu planificación semanal de clases.</p>
      </header>

      {/* Day Selector */}
      <div className="flex overflow-x-auto gap-2 pb-2 -mx-2 px-2 scrollbar-hide">
        {[1, 2, 3, 4, 5].map((day) => (
          <button
            key={day}
            onClick={() => setSelectedDay(day)}
            className={cn(
              "px-6 py-3 rounded-2xl font-bold text-sm transition-all flex-shrink-0 whitespace-nowrap",
              selectedDay === day 
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-100" 
                : "bg-white text-slate-500 border border-slate-100 hover:bg-slate-50"
            )}
          >
            {dayNames[day]}
          </button>
        ))}
      </div>

      {!state.schedule ? (
        <div className="bg-white rounded-3xl p-12 border-2 border-dashed border-slate-200 flex flex-col items-center justify-center text-center">
          <Calendar className="w-16 h-16 text-slate-200 mb-4" />
          <h3 className="text-xl font-bold text-slate-800 mb-2">No hay horario cargado</h3>
          <p className="text-slate-500 max-w-sm">
            Sube el PDF de tu horario en la sección de Ajustes para poder visualizar tus clases diarias.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {scheduleForDay && scheduleForDay.classes.length > 0 ? (
            scheduleForDay.classes.map((cls, idx) => (
              <div 
                key={idx} 
                className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-6 group hover:border-indigo-100 transition-colors"
              >
                <div className="flex flex-col items-center justify-center min-w-[80px] py-2 border-r border-slate-100">
                  <span className="text-indigo-600 font-bold text-sm tracking-tight">{cls.startTime}</span>
                  <div className="w-0.5 h-4 bg-slate-100 my-1"></div>
                  <span className="text-slate-400 font-medium text-xs tracking-tight">{cls.endTime}</span>
                </div>
                
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">{cls.subject}</h3>
                  {cls.room && (
                    <div className="flex items-center gap-1.5 mt-1 text-slate-400">
                      <MapPin className="w-3 h-3" />
                      <span className="text-xs font-medium">Aula {cls.room}</span>
                    </div>
                  )}
                </div>

                <div className="hidden sm:block">
                  <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-300">
                    <Clock className="w-5 h-5" />
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="bg-slate-50 rounded-3xl p-12 flex flex-col items-center justify-center text-center text-slate-400">
              <p>No hay clases registradas para este día.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
