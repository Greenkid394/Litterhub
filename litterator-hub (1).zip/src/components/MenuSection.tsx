import { useMemo, useState } from 'react';
import { Utensils, Calendar, Info, Calculator, InfoIcon } from 'lucide-react';
import type { AppState } from '../types';
import { cn } from '../lib/utils';

interface MenuSectionProps {
  state: AppState;
}

export default function MenuSection({ state }: MenuSectionProps) {
  const [selectedAllergens, setSelectedAllergens] = useState<string[]>([]);
  
  const currentMonth = useMemo(() => {
    if (!state.menu) return "Carga el menú";
    return state.menu.month;
  }, [state.menu]);

  const items = state.menu?.items || [];

  const commonAllergens = ['Gluten', 'Lácteos', 'Huevos', 'Frutos Secos', 'Pescado'];

  const toggleAllergen = (allergen: string) => {
    setSelectedAllergens(prev => 
      prev.includes(allergen) 
        ? prev.filter(a => a !== allergen)
        : [...prev, allergen]
    );
  };

  const hasAllergenWarning = (itemText: string) => {
    if (selectedAllergens.length === 0) return false;
    const textLower = itemText.toLowerCase();
    
    // Very basic client-side check matching text (real life would need more complex matching)
    return selectedAllergens.some(allergen => {
      const a = allergen.toLowerCase();
      if (a === 'lácteos' && (textLower.includes('queso') || textLower.includes('leche') || textLower.includes('nata'))) return true;
      if (a === 'gluten' && (textLower.includes('pan') || textLower.includes('pasta') || textLower.includes('macarrones') || textLower.includes('harina'))) return true;
      if (a === 'pescado' && (textLower.includes('merluza') || textLower.includes('pescado') || textLower.includes('salmón'))) return true;
      if (a === 'huevos' && (textLower.includes('tortilla') || textLower.includes('huevo'))) return true;
      if (a === 'frutos secos' && (textLower.includes('nueces') || textLower.includes('almendra'))) return true;
      return textLower.includes(a);
    });
  };

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Menú del Mes</h1>
          <p className="text-slate-500 mt-1">Calendario de comedor de Litterator.</p>
        </div>
        <div className="bg-white px-4 py-2 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-3">
          <Calendar className="w-5 h-5 text-indigo-500" />
          <span className="font-bold text-slate-700 capitalize">{currentMonth} {state.menu?.year}</span>
        </div>
      </header>

      {state.menu && (
        <div className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="flex items-center gap-2 text-slate-700 font-bold px-2">
            <InfoIcon className="w-5 h-5 text-indigo-500" />
            <span>Filtro de Alergias:</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {commonAllergens.map(allergen => (
              <button
                key={allergen}
                onClick={() => toggleAllergen(allergen)}
                className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  selectedAllergens.includes(allergen)
                    ? 'bg-red-500 text-white shadow-md shadow-red-200'
                    : 'bg-slate-50 text-slate-500 hover:bg-slate-100'
                }`}
              >
                {allergen}
              </button>
            ))}
          </div>
        </div>
      )}

      {!state.menu ? (
        <div className="bg-white rounded-3xl p-12 border-2 border-dashed border-slate-200 flex flex-col items-center justify-center text-center">
          <Utensils className="w-16 h-16 text-slate-200 mb-4" />
          <h3 className="text-xl font-bold text-slate-800 mb-2">No hay menú cargado</h3>
          <p className="text-slate-500 max-w-sm">
            Para ver el menú del mes, ve a la sección de Ajustes y sube el PDF mensual que proporciona el colegio.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.map((item, idx) => {
            const isToday = new Date().getDate() === item.day;
            const fullMenuText = `${item.firstCourse} ${item.secondCourse} ${item.dessert}`;
            const isWarning = hasAllergenWarning(fullMenuText);

            return (
              <div 
                key={idx} 
                className={cn(
                  "bg-white p-5 rounded-3xl border shadow-sm transition-all group relative overflow-hidden",
                  isToday ? "border-indigo-200 ring-2 ring-indigo-50" : "border-slate-100 hover:shadow-md",
                  isWarning && "bg-red-50/50 border-red-100"
                )}
              >
                {isWarning && (
                  <div className="absolute top-0 right-0 bg-red-500 text-white text-[9px] font-bold px-3 py-1 rounded-bl-xl uppercase tracking-wider">
                    Contiene Alérgeno
                  </div>
                )}
                
                <div className="flex items-center justify-between mb-4 relative z-10">
                  <span className={cn(
                    "w-10 h-10 rounded-xl flex items-center justify-center font-bold",
                    isWarning ? "bg-red-100 text-red-600" : "bg-indigo-50 text-indigo-600"
                  )}>
                    {item.day}
                  </span>
                  <span className={cn(
                    "text-xs font-bold uppercase tracking-tighter",
                    isWarning ? "text-red-400" : "text-slate-400"
                  )}>{item.date}</span>
                </div>
                
                <div className="space-y-3 relative z-10">
                  <div>
                    <p className={cn("text-[10px] font-bold uppercase mb-0.5", isWarning ? "text-red-400" : "text-indigo-400")}>Primero</p>
                    <p className={cn("text-sm font-medium", isWarning ? "text-red-900" : "text-slate-800")}>{item.firstCourse}</p>
                  </div>
                  <div className={cn("pt-2 border-t", isWarning ? "border-red-100" : "border-slate-50")}>
                    <p className={cn("text-[10px] font-bold uppercase mb-0.5", isWarning ? "text-red-400" : "text-indigo-400")}>Segundo</p>
                    <p className={cn("text-sm font-medium", isWarning ? "text-red-900" : "text-slate-800")}>{item.secondCourse}</p>
                  </div>
                  <div className={cn("pt-2 border-t", isWarning ? "border-red-100" : "border-slate-50")}>
                    <p className={cn("text-[10px] font-bold uppercase mb-0.5", isWarning ? "text-red-400" : "text-indigo-400")}>Postre</p>
                    <p className={cn("text-sm font-medium", isWarning ? "text-red-900" : "text-slate-800")}>{item.dessert}</p>
                  </div>
                </div>

                {item.observations && (
                  <div className={cn("mt-4 pt-3 border-t flex items-start gap-2 italic", isWarning ? "border-red-100 text-red-400" : "border-slate-50 text-slate-400")}>
                    <Info className="w-3 h-3 mt-1 flex-shrink-0" />
                    <p className="text-[10px] leading-relaxed">{item.observations}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
