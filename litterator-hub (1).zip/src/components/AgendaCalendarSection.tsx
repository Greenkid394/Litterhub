import React, { useState, useMemo } from 'react';
import { 
  Calendar as CalendarIcon, 
  ChevronLeft, 
  ChevronRight, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Circle, 
  Clock, 
  AlertCircle, 
  BookOpen, 
  Tag, 
  Filter,
  Check,
  Sparkles,
  CalendarDays
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import type { AppState, AgendaEvent } from '../types';
import { cn } from '../lib/utils';

interface AgendaCalendarSectionProps {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
}

export default function AgendaCalendarSection({ state, setState }: AgendaCalendarSectionProps) {
  const today = new Date();
  const [currentDate, setCurrentDate] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [selectedDate, setSelectedDate] = useState<string>(
    `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`
  );
  const [viewMode, setViewMode] = useState<'calendar' | 'agenda'>('calendar');
  const [filterType, setFilterType] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form states
  const [formTitle, setFormTitle] = useState('');
  const [formDate, setFormDate] = useState(selectedDate);
  const [formTime, setFormTime] = useState('');
  const [formType, setFormType] = useState<AgendaEvent['type']>('tarea');
  const [formSubject, setFormSubject] = useState('Matemáticas');
  const [formDescription, setFormDescription] = useState('');
  const [formPriority, setFormPriority] = useState<AgendaEvent['priority']>('media');

  // Combine existing assignments with agendaEvents so none of the user's data is lost
  const events: AgendaEvent[] = useMemo(() => {
    const list: AgendaEvent[] = state.agendaEvents ? [...state.agendaEvents] : [];

    // Map any assignments from state.assignments that are not yet in agendaEvents
    state.assignments.forEach(a => {
      const alreadyExists = list.some(e => e.id === a.id);
      if (!alreadyExists) {
        list.push({
          id: a.id,
          title: a.title,
          date: a.dueDate,
          type: a.type === 'examen' ? 'examen' : 'tarea',
          completed: a.completed,
          subject: a.description || 'General',
          priority: a.type === 'examen' ? 'alta' : 'media'
        });
      }
    });

    return list;
  }, [state.agendaEvents, state.assignments]);

  const subjects = [
    'Matemáticas',
    'Lengua y Literatura',
    'Inglés',
    'Física y Química',
    'Biología y Geología',
    'Historia / Geografía',
    'Filosofía',
    'Educación Física',
    'Tecnología',
    'Música',
    'Dibujo / Plástica',
    'General / Tutoría'
  ];

  // Calendar calculations
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayIndex = (new Date(year, month, 1).getDay() + 6) % 7; // Monday is 0

  const monthNames = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  ];

  const prevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const goToToday = () => {
    const now = new Date();
    setCurrentDate(new Date(now.getFullYear(), now.getMonth(), 1));
    setSelectedDate(`${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`);
  };

  // Events map by date string (YYYY-MM-DD)
  const eventsByDate = useMemo(() => {
    const map: Record<string, AgendaEvent[]> = {};
    events.forEach(e => {
      if (!map[e.date]) map[e.date] = [];
      map[e.date].push(e);
    });
    return map;
  }, [events]);

  const selectedDayEvents = useMemo(() => {
    const list = eventsByDate[selectedDate] || [];
    if (filterType === 'all') return list;
    if (filterType === 'pending') return list.filter(e => !e.completed);
    if (filterType === 'completed') return list.filter(e => e.completed);
    return list.filter(e => e.type === filterType);
  }, [eventsByDate, selectedDate, filterType]);

  // Timetable classes for selected day
  const selectedDaySchedule = useMemo(() => {
    if (!state.schedule) return null;
    const parts = selectedDate.split('-').map(Number);
    const dateObj = new Date(parts[0], parts[1] - 1, parts[2]);
    const dayOfWeek = dateObj.getDay(); // 0 is Sunday, 1 is Monday
    return state.schedule.days.find(d => d.dayOfWeek === dayOfWeek);
  }, [state.schedule, selectedDate]);

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formDate) return;

    const newEvent: AgendaEvent = {
      id: crypto.randomUUID(),
      title: formTitle.trim(),
      date: formDate,
      time: formTime || undefined,
      type: formType,
      subject: formSubject,
      description: formDescription.trim() || undefined,
      priority: formPriority,
      completed: false
    };

    const updated = [...events, newEvent];
    
    // Also sync to assignments for backwards compatibility if needed
    const updatedAssignments = [
      ...state.assignments,
      {
        id: newEvent.id,
        title: newEvent.title,
        dueDate: newEvent.date,
        type: newEvent.type === 'examen' ? 'examen' as const : 'trabajo' as const,
        completed: false,
        description: newEvent.subject
      }
    ];

    setState(prev => ({
      ...prev,
      agendaEvents: updated,
      assignments: updatedAssignments
    }));

    setFormTitle('');
    setFormDescription('');
    setFormTime('');
    setIsModalOpen(false);
  };

  const toggleEventComplete = (id: string) => {
    const updated = events.map(e => e.id === id ? { ...e, completed: !e.completed } : e);
    const updatedAssignments = state.assignments.map(a => a.id === id ? { ...a, completed: !a.completed } : a);

    setState(prev => ({
      ...prev,
      agendaEvents: updated,
      assignments: updatedAssignments
    }));
  };

  const deleteEvent = (id: string) => {
    const updated = events.filter(e => e.id !== id);
    const updatedAssignments = state.assignments.filter(a => a.id !== id);

    setState(prev => ({
      ...prev,
      agendaEvents: updated,
      assignments: updatedAssignments
    }));
  };

  const getTypeBadge = (type: AgendaEvent['type']) => {
    switch (type) {
      case 'examen':
        return { label: 'Examen', bg: 'bg-rose-50 text-rose-700 border-rose-200', dot: 'bg-rose-500' };
      case 'tarea':
        return { label: 'Deberes', bg: 'bg-amber-50 text-amber-700 border-amber-200', dot: 'bg-amber-500' };
      case 'trabajo':
        return { label: 'Entrega Trabajo', bg: 'bg-indigo-50 text-indigo-700 border-indigo-200', dot: 'bg-indigo-500' };
      case 'actividad':
        return { label: 'Excursión / Actividad', bg: 'bg-emerald-50 text-emerald-700 border-emerald-200', dot: 'bg-emerald-500' };
      case 'recordatorio':
        return { label: 'Recordatorio', bg: 'bg-purple-50 text-purple-700 border-purple-200', dot: 'bg-purple-500' };
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-gradient-to-br from-indigo-500 to-indigo-700 text-white rounded-2xl shadow-md shadow-indigo-100">
            <CalendarDays className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tight font-display">Agenda Escolar</h1>
            <p className="text-slate-500 text-sm">Tu calendario mensual y agenda diaria de tareas y exámenes.</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center bg-white p-1 rounded-2xl border border-slate-200 shadow-sm">
            <button
              onClick={() => setViewMode('calendar')}
              className={cn(
                "px-4 py-2 rounded-xl text-xs font-bold transition-all",
                viewMode === 'calendar' ? "bg-slate-900 text-white shadow-sm" : "text-slate-500 hover:text-slate-900"
              )}
            >
              Calendario
            </button>
            <button
              onClick={() => setViewMode('agenda')}
              className={cn(
                "px-4 py-2 rounded-xl text-xs font-bold transition-all",
                viewMode === 'agenda' ? "bg-slate-900 text-white shadow-sm" : "text-slate-500 hover:text-slate-900"
              )}
            >
              Lista Agenda
            </button>
          </div>

          <button
            onClick={() => {
              setFormDate(selectedDate);
              setIsModalOpen(true);
            }}
            className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl text-xs font-bold shadow-md shadow-indigo-200 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Añadir a Agenda</span>
          </button>
        </div>
      </header>

      {/* Main Grid: Calendar on Left, Selected Day Details on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Calendar Grid */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-6 md:p-8 rounded-[32px] border border-slate-100 shadow-xl shadow-slate-200/40">
            {/* Calendar Controls */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <h2 className="text-2xl font-black text-slate-800 font-display">
                  {monthNames[month]} {year}
                </h2>
                <button
                  onClick={goToToday}
                  className="text-xs font-bold px-3 py-1.5 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 rounded-xl transition-colors"
                >
                  Hoy
                </button>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={prevMonth}
                  className="p-2 hover:bg-slate-100 rounded-xl text-slate-600 transition-colors"
                  title="Mes anterior"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={nextMonth}
                  className="p-2 hover:bg-slate-100 rounded-xl text-slate-600 transition-colors"
                  title="Mes siguiente"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Days of week header */}
            <div className="grid grid-cols-7 gap-2 text-center text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
              <span>Lun</span>
              <span>Mar</span>
              <span>Mié</span>
              <span>Jue</span>
              <span>Vie</span>
              <span className="text-indigo-400">Sáb</span>
              <span className="text-indigo-400">Dom</span>
            </div>

            {/* Calendar Cells */}
            <div className="grid grid-cols-7 gap-2">
              {/* Empty placeholder cells before first day */}
              {Array.from({ length: firstDayIndex }).map((_, idx) => (
                <div key={`empty-${idx}`} className="h-20 sm:h-24 bg-slate-50/50 rounded-2xl border border-transparent" />
              ))}

              {/* Day cells */}
              {Array.from({ length: daysInMonth }).map((_, idx) => {
                const dayNum = idx + 1;
                const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
                const isSelected = selectedDate === dateStr;
                const isToday = 
                  today.getDate() === dayNum && 
                  today.getMonth() === month && 
                  today.getFullYear() === year;

                const dayEvents = eventsByDate[dateStr] || [];
                const hasExam = dayEvents.some(e => e.type === 'examen');
                const hasHomework = dayEvents.some(e => e.type === 'tarea' || e.type === 'trabajo');
                const hasPending = dayEvents.some(e => !e.completed);

                return (
                  <button
                    key={dateStr}
                    onClick={() => setSelectedDate(dateStr)}
                    className={cn(
                      "h-20 sm:h-24 p-2 rounded-2xl border flex flex-col justify-between transition-all text-left group relative",
                      isSelected 
                        ? "border-indigo-600 bg-indigo-50/40 shadow-md ring-2 ring-indigo-500/20" 
                        : "border-slate-100 hover:border-indigo-200 bg-white hover:bg-slate-50/50",
                      isToday && !isSelected && "border-indigo-300"
                    )}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className={cn(
                        "text-xs font-black w-6 h-6 rounded-full flex items-center justify-center transition-colors",
                        isToday 
                          ? "bg-indigo-600 text-white shadow-sm" 
                          : isSelected 
                          ? "text-indigo-600 font-black" 
                          : "text-slate-700"
                      )}>
                        {dayNum}
                      </span>

                      {dayEvents.length > 0 && (
                        <span className="text-[10px] font-bold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded-md">
                          {dayEvents.length}
                        </span>
                      )}
                    </div>

                    {/* Events dots / preview */}
                    <div className="flex flex-wrap gap-1 mt-1 overflow-hidden max-h-8">
                      {dayEvents.slice(0, 3).map((ev) => {
                        const badge = getTypeBadge(ev.type);
                        return (
                          <span
                            key={ev.id}
                            className={cn("w-2 h-2 rounded-full", badge.dot, ev.completed && "opacity-30")}
                            title={`${ev.title} (${ev.type})`}
                          />
                        );
                      })}
                      {dayEvents.length > 3 && (
                        <span className="text-[8px] text-slate-400 font-bold">+{dayEvents.length - 3}</span>
                      )}
                    </div>

                    {/* Tiny type tag on hover/selected */}
                    {hasExam && (
                      <span className="text-[8px] font-bold text-rose-600 truncate w-full hidden sm:block">
                        Examen
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Selected Day Agenda & Schedule */}
        <div className="space-y-6">
          <div className="bg-white p-6 md:p-8 rounded-[32px] border border-slate-100 shadow-xl shadow-slate-200/40 space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-indigo-500">Agenda del día</span>
                <h3 className="text-xl font-black text-slate-900 capitalize font-display">
                  {new Date(selectedDate.replace(/-/g, '/')).toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' })}
                </h3>
              </div>

              <button
                onClick={() => {
                  setFormDate(selectedDate);
                  setIsModalOpen(true);
                }}
                className="p-2 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 rounded-xl transition-colors"
                title="Añadir tarea a este día"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>

            {/* Filter pills */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-hide text-xs font-bold">
              {[
                { id: 'all', label: 'Todos' },
                { id: 'pending', label: 'Pendientes' },
                { id: 'examen', label: 'Exámenes' },
                { id: 'tarea', label: 'Deberes' },
              ].map(f => (
                <button
                  key={f.id}
                  onClick={() => setFilterType(f.id)}
                  className={cn(
                    "px-3 py-1.5 rounded-xl transition-all whitespace-nowrap",
                    filterType === f.id ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-500 hover:bg-slate-200"
                  )}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {/* List of events for selected day */}
            <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
              {selectedDayEvents.map(event => {
                const badge = getTypeBadge(event.type);
                return (
                  <div
                    key={event.id}
                    className={cn(
                      "p-4 rounded-2xl border transition-all flex items-start gap-3 group",
                      event.completed 
                        ? "bg-slate-50 border-slate-100 opacity-60" 
                        : "bg-white border-slate-200 hover:border-indigo-200 hover:shadow-sm"
                    )}
                  >
                    <button
                      onClick={() => toggleEventComplete(event.id)}
                      className="mt-0.5 text-slate-400 hover:text-indigo-600 transition-colors flex-shrink-0"
                    >
                      {event.completed ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                      ) : (
                        <Circle className="w-5 h-5" />
                      )}
                    </button>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <span className={cn("text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md border", badge.bg)}>
                          {badge.label}
                        </span>
                        {event.subject && (
                          <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                            {event.subject}
                          </span>
                        )}
                        {event.time && (
                          <span className="text-[10px] font-bold text-indigo-600 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {event.time}
                          </span>
                        )}
                      </div>

                      <h4 className={cn("text-sm font-bold text-slate-800", event.completed && "line-through text-slate-400")}>
                        {event.title}
                      </h4>

                      {event.description && (
                        <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                          {event.description}
                        </p>
                      )}
                    </div>

                    <button
                      onClick={() => deleteEvent(event.id)}
                      className="opacity-0 group-hover:opacity-100 p-1.5 text-slate-400 hover:text-red-500 rounded-lg hover:bg-red-50 transition-all flex-shrink-0"
                      title="Eliminar"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}

              {selectedDayEvents.length === 0 && (
                <div className="text-center py-8 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                  <CalendarIcon className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-bold text-slate-500">No hay tareas programadas para este día</p>
                  <p className="text-[10px] text-slate-400 mt-1">¡Aprovecha para descansar o adelantar trabajo!</p>
                </div>
              )}
            </div>

            {/* Daily Class Schedule integration */}
            {selectedDaySchedule && selectedDaySchedule.classes.length > 0 && (
              <div className="pt-4 border-t border-slate-100 space-y-3">
                <div className="flex items-center gap-2 text-slate-700 font-bold text-xs uppercase tracking-wider">
                  <Clock className="w-4 h-4 text-indigo-500" />
                  <span>Clases según tu Horario ({selectedDaySchedule.classes.length})</span>
                </div>

                <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                  {selectedDaySchedule.classes.map((cls, idx) => (
                    <div key={idx} className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-indigo-600">{cls.startTime}</span>
                        <span className="font-bold text-slate-800">{cls.subject}</span>
                      </div>
                      {cls.room && <span className="text-[10px] text-slate-400">Aula {cls.room}</span>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Modal for adding new event */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 md:p-8 max-w-lg w-full shadow-2xl border border-slate-100 space-y-5"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
                    <CalendarDays className="w-5 h-5" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 font-display">Nueva Entrada en Agenda</h3>
                </div>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="text-slate-400 hover:text-slate-600 p-1"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleCreateEvent} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
                    Título del evento o tarea *
                  </label>
                  <input
                    type="text"
                    required
                    value={formTitle}
                    onChange={(e) => setFormTitle(e.target.value)}
                    placeholder="Ej. Examen de Historia Tema 3, Ejercicios pág 45..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
                      Fecha *
                    </label>
                    <input
                      type="date"
                      required
                      value={formDate}
                      onChange={(e) => setFormDate(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
                      Hora (opcional)
                    </label>
                    <input
                      type="time"
                      value={formTime}
                      onChange={(e) => setFormTime(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
                      Tipo de entrada
                    </label>
                    <select
                      value={formType}
                      onChange={(e) => setFormType(e.target.value as any)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-medium"
                    >
                      <option value="tarea">📝 Deberes / Tarea</option>
                      <option value="examen">🎯 Examen</option>
                      <option value="trabajo">📚 Entrega de Trabajo</option>
                      <option value="actividad">🚌 Excursión / Actividad</option>
                      <option value="recordatorio">🔔 Recordatorio</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
                      Asignatura
                    </label>
                    <select
                      value={formSubject}
                      onChange={(e) => setFormSubject(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-medium"
                    >
                      {subjects.map(s => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
                    Descripción o notas adicionales
                  </label>
                  <textarea
                    rows={3}
                    value={formDescription}
                    onChange={(e) => setFormDescription(e.target.value)}
                    placeholder="Detalles sobre qué temas entran, material a traer, etc."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 resize-none"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-5 py-2.5 rounded-xl text-slate-600 font-bold text-sm hover:bg-slate-100 transition-colors"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm rounded-xl shadow-md shadow-indigo-100 transition-colors"
                  >
                    Guardar en Agenda
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
