import React, { useState } from 'react';
import { Plus, Trash2, CheckCircle2, Circle, Calendar, AlertCircle, FileText, Tag } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import type { AppState, Assignment } from '../types';
import { cn } from '../lib/utils';

interface AssignmentsSectionProps {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
}

export default function AssignmentsSection({ state, setState }: AssignmentsSectionProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDate, setNewDate] = useState('');
  const [newType, setNewType] = useState<'trabajo' | 'examen'>('trabajo');

  const addAssignment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newDate) return;

    const assignment: Assignment = {
      id: crypto.randomUUID(),
      title: newTitle,
      dueDate: newDate,
      type: newType,
      completed: false,
    };

    setState(prev => ({
      ...prev,
      assignments: [...prev.assignments, assignment]
    }));

    setNewTitle('');
    setNewDate('');
    setIsAdding(false);
  };

  const toggleComplete = (id: string) => {
    setState(prev => ({
      ...prev,
      assignments: prev.assignments.map(a => 
        a.id === id ? { ...a, completed: !a.completed } : a
      )
    }));
  };

  const removeAssignment = (id: string) => {
    setState(prev => ({
      ...prev,
      assignments: prev.assignments.filter(a => a.id !== id)
    }));
  };

  const sortedAssignments = [...state.assignments].sort((a, b) => {
    if (a.completed !== b.completed) return a.completed ? 1 : -1;
    return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
  });

  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Tareas y Exámenes</h1>
          <p className="text-slate-500 mt-1">Organiza tus entregas y fechas importantes.</p>
        </div>
        <button
          onClick={() => setIsAdding(true)}
          className="bg-indigo-600 text-white px-5 py-3 rounded-2xl font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all flex items-center gap-2"
        >
          <Plus className="w-5 h-5" />
          <span className="hidden sm:inline">Nueva Tarea</span>
        </button>
      </header>

      <AnimatePresence>
        {isAdding && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <form onSubmit={addAssignment} className="bg-white p-6 rounded-3xl border border-indigo-100 shadow-sm space-y-4 mb-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-500 uppercase ml-1">Título</label>
                  <input
                    type="text"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="Ej: Proyecto de Historia"
                    className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:bg-white transition-all"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-500 uppercase ml-1">Fecha de Entrega</label>
                  <input
                    type="date"
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:bg-white transition-all"
                  />
                </div>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="flex-1 flex gap-2">
                  <button
                    type="button"
                    onClick={() => setNewType('trabajo')}
                    className={cn(
                      "flex-1 py-3 rounded-xl font-bold text-sm border transition-all",
                      newType === 'trabajo' 
                        ? "bg-blue-50 border-blue-200 text-blue-600" 
                        : "bg-white border-slate-100 text-slate-400 hover:bg-slate-50"
                    )}
                  >
                    Trabajo
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewType('examen')}
                    className={cn(
                      "flex-1 py-3 rounded-xl font-bold text-sm border transition-all",
                      newType === 'examen' 
                        ? "bg-red-50 border-red-200 text-red-600" 
                        : "bg-white border-slate-100 text-slate-400 hover:bg-slate-50"
                    )}
                  >
                    Examen
                  </button>
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setIsAdding(false)}
                    className="px-6 py-3 rounded-xl font-bold text-sm text-slate-500 hover:bg-slate-50 transition-all"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold text-sm hover:bg-indigo-700 transition-all shadow-md shadow-indigo-100"
                  >
                    Guardar
                  </button>
                </div>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="space-y-4">
        {sortedAssignments.length > 0 ? (
          sortedAssignments.map((assignment) => (
            <motion.div
              layout
              key={assignment.id}
              className={cn(
                "bg-white p-5 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-4 group transition-all",
                assignment.completed && "opacity-60 bg-slate-50"
              )}
            >
              <button
                onClick={() => toggleComplete(assignment.id)}
                className={cn(
                  "flex-shrink-0 transition-colors",
                  assignment.completed ? "text-green-500" : "text-slate-300 hover:text-indigo-400"
                )}
              >
                {assignment.completed ? (
                  <CheckCircle2 className="w-8 h-8" />
                ) : (
                  <Circle className="w-8 h-8" />
                )}
              </button>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className={cn(
                    "px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider",
                    assignment.type === 'examen' ? "bg-red-100 text-red-600" : "bg-blue-100 text-blue-600"
                  )}>
                    {assignment.type}
                  </span>
                  <span className="flex items-center gap-1 text-slate-400 text-[10px] font-medium">
                    <Calendar className="w-3 h-3" />
                    {new Date(assignment.dueDate).toLocaleDateString('es-ES', { weekday: 'short', day: 'numeric', month: 'short' })}
                  </span>
                </div>
                <h3 className={cn(
                  "font-bold text-slate-800 truncate transition-all",
                  assignment.completed && "line-through"
                )}>
                  {assignment.title}
                </h3>
              </div>

              <button
                onClick={() => removeAssignment(assignment.id)}
                className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all opacity-100 md:opacity-0 md:group-hover:opacity-100"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </motion.div>
          ))
        ) : (
          <div className="bg-white rounded-3xl p-12 border-2 border-dashed border-slate-200 flex flex-col items-center justify-center text-center">
            <Tag className="w-16 h-16 text-slate-200 mb-4" />
            <h3 className="text-xl font-bold text-slate-800 mb-2">No tienes tareas pendientes</h3>
            <p className="text-slate-500 max-w-sm">
              Pulsa el botón "Nueva Tarea" para añadir tus próximos trabajos o exámenes.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
