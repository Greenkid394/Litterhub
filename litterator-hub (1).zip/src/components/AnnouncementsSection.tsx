import React, { useState, useEffect } from 'react';
import { 
  Megaphone, 
  Calendar, 
  Clock, 
  AlertTriangle, 
  Info, 
  ShieldAlert, 
  CheckCircle2, 
  Search, 
  Filter,
  Sparkles,
  School,
  BellRing
} from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, query, orderBy, onSnapshot, doc, getDoc } from 'firebase/firestore';
import type { SchoolAnnouncement } from '../types';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

export default function AnnouncementsSection() {
  const [announcements, setAnnouncements] = useState<SchoolAnnouncement[]>([]);
  const [featuredAnnouncement, setFeaturedAnnouncement] = useState<SchoolAnnouncement | null>(null);
  const [loading, setLoading] = useState(true);
  const [filterPriority, setFilterPriority] = useState<'all' | 'alert' | 'important' | 'info'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    // 1. Listen to the latest active announcement from shared_resources/announcement
    const unsubFeatured = onSnapshot(doc(db, 'shared_resources', 'announcement'), (snap) => {
      if (snap.exists()) {
        const data = snap.data() as SchoolAnnouncement;
        if (data.active) {
          setFeaturedAnnouncement(data);
        } else {
          setFeaturedAnnouncement(null);
        }
      } else {
        setFeaturedAnnouncement(null);
      }
    });

    // 2. Listen to the announcements collection
    const q = query(collection(db, 'announcements'), orderBy('date', 'desc'));
    const unsubList = onSnapshot(q, (snapshot) => {
      const list: SchoolAnnouncement[] = snapshot.docs.map(docSnap => ({
        id: docSnap.id,
        ...docSnap.data()
      } as SchoolAnnouncement));
      setAnnouncements(list);
      setLoading(false);
    }, (err) => {
      console.warn('Announcements collection note:', err);
      setLoading(false);
    });

    return () => {
      unsubFeatured();
      unsubList();
    };
  }, []);

  // Merge featured announcement into list if not already present
  const allAnnouncements = React.useMemo(() => {
    const list = [...announcements];
    if (featuredAnnouncement) {
      const exists = list.some(a => 
        a.title === featuredAnnouncement.title && 
        a.date === featuredAnnouncement.date
      );
      if (!exists) {
        list.unshift({ ...featuredAnnouncement, id: 'featured-active' });
      }
    }
    return list;
  }, [announcements, featuredAnnouncement]);

  const filteredAnnouncements = allAnnouncements.filter(item => {
    const matchesPriority = filterPriority === 'all' || item.priority === filterPriority;
    const matchesSearch = 
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.author && item.author.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesPriority && matchesSearch;
  });

  return (
    <div className="space-y-6 md:space-y-8 pb-10">
      {/* Section Header */}
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="p-3.5 bg-gradient-to-br from-indigo-600 to-rose-600 text-white rounded-2xl shadow-lg shadow-indigo-100 dark:shadow-none flex-shrink-0">
            <Megaphone className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl md:text-3xl font-black text-slate-900 dark:text-white tracking-tight font-display">
                Tablón de Avisos
              </h1>
              <span className="px-2.5 py-0.5 bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-900 text-[10px] font-black rounded-full uppercase tracking-wider">
                Colegio Litterator
              </span>
            </div>
            <p className="text-slate-500 dark:text-slate-400 text-xs md:text-sm mt-0.5">
              Comunicados oficiales, cambios de horario, eventos escolares y avisos urgentes.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-bold text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-900 px-4 py-2.5 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm self-start sm:self-auto">
          <BellRing className="w-4 h-4 text-indigo-600 dark:text-indigo-400 animate-pulse" />
          <span>{allAnnouncements.length} avisos</span>
        </div>
      </header>

      {/* Featured Banner if active */}
      {featuredAnnouncement && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className={cn(
            "p-6 md:p-8 rounded-[32px] border relative overflow-hidden shadow-lg shadow-indigo-500/5",
            featuredAnnouncement.priority === 'alert'
              ? "bg-gradient-to-br from-rose-600 to-red-700 text-white border-rose-500"
              : featuredAnnouncement.priority === 'important'
              ? "bg-gradient-to-br from-amber-500 to-orange-600 text-white border-amber-400"
              : "bg-gradient-to-br from-indigo-600 via-indigo-700 to-slate-900 text-white border-indigo-500"
          )}
        >
          <div className="relative z-10">
            <div className="flex flex-wrap items-center gap-2.5 mb-3">
              <span className="px-3 py-1 bg-white/20 backdrop-blur-md rounded-xl text-xs font-black uppercase tracking-wider text-white">
                {featuredAnnouncement.priority === 'alert' ? '🔴 Urgente' : featuredAnnouncement.priority === 'important' ? '🟡 Importante' : '🔵 Comunicado'}
              </span>
              <span className="text-xs text-white/80 font-bold flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5" />
                {featuredAnnouncement.date}
              </span>
              <span className="text-xs text-white/80 font-bold ml-auto flex items-center gap-1">
                <School className="w-3.5 h-3.5" />
                {featuredAnnouncement.author || 'Dirección Litterator'}
              </span>
            </div>

            <h2 className="text-2xl md:text-3xl font-black font-display tracking-tight mb-3">
              {featuredAnnouncement.title}
            </h2>

            <p className="text-sm md:text-base leading-relaxed text-white/95 whitespace-pre-line max-w-4xl">
              {featuredAnnouncement.message}
            </p>
          </div>
        </motion.div>
      )}

      {/* Filters & Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm">
        {/* Search */}
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            placeholder="Buscar avisos o comunicados..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-2xl pl-10 pr-4 py-2.5 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
          />
        </div>

        {/* Priority Filter */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 scrollbar-hide">
          <button
            onClick={() => setFilterPriority('all')}
            className={cn(
              "px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap",
              filterPriority === 'all'
                ? "bg-slate-900 dark:bg-indigo-600 text-white shadow-sm"
                : "bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700"
            )}
          >
            Todos
          </button>
          <button
            onClick={() => setFilterPriority('alert')}
            className={cn(
              "px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5",
              filterPriority === 'alert'
                ? "bg-rose-600 text-white shadow-sm"
                : "bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 hover:bg-rose-100"
            )}
          >
            <span className="w-2 h-2 rounded-full bg-rose-500" />
            Urgentes
          </button>
          <button
            onClick={() => setFilterPriority('important')}
            className={cn(
              "px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5",
              filterPriority === 'important'
                ? "bg-amber-500 text-white shadow-sm"
                : "bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 hover:bg-amber-100"
            )}
          >
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            Importantes
          </button>
          <button
            onClick={() => setFilterPriority('info')}
            className={cn(
              "px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5",
              filterPriority === 'info'
                ? "bg-indigo-600 text-white shadow-sm"
                : "bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100"
            )}
          >
            <span className="w-2 h-2 rounded-full bg-indigo-500" />
            Informativos
          </button>
        </div>
      </div>

      {/* Announcements List */}
      <div className="space-y-4">
        {filteredAnnouncements.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-dashed border-slate-200 dark:border-slate-800 p-12 text-center">
            <Megaphone className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-700 dark:text-slate-300">No hay avisos para mostrar</h3>
            <p className="text-xs text-slate-400 mt-1">
              {searchQuery ? 'No se encontraron avisos con ese criterio de búsqueda.' : 'Los comunicados escolares publicados por el centro aparecerán aquí.'}
            </p>
          </div>
        ) : (
          filteredAnnouncements.map((ann, idx) => {
            const isAlert = ann.priority === 'alert';
            const isImportant = ann.priority === 'important';

            return (
              <motion.div
                key={ann.id || idx}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className={cn(
                  "p-6 rounded-3xl border bg-white dark:bg-slate-900 shadow-sm transition-all hover:shadow-md",
                  isAlert 
                    ? "border-rose-200 dark:border-rose-900/60 hover:border-rose-300" 
                    : isImportant 
                    ? "border-amber-200 dark:border-amber-900/60 hover:border-amber-300" 
                    : "border-slate-100 dark:border-slate-800 hover:border-indigo-100 dark:hover:border-slate-700"
                )}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <span className={cn(
                      "px-2.5 py-1 rounded-xl text-[10px] font-black uppercase tracking-wider",
                      isAlert 
                        ? "bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300" 
                        : isImportant 
                        ? "bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300" 
                        : "bg-indigo-100 dark:bg-indigo-950 text-indigo-800 dark:text-indigo-300"
                    )}>
                      {isAlert ? 'Urgente' : isImportant ? 'Importante' : 'Informativo'}
                    </span>
                    <span className="text-xs text-slate-400 font-bold flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {ann.date}
                    </span>
                  </div>

                  <span className="text-xs text-slate-400 font-medium">
                    Emitido por: <strong className="text-slate-700 dark:text-slate-300 font-bold">{ann.author || 'Colegio Litterator'}</strong>
                  </span>
                </div>

                <h3 className="text-lg font-black text-slate-900 dark:text-white font-display tracking-tight mb-2">
                  {ann.title}
                </h3>

                <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                  {ann.message}
                </p>
              </motion.div>
            );
          })
        )}
      </div>
    </div>
  );
}
