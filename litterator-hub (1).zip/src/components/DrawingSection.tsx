import React, { useRef, useState, useEffect } from 'react';
import { 
  Pen, 
  Eraser, 
  Trash2, 
  Download, 
  Undo, 
  Redo, 
  Grid, 
  Circle, 
  Square, 
  Minus, 
  ArrowRight, 
  Type, 
  Highlighter, 
  Paintbrush, 
  Sparkles,
  Check,
  Copy
} from 'lucide-react';
import { cn } from '../lib/utils';

type Tool = 
  | 'pen' 
  | 'highlighter' 
  | 'brush' 
  | 'eraser' 
  | 'line' 
  | 'arrow' 
  | 'rect' 
  | 'rect-fill' 
  | 'circle' 
  | 'circle-fill' 
  | 'text';

type BackgroundType = 'white' | 'grid' | 'lines' | 'dots' | 'chalkboard' | 'dark';

export default function DrawingSection() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  const [currentTool, setCurrentTool] = useState<Tool>('pen');
  const [color, setColor] = useState('#4f46e5');
  const [brushSize, setBrushSize] = useState(3);
  const [opacity, setOpacity] = useState(1);
  const [backgroundType, setBackgroundType] = useState<BackgroundType>('white');
  const [isDrawing, setIsDrawing] = useState(false);
  const [startPos, setStartPos] = useState<{ x: number; y: number } | null>(null);
  const [copiedNotification, setCopiedNotification] = useState(false);

  // Snapshot before starting a shape (for previewing line/rect/circle)
  const [snapshot, setSnapshot] = useState<ImageData | null>(null);

  // History for undo/redo
  const [history, setHistory] = useState<ImageData[]>([]);
  const [historyStep, setHistoryStep] = useState(-1);

  const colors = [
    { name: 'Índigo', hex: '#4f46e5' },
    { name: 'Azul', hex: '#2563eb' },
    { name: 'Cian', hex: '#06b6d4' },
    { name: 'Esmeralda', hex: '#10b981' },
    { name: 'Lima', hex: '#84cc16' },
    { name: 'Amarillo', hex: '#eab308' },
    { name: 'Naranja', hex: '#f97316' },
    { name: 'Rojo', hex: '#ef4444' },
    { name: 'Rosa', hex: '#ec4899' },
    { name: 'Púrpura', hex: '#9333ea' },
    { name: 'Negro', hex: '#0f172a' },
    { name: 'Gris', hex: '#64748b' },
    { name: 'Blanco', hex: '#ffffff' },
  ];

  const sizePresets = [
    { label: 'Fino', size: 2 },
    { label: 'Medio', size: 5 },
    { label: 'Grueso', size: 10 },
    { label: 'Extra', size: 20 },
  ];

  // Helper to save history
  const saveHistoryState = (canvas: HTMLCanvasElement) => {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    try {
      const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
      setHistory(prev => {
        const newHistory = prev.slice(0, historyStep + 1);
        newHistory.push(data);
        if (newHistory.length > 25) newHistory.shift();
        return newHistory;
      });
      setHistoryStep(prev => Math.min(prev + 1, 24));
    } catch (e) {
      console.error(e);
    }
  };

  // Resize canvas and init
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const resizeCanvas = () => {
      const ctx = canvas.getContext('2d');
      let imgData: ImageData | null = null;
      if (ctx && canvas.width > 0 && canvas.height > 0) {
        try {
          imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        } catch (e) {
          // ignore
        }
      }

      const rect = container.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;

      canvas.width = rect.width;
      canvas.height = rect.height;

      if (ctx) {
        if (imgData) {
          ctx.putImageData(imgData, 0, 0);
        } else {
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          saveHistoryState(canvas);
        }
      }
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    return () => window.removeEventListener('resize', resizeCanvas);
  }, []);

  const undo = () => {
    if (historyStep > 0) {
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');
      if (!canvas || !ctx) return;
      const prevStep = historyStep - 1;
      ctx.putImageData(history[prevStep], 0, 0);
      setHistoryStep(prevStep);
    }
  };

  const redo = () => {
    if (historyStep < history.length - 1) {
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');
      if (!canvas || !ctx) return;
      const nextStep = historyStep + 1;
      ctx.putImageData(history[nextStep], 0, 0);
      setHistoryStep(nextStep);
    }
  };

  const getCoordinates = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    if ('touches' in e) {
      const touch = e.touches[0] || e.changedTouches[0];
      return {
        x: (touch.clientX - rect.left) * scaleX,
        y: (touch.clientY - rect.top) * scaleY
      };
    }
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY
    };
  };

  const handleStart = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const coords = getCoordinates(e);
    setStartPos(coords);
    setIsDrawing(true);

    if (currentTool === 'text') {
      const text = window.prompt('Introduce el texto a escribir en la pizarra:');
      if (text) {
        ctx.globalCompositeOperation = 'source-over';
        ctx.font = `bold ${Math.max(brushSize * 4, 16)}px sans-serif`;
        ctx.fillStyle = color;
        ctx.globalAlpha = opacity;
        ctx.fillText(text, coords.x, coords.y);
        saveHistoryState(canvas);
      }
      setIsDrawing(false);
      return;
    }

    // Save snapshot for shapes preview
    setSnapshot(ctx.getImageData(0, 0, canvas.width, canvas.height));

    ctx.beginPath();
    ctx.moveTo(coords.x, coords.y);

    if (['pen', 'brush', 'highlighter', 'eraser'].includes(currentTool)) {
      applyContextStyles(ctx);
      ctx.lineTo(coords.x, coords.y);
      ctx.stroke();
    }
  };

  const applyContextStyles = (ctx: CanvasRenderingContext2D) => {
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (currentTool === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.strokeStyle = 'rgba(0,0,0,1)';
      ctx.lineWidth = brushSize * 2.5;
      ctx.globalAlpha = 1;
    } else if (currentTool === 'highlighter') {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = color;
      ctx.lineWidth = brushSize * 3;
      ctx.globalAlpha = 0.35 * opacity;
    } else if (currentTool === 'brush') {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = color;
      ctx.lineWidth = brushSize * 2;
      ctx.globalAlpha = opacity;
    } else {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = color;
      ctx.lineWidth = brushSize;
      ctx.globalAlpha = opacity;
    }
  };

  const handleMove = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !startPos) return;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    if ('touches' in e) e.preventDefault();

    const currentCoords = getCoordinates(e);

    if (['pen', 'brush', 'highlighter', 'eraser'].includes(currentTool)) {
      applyContextStyles(ctx);
      ctx.lineTo(currentCoords.x, currentCoords.y);
      ctx.stroke();
    } else if (snapshot) {
      // Restore previous state to draw dynamic preview
      ctx.putImageData(snapshot, 0, 0);
      applyContextStyles(ctx);

      const dx = currentCoords.x - startPos.x;
      const dy = currentCoords.y - startPos.y;

      if (currentTool === 'line') {
        ctx.beginPath();
        ctx.moveTo(startPos.x, startPos.y);
        ctx.lineTo(currentCoords.x, currentCoords.y);
        ctx.stroke();
      } else if (currentTool === 'arrow') {
        ctx.beginPath();
        ctx.moveTo(startPos.x, startPos.y);
        ctx.lineTo(currentCoords.x, currentCoords.y);
        ctx.stroke();

        // Draw arrow head
        const headlen = Math.max(12, brushSize * 3);
        const angle = Math.atan2(dy, dx);
        ctx.beginPath();
        ctx.moveTo(currentCoords.x, currentCoords.y);
        ctx.lineTo(currentCoords.x - headlen * Math.cos(angle - Math.PI / 6), currentCoords.y - headlen * Math.sin(angle - Math.PI / 6));
        ctx.moveTo(currentCoords.x, currentCoords.y);
        ctx.lineTo(currentCoords.x - headlen * Math.cos(angle + Math.PI / 6), currentCoords.y - headlen * Math.sin(angle + Math.PI / 6));
        ctx.stroke();
      } else if (currentTool === 'rect') {
        ctx.beginPath();
        ctx.strokeRect(startPos.x, startPos.y, dx, dy);
      } else if (currentTool === 'rect-fill') {
        ctx.fillStyle = color;
        ctx.fillRect(startPos.x, startPos.y, dx, dy);
      } else if (currentTool === 'circle') {
        ctx.beginPath();
        const radiusX = Math.abs(dx / 2);
        const radiusY = Math.abs(dy / 2);
        const centerX = startPos.x + dx / 2;
        const centerY = startPos.y + dy / 2;
        ctx.ellipse(centerX, centerY, radiusX, radiusY, 0, 0, 2 * Math.PI);
        ctx.stroke();
      } else if (currentTool === 'circle-fill') {
        ctx.beginPath();
        const radiusX = Math.abs(dx / 2);
        const radiusY = Math.abs(dy / 2);
        const centerX = startPos.x + dx / 2;
        const centerY = startPos.y + dy / 2;
        ctx.fillStyle = color;
        ctx.ellipse(centerX, centerY, radiusX, radiusY, 0, 0, 2 * Math.PI);
        ctx.fill();
      }
    }
  };

  const handleEnd = () => {
    if (isDrawing) {
      setIsDrawing(false);
      setStartPos(null);
      setSnapshot(null);
      const canvas = canvasRef.current;
      if (canvas) {
        saveHistoryState(canvas);
      }
    }
  };

  const clearCanvas = () => {
    if (window.confirm('¿Quieres limpiar todo lo dibujado en la pizarra?')) {
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');
      if (!canvas || !ctx) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      saveHistoryState(canvas);
    }
  };

  // Render combined canvas for export or copy
  const createExportCanvas = (): HTMLCanvasElement | null => {
    const canvas = canvasRef.current;
    if (!canvas) return null;

    const exportCanvas = document.createElement('canvas');
    exportCanvas.width = canvas.width;
    exportCanvas.height = canvas.height;
    const ctx = exportCanvas.getContext('2d');
    if (!ctx) return null;

    // Fill background
    if (backgroundType === 'chalkboard') {
      ctx.fillStyle = '#064e3b'; // dark chalkboard green
      ctx.fillRect(0, 0, exportCanvas.width, exportCanvas.height);
    } else if (backgroundType === 'dark') {
      ctx.fillStyle = '#0f172a'; // slate 900
      ctx.fillRect(0, 0, exportCanvas.width, exportCanvas.height);
    } else {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, exportCanvas.width, exportCanvas.height);
    }

    // Pattern for grid/lines/dots
    if (backgroundType === 'grid') {
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 1;
      const step = 30;
      for (let x = 0; x <= exportCanvas.width; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, exportCanvas.height);
        ctx.stroke();
      }
      for (let y = 0; y <= exportCanvas.height; y += step) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(exportCanvas.width, y);
        ctx.stroke();
      }
    } else if (backgroundType === 'lines') {
      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 1;
      const step = 28;
      for (let y = 40; y <= exportCanvas.height; y += step) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(exportCanvas.width, y);
        ctx.stroke();
      }
    }

    // Draw drawing layer
    ctx.drawImage(canvas, 0, 0);
    return exportCanvas;
  };

  const downloadCanvas = () => {
    const exportCanvas = createExportCanvas();
    if (!exportCanvas) return;

    const url = exportCanvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = `pizarra-litterator-${new Date().toISOString().slice(0, 10)}.png`;
    a.click();
  };

  const copyCanvas = async () => {
    const exportCanvas = createExportCanvas();
    if (!exportCanvas) return;

    try {
      exportCanvas.toBlob(async (blob) => {
        if (!blob) return;
        await navigator.clipboard.write([
          new ClipboardItem({ 'image/png': blob })
        ]);
        setCopiedNotification(true);
        setTimeout(() => setCopiedNotification(false), 2500);
      });
    } catch (e) {
      alert('Tu navegador no admite copiar imágenes directamente al portapapeles. Usa "Descargar".');
    }
  };

  // Background styles
  const getContainerBgStyle = () => {
    switch (backgroundType) {
      case 'grid':
        return {
          backgroundColor: '#ffffff',
          backgroundImage: 'linear-gradient(to right, #e2e8f0 1px, transparent 1px), linear-gradient(to bottom, #e2e8f0 1px, transparent 1px)',
          backgroundSize: '32px 32px'
        };
      case 'lines':
        return {
          backgroundColor: '#ffffff',
          backgroundImage: 'linear-gradient(#cbd5e1 1px, transparent 1px)',
          backgroundSize: '100% 28px'
        };
      case 'dots':
        return {
          backgroundColor: '#ffffff',
          backgroundImage: 'radial-gradient(#cbd5e1 2px, transparent 2px)',
          backgroundSize: '24px 24px'
        };
      case 'chalkboard':
        return {
          backgroundColor: '#064e3b',
          backgroundImage: 'radial-gradient(rgba(255,255,255,0.05) 1px, transparent 1px)',
          backgroundSize: '16px 16px'
        };
      case 'dark':
        return {
          backgroundColor: '#0f172a',
          backgroundImage: 'linear-gradient(to right, rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.05) 1px, transparent 1px)',
          backgroundSize: '32px 32px'
        };
      default:
        return { backgroundColor: '#ffffff' };
    }
  };

  const isDarkBg = backgroundType === 'chalkboard' || backgroundType === 'dark';

  return (
    <div className="space-y-6">
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-gradient-to-br from-indigo-500 to-purple-600 text-white rounded-2xl shadow-md shadow-indigo-100">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tight font-display">Pizarra Estudio Pro</h1>
            <p className="text-slate-500 text-sm">Dibuja esquemas, fórmulas, toma notas y resuelve ejercicios.</p>
          </div>
        </div>

        {copiedNotification && (
          <div className="flex items-center gap-2 bg-emerald-50 text-emerald-700 px-4 py-2 rounded-2xl text-xs font-bold border border-emerald-200 animate-fade-in">
            <Check className="w-4 h-4" />
            ¡Copiado al portapapeles!
          </div>
        )}
      </header>

      {/* Main Container */}
      <div className="bg-white p-5 md:p-6 rounded-[32px] border border-slate-100 shadow-xl shadow-slate-200/40 space-y-4">
        
        {/* Top Control Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-100">
          
          {/* Tool Selector */}
          <div className="flex flex-wrap items-center gap-1 bg-white p-1.5 rounded-xl shadow-sm border border-slate-100">
            <button
              onClick={() => setCurrentTool('pen')}
              className={cn("p-2 rounded-lg transition-all", currentTool === 'pen' ? "bg-indigo-600 text-white shadow-sm" : "text-slate-500 hover:text-slate-900 hover:bg-slate-50")}
              title="Lápiz fino"
            >
              <Pen className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentTool('highlighter')}
              className={cn("p-2 rounded-lg transition-all", currentTool === 'highlighter' ? "bg-indigo-600 text-white shadow-sm" : "text-slate-500 hover:text-slate-900 hover:bg-slate-50")}
              title="Subrayador fluorescente"
            >
              <Highlighter className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentTool('brush')}
              className={cn("p-2 rounded-lg transition-all", currentTool === 'brush' ? "bg-indigo-600 text-white shadow-sm" : "text-slate-500 hover:text-slate-900 hover:bg-slate-50")}
              title="Pincel"
            >
              <Paintbrush className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentTool('eraser')}
              className={cn("p-2 rounded-lg transition-all", currentTool === 'eraser' ? "bg-indigo-600 text-white shadow-sm" : "text-slate-500 hover:text-slate-900 hover:bg-slate-50")}
              title="Goma de borrar"
            >
              <Eraser className="w-4 h-4" />
            </button>

            <div className="w-px h-5 bg-slate-200 mx-1" />

            {/* Shapes */}
            <button
              onClick={() => setCurrentTool('line')}
              className={cn("p-2 rounded-lg transition-all", currentTool === 'line' ? "bg-indigo-600 text-white shadow-sm" : "text-slate-500 hover:text-slate-900 hover:bg-slate-50")}
              title="Línea recta"
            >
              <Minus className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentTool('arrow')}
              className={cn("p-2 rounded-lg transition-all", currentTool === 'arrow' ? "bg-indigo-600 text-white shadow-sm" : "text-slate-500 hover:text-slate-900 hover:bg-slate-50")}
              title="Flecha"
            >
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentTool('rect')}
              className={cn("p-2 rounded-lg transition-all", currentTool === 'rect' ? "bg-indigo-600 text-white shadow-sm" : "text-slate-500 hover:text-slate-900 hover:bg-slate-50")}
              title="Rectángulo contorno"
            >
              <Square className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentTool('rect-fill')}
              className={cn("p-2 rounded-lg transition-all", currentTool === 'rect-fill' ? "bg-indigo-600 text-white shadow-sm" : "text-slate-500 hover:text-slate-900 hover:bg-slate-50")}
              title="Rectángulo sólido"
            >
              <div className="w-4 h-4 bg-current rounded-sm" />
            </button>
            <button
              onClick={() => setCurrentTool('circle')}
              className={cn("p-2 rounded-lg transition-all", currentTool === 'circle' ? "bg-indigo-600 text-white shadow-sm" : "text-slate-500 hover:text-slate-900 hover:bg-slate-50")}
              title="Círculo contorno"
            >
              <Circle className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentTool('circle-fill')}
              className={cn("p-2 rounded-lg transition-all", currentTool === 'circle-fill' ? "bg-indigo-600 text-white shadow-sm" : "text-slate-500 hover:text-slate-900 hover:bg-slate-50")}
              title="Círculo sólido"
            >
              <div className="w-4 h-4 bg-current rounded-full" />
            </button>
            <button
              onClick={() => setCurrentTool('text')}
              className={cn("p-2 rounded-lg transition-all", currentTool === 'text' ? "bg-indigo-600 text-white shadow-sm" : "text-slate-500 hover:text-slate-900 hover:bg-slate-50")}
              title="Escribir texto"
            >
              <Type className="w-4 h-4" />
            </button>
          </div>

          {/* Background selection */}
          <div className="flex items-center gap-1 bg-white p-1.5 rounded-xl shadow-sm border border-slate-100">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 hidden sm:inline">Fondo</span>
            <button
              onClick={() => setBackgroundType('white')}
              className={cn("px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all", backgroundType === 'white' ? "bg-slate-900 text-white" : "text-slate-600 hover:bg-slate-100")}
              title="Liso blanco"
            >
              Blanco
            </button>
            <button
              onClick={() => setBackgroundType('grid')}
              className={cn("p-2 rounded-lg text-xs font-bold transition-all", backgroundType === 'grid' ? "bg-slate-900 text-white" : "text-slate-600 hover:bg-slate-100")}
              title="Cuadrícula"
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setBackgroundType('lines')}
              className={cn("px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all", backgroundType === 'lines' ? "bg-slate-900 text-white" : "text-slate-600 hover:bg-slate-100")}
              title="Rayas libreta"
            >
              Rayas
            </button>
            <button
              onClick={() => setBackgroundType('chalkboard')}
              className={cn("px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all", backgroundType === 'chalkboard' ? "bg-emerald-800 text-white" : "text-emerald-700 hover:bg-emerald-50")}
              title="Pizarra verde"
            >
              Verde
            </button>
            <button
              onClick={() => setBackgroundType('dark')}
              className={cn("px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all", backgroundType === 'dark' ? "bg-slate-900 text-white" : "text-slate-700 hover:bg-slate-100")}
              title="Pizarra oscura"
            >
              Oscura
            </button>
          </div>

          {/* Action Buttons: Undo, Redo, Clear, Download */}
          <div className="flex items-center gap-1 bg-white p-1.5 rounded-xl shadow-sm border border-slate-100 ml-auto">
            <button
              onClick={undo}
              disabled={historyStep <= 0}
              className="p-2 text-slate-500 disabled:opacity-30 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
              title="Deshacer (Ctrl+Z)"
            >
              <Undo className="w-4 h-4" />
            </button>
            <button
              onClick={redo}
              disabled={historyStep >= history.length - 1}
              className="p-2 text-slate-500 disabled:opacity-30 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
              title="Rehacer (Ctrl+Y)"
            >
              <Redo className="w-4 h-4" />
            </button>
            <div className="w-px h-5 bg-slate-200 mx-1" />
            <button
              onClick={clearCanvas}
              className="p-2 text-slate-500 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
              title="Limpiar pizarra"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              onClick={copyCanvas}
              className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
              title="Copiar imagen"
            >
              <Copy className="w-4 h-4" />
            </button>
            <button
              onClick={downloadCanvas}
              className="p-2 bg-indigo-600 text-white hover:bg-indigo-700 rounded-lg transition-all shadow-sm"
              title="Descargar como PNG"
            >
              <Download className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Secondary Tool Bar: Colors, Stroke Size & Opacity */}
        <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-50 px-4 py-2.5 rounded-2xl border border-slate-100">
          {/* Color Palettes */}
          <div className="flex items-center gap-1.5 overflow-x-auto py-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mr-1 hidden sm:inline">Color</span>
            {colors.map(c => (
              <button
                key={c.hex}
                onClick={() => {
                  setColor(c.hex);
                  if (currentTool === 'eraser') setCurrentTool('pen');
                }}
                className={cn(
                  "w-6 h-6 rounded-full transition-all border-2 flex items-center justify-center",
                  color === c.hex && currentTool !== 'eraser' ? "scale-125 border-slate-900 shadow-md" : "border-slate-200 hover:scale-110"
                )}
                style={{ backgroundColor: c.hex }}
                title={c.name}
              >
                {color === c.hex && currentTool !== 'eraser' && (
                  <div className={cn("w-1.5 h-1.5 rounded-full", c.hex === '#ffffff' ? "bg-slate-900" : "bg-white")} />
                )}
              </button>
            ))}

            {/* Custom Color Input */}
            <label className="cursor-pointer ml-1 relative flex items-center" title="Color personalizado">
              <input
                type="color"
                value={color}
                onChange={(e) => {
                  setColor(e.target.value);
                  if (currentTool === 'eraser') setCurrentTool('pen');
                }}
                className="opacity-0 absolute inset-0 w-6 h-6 cursor-pointer"
              />
              <div 
                className="w-6 h-6 rounded-full border-2 border-dashed border-slate-400 flex items-center justify-center hover:scale-110 transition-transform"
                style={{ background: 'conic-gradient(red, yellow, lime, aqua, blue, magenta, red)' }}
              />
            </label>
          </div>

          {/* Stroke Size Presets & Slider */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-100">
              {sizePresets.map(preset => (
                <button
                  key={preset.size}
                  onClick={() => setBrushSize(preset.size)}
                  className={cn(
                    "px-2 py-1 rounded-lg text-[10px] font-bold transition-all",
                    brushSize === preset.size ? "bg-slate-900 text-white" : "text-slate-500 hover:bg-slate-50"
                  )}
                >
                  {preset.label}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2 min-w-[120px]">
              <span className="text-[10px] font-bold text-slate-400">{brushSize}px</span>
              <input
                type="range"
                min="1"
                max="45"
                value={brushSize}
                onChange={(e) => setBrushSize(parseInt(e.target.value))}
                className="w-24 accent-indigo-600 h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer"
              />
            </div>

            {/* Opacity slider */}
            <div className="flex items-center gap-2 min-w-[110px] pl-2 border-l border-slate-200">
              <span className="text-[10px] font-bold text-slate-400">{Math.round(opacity * 100)}%</span>
              <input
                type="range"
                min="0.1"
                max="1"
                step="0.05"
                value={opacity}
                onChange={(e) => setOpacity(parseFloat(e.target.value))}
                className="w-16 accent-indigo-600 h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                title="Opacidad"
              />
            </div>
          </div>
        </div>

        {/* Canvas Area */}
        <div
          ref={containerRef}
          className="border-2 border-slate-200 rounded-3xl overflow-hidden touch-none relative shadow-inner select-none transition-colors"
          style={{
            height: '68vh',
            ...getContainerBgStyle()
          }}
        >
          <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full cursor-crosshair"
            style={{ touchAction: 'none' }}
            onMouseDown={handleStart}
            onMouseMove={handleMove}
            onMouseUp={handleEnd}
            onMouseLeave={handleEnd}
            onTouchStart={handleStart}
            onTouchMove={handleMove}
            onTouchEnd={handleEnd}
            onTouchCancel={handleEnd}
          />

          {/* Quick indicator when chalkboard mode */}
          {isDarkBg && (
            <div className="absolute top-4 right-4 pointer-events-none bg-black/40 text-white/70 px-3 py-1 rounded-full text-xs font-medium backdrop-blur-sm">
              Tiza / Modo Pizarra
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
