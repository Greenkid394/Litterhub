import React, { useState, useEffect } from 'react';
import { MessageSquare, Send, Trash, User } from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, addDoc, query, orderBy, onSnapshot, serverTimestamp, deleteDoc, doc } from 'firebase/firestore';

export default function AdminSupportDashboard() {
  const [messages, setMessages] = useState<any[]>([]);
  const [replyText, setReplyText] = useState('');
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);

  useEffect(() => {
    // Escuchar TODOS los mensajes de soporte para ver a quién responder
    const q = query(collection(db, 'support_messages'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMessages(msgs);
    });
    return () => unsubscribe();
  }, []);

  // Agrupar usuarios que han enviado mensajes
  const usersWithChats = Array.from(new Set(messages.map(m => m.userId))).map(uid => {
    const userMsgs = messages.filter(m => m.userId === uid);
    const email = userMsgs.find(m => m.senderEmail)?.senderEmail || 'Desconocido';
    const lastMsg = userMsgs[0]; // because it's ordered by desc
    return { uid, email, lastMsg };
  });

  const selectedUserMessages = messages.filter(m => m.userId === selectedUserId).reverse();

  const sendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !selectedUserId) return;
    
    try {
      await addDoc(collection(db, 'support_messages'), {
        text: replyText,
        senderEmail: 'Soporte', // El admin responde como 'Soporte'
        userId: selectedUserId, // Mantenemos el hilo con este usuario
        isAdminReply: true,
        createdAt: serverTimestamp(),
      });
      setReplyText('');
    } catch (err) {
      console.error(err);
      alert('Error al enviar respuesta');
    }
  };

  const deleteMsg = async (id: string) => {
    if (window.confirm('¿Borrar este mensaje?')) {
      await deleteDoc(doc(db, 'support_messages', id));
    }
  };

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
            <MessageSquare className="w-6 h-6" />
          </div>
          <h1 className="text-3xl font-bold text-slate-900">Panel de Soporte</h1>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Lista de Chats */}
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm col-span-1 h-[600px] flex flex-col">
          <h2 className="font-bold text-lg text-slate-800 mb-4">Usuarios ({usersWithChats.length})</h2>
          <div className="overflow-y-auto flex-1 space-y-2 pr-2">
            {usersWithChats.length === 0 ? (
              <p className="text-sm text-slate-400">No hay chats activos.</p>
            ) : (
              usersWithChats.map(u => (
                <button
                  key={u.uid}
                  onClick={() => setSelectedUserId(u.uid as string)}
                  className={`w-full text-left p-4 rounded-2xl border transition-all ${
                    selectedUserId === u.uid 
                      ? 'border-indigo-500 bg-indigo-50' 
                      : 'border-slate-100 hover:border-indigo-200'
                  }`}
                >
                  <p className="font-bold text-sm text-slate-800 truncate">{u.email}</p>
                  <p className="text-xs text-slate-500 truncate mt-1">
                    {u.lastMsg.isAdminReply ? 'Tú: ' : ''}{u.lastMsg.text}
                  </p>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Chat Activo */}
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm col-span-1 lg:col-span-2 h-[600px] flex flex-col">
          {!selectedUserId ? (
            <div className="flex-1 flex flex-col items-center justify-center text-slate-400">
              <User className="w-16 h-16 mb-4 text-slate-200" />
              <p>Selecciona un usuario para empezar a chatear.</p>
            </div>
          ) : (
            <>
              <div className="mb-4 pb-4 border-b border-slate-100 flex items-center justify-between">
                <h3 className="font-bold text-slate-800">
                  Chat con {usersWithChats.find(u => u.uid === selectedUserId)?.email}
                </h3>
              </div>

              <div className="flex-1 overflow-y-auto space-y-3 pr-2 mb-4">
                {selectedUserMessages.map(msg => {
                  const isSoporte = msg.isAdminReply;
                  return (
                    <div key={msg.id} className={`flex flex-col group ${isSoporte ? 'items-end' : 'items-start'}`}>
                      <div className={`max-w-[80%] p-3 rounded-2xl relative ${isSoporte ? 'bg-indigo-600 text-white rounded-br-none' : 'bg-slate-100 text-slate-800 rounded-bl-none'}`}>
                        <p className="text-sm">{msg.text}</p>
                        <button onClick={() => deleteMsg(msg.id)} className="absolute -top-2 -right-2 p-1 text-red-500 bg-white rounded-full shadow-sm opacity-0 group-hover:opacity-100 transition-opacity">
                          <Trash className="w-3 h-3" />
                        </button>
                      </div>
                      <span className="text-[10px] text-slate-400 mt-1 mx-1">
                        {isSoporte ? 'Tú' : msg.senderEmail}
                      </span>
                    </div>
                  );
                })}
              </div>

              <form onSubmit={sendReply} className="flex gap-2">
                <input
                  type="text"
                  value={replyText}
                  onChange={e => setReplyText(e.target.value)}
                  placeholder="Escribe tu respuesta..."
                  className="flex-1 bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-sm"
                />
                <button type="submit" className="bg-indigo-600 text-white px-5 py-3 rounded-xl hover:bg-indigo-700 transition-colors flex items-center justify-center">
                  <Send className="w-5 h-5" />
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
