import React, { useState, useEffect, useMemo } from 'react';
import { 
  Calendar, 
  Clock, 
  Sparkles,
  Layers,
  FileText,
  Mail,
  Megaphone,
  Utensils,
  MessageSquare,
  ShieldCheck,
  Check,
  AlertCircle,
  Trash2,
  Users,
  BarChart3,
  CalendarDays,
  Download,
  Bell,
  RefreshCw,
  Send,
  Search,
  CheckCircle2,
  ChevronRight,
  Eye,
  User,
  Trash,
  Plus,
  Activity,
  Loader2,
  Upload
} from 'lucide-react';
import { db } from '../lib/firebase';
import { 
  collection, 
  addDoc, 
  query, 
  orderBy, 
  onSnapshot, 
  serverTimestamp, 
  deleteDoc, 
  doc, 
  setDoc, 
  getDoc,
  where,
  getDocs
} from 'firebase/firestore';
import type { WeeklySchedule, SchoolAnnouncement, SchoolCalendarEvent } from '../types';
import { cn } from '../lib/utils';

export default function AdminHub() {
  const [activeSubTab, setActiveSubTab] = useState<
    'schedules' | 'announcements' | 'analytics' | 'menu' | 'chat' | 'calendar' | 'backup'
  >('schedules');

  // Directory and messages state
  const [messages, setMessages] = useState<any[]>([]);
  const [directoryUsers, setDirectoryUsers] = useState<any[]>([]);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const [userSearch, setUserSearch] = useState('');

  // Target schedule upload state
  const [targetStudentUid, setTargetStudentUid] = useState<string>('');
  const [targetStudentEmail, setTargetStudentEmail] = useState<string>('');
  const [isProcessingSchedule, setIsProcessingSchedule] = useState(false);
  const [scheduleSuccess, setScheduleSuccess] = useState<string | null>(null);
  const [scheduleError, setScheduleError] = useState<string | null>(null);
  const [targetUserCurrentSchedule, setTargetUserCurrentSchedule] = useState<WeeklySchedule | null>(null);
  const [loadingTargetSchedule, setLoadingTargetSchedule] = useState(false);

  // Global Announcement state
  const [announcementTitle, setAnnouncementTitle] = useState('');
  const [announcementMessage, setAnnouncementMessage] = useState('');
  const [announcementPriority, setAnnouncementPriority] = useState<'info' | 'important' | 'alert'>('info');
  const [announcementActive, setAnnouncementActive] = useState(true);
  const [savingAnnouncement, setSavingAnnouncement] = useState(false);
  const [currentAnnouncement, setCurrentAnnouncement] = useState<SchoolAnnouncement | null>(null);
  const [allAnnouncements, setAllAnnouncements] = useState<SchoolAnnouncement[]>([]);
  const [deletingAnnouncementId, setDeletingAnnouncementId] = useState<string | null>(null);

  // Menu global state
  const [isProcessingMenu, setIsProcessingMenu] = useState(false);
  const [menuSuccess, setMenuSuccess] = useState<string | null>(null);
  const [menuError, setMenuError] = useState<string | null>(null);
  const [globalMenuData, setGlobalMenuData] = useState<any | null>(null);

  // School Calendar events state (shared_resources/school_calendar)
  const [calendarEvents, setCalendarEvents] = useState<SchoolCalendarEvent[]>([]);
  const [newCalTitle, setNewCalTitle] = useState('');
  const [newCalDate, setNewCalDate] = useState('');
  const [newCalType, setNewCalType] = useState<'festivo' | 'evaluacion' | 'evento' | 'vacaciones'>('festivo');
  const [newCalDesc, setNewCalDesc] = useState('');
  const [savingCalendarEvent, setSavingCalendarEvent] = useState(false);

  // Filter for analytics
  const [analyticsFilter, setAnalyticsFilter] = useState<'all' | 'no_schedule'>('all');

  // Listen to support messages
  useEffect(() => {
    const q = query(collection(db, 'support_messages'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setMessages(msgs);
    });
    return () => unsubscribe();
  }, []);

  // Listen to user directory
  useEffect(() => {
    const q = query(collection(db, 'user_directory'), orderBy('lastActive', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const users = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setDirectoryUsers(users);
    }, (err) => {
      console.warn('Directory read note:', err);
    });
    return () => unsubscribe();
  }, []);

  // Listen to active global announcement
  useEffect(() => {
    const unsubscribe = onSnapshot(doc(db, 'shared_resources', 'announcement'), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data() as SchoolAnnouncement;
        setCurrentAnnouncement(data);
        if (!announcementTitle) {
          setAnnouncementTitle(data.title || '');
          setAnnouncementMessage(data.message || '');
          setAnnouncementPriority(data.priority || 'info');
          setAnnouncementActive(Boolean(data.active));
        }
      } else {
        setCurrentAnnouncement(null);
      }
    });
    return () => unsubscribe();
  }, []);

  // Listen to announcements collection (history)
  useEffect(() => {
    const q = query(collection(db, 'announcements'), orderBy('date', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as SchoolAnnouncement));
      setAllAnnouncements(list);
    }, (err) => {
      console.warn('Announcements collection note:', err);
    });
    return () => unsubscribe();
  }, []);

  // Listen to global menu
  useEffect(() => {
    const unsubscribe = onSnapshot(doc(db, 'shared_resources', 'menu'), (docSnap) => {
      if (docSnap.exists()) {
        setGlobalMenuData(docSnap.data());
      }
    });
    return () => unsubscribe();
  }, []);

  // Listen to school calendar events
  useEffect(() => {
    const unsubscribe = onSnapshot(doc(db, 'shared_resources', 'school_calendar'), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        setCalendarEvents(data.events || []);
      }
    });
    return () => unsubscribe();
  }, []);

  // Helper to reliably resolve user email
  const getUserEmail = (uid: string, fallback?: string): string => {
    if (fallback && fallback.includes('@') && fallback !== 'Soporte' && fallback !== 'Soporte Automático') {
      return fallback;
    }
    const dirUser = directoryUsers.find(u => (u.id || u.uid) === uid);
    if (dirUser?.email && dirUser.email.includes('@')) {
      return dirUser.email;
    }
    const userMsg = messages.find(m => m.userId === uid && m.senderEmail && m.senderEmail.includes('@') && !m.isAdminReply);
    if (userMsg?.senderEmail) {
      return userMsg.senderEmail;
    }
    return `alumno_${uid.slice(0, 8)}@colegiolitterator.com`;
  };

  // Aggregate users from messages & directory
  const allKnownUsers = useMemo(() => {
    const map = new Map<string, { uid: string; email: string; lastSeen?: any; hasSchedule?: boolean }>();

    // From directory
    directoryUsers.forEach(u => {
      const uid = u.id || u.uid;
      if (uid) {
        const resolvedEmail = u.email && u.email.includes('@') ? u.email : getUserEmail(uid, u.email);
        map.set(uid, {
          uid,
          email: resolvedEmail,
          lastSeen: u.lastActive,
          hasSchedule: Boolean(u.hasSchedule)
        });
      }
    });

    // From messages
    messages.forEach(m => {
      if (m.userId && !map.has(m.userId)) {
        map.set(m.userId, {
          uid: m.userId,
          email: getUserEmail(m.userId, m.senderEmail),
        });
      }
    });

    return Array.from(map.values());
  }, [directoryUsers, messages]);

  const filteredUsers = allKnownUsers.filter(u => 
    u.email.toLowerCase().includes(userSearch.toLowerCase()) || 
    u.uid.toLowerCase().includes(userSearch.toLowerCase())
  );

  // Fetch target user's current schedule when selected
  const handleSelectStudentForSchedule = async (uid: string, email: string) => {
    const exactEmail = getUserEmail(uid, email);
    setTargetStudentUid(uid);
    setTargetStudentEmail(exactEmail);
    setScheduleSuccess(null);
    setScheduleError(null);
    setLoadingTargetSchedule(true);

    try {
      const docRef = doc(db, 'users', uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data();
        setTargetUserCurrentSchedule(data.schedule || null);
      } else {
        setTargetUserCurrentSchedule(null);
      }
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoadingTargetSchedule(false);
    }
  };

  // Upload schedule PDF for selected student
  const handleScheduleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !targetStudentUid) return;

    setIsProcessingSchedule(true);
    setScheduleError(null);
    setScheduleSuccess(null);

    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64 = (event.target?.result as string).split(',')[1];
      try {
        const response = await fetch('/api/process-schedule', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pdfBase64: base64 }),
        });

        if (!response.ok) {
          const errData = await response.json().catch(() => ({}));
          throw new Error(errData.error || 'Error en el servidor al procesar el horario.');
        }

        const parsedSchedule = await response.json();
        const studentDocRef = doc(db, 'users', targetStudentUid);
        const exactTargetEmail = targetStudentEmail || getUserEmail(targetStudentUid);

        await setDoc(studentDocRef, { schedule: parsedSchedule, email: exactTargetEmail }, { merge: true });
        await setDoc(doc(db, 'user_directory', targetStudentUid), { hasSchedule: true }, { merge: true });

        setTargetUserCurrentSchedule(parsedSchedule);
        setScheduleSuccess(`✅ Horario cargado exitosamente para el alumno: ${exactTargetEmail}`);
      } catch (err: any) {
        console.error(err);
        setScheduleError(err.message || 'Error al procesar el horario.');
      } finally {
        setIsProcessingSchedule(false);
      }
    };
    reader.readAsDataURL(file);
  };

  // Assign instant template schedule
  const assignTemplateSchedule = async (type: 'eso' | 'bach' | 'primaria', studentUid?: string, studentEmail?: string) => {
    const uid = studentUid || targetStudentUid;
    if (!uid) return;

    setIsProcessingSchedule(true);
    setScheduleError(null);
    setScheduleSuccess(null);

    const isBach = type === 'bach';
    const isPrimaria = type === 'primaria';

    const subjects = isBach
      ? ["Matemáticas II", "Lengua Castellana y Literatura II", "Inglés II", "Historia de España", "Física / Química", "Filosofía"]
      : isPrimaria
      ? ["Matemáticas", "Lengua Castellana", "Inglés", "Ciencias Naturales", "Ciencias Sociales", "Educación Física", "Educación Artística"]
      : ["Matemáticas", "Lengua Castellana", "Inglés", "Geografía e Historia", "Biología y Geología", "Educación Física", "Física y Química", "Tecnología", "Música", "Tutoría"];

    const slots = [
      { startTime: "08:30", endTime: "09:25" },
      { startTime: "09:25", endTime: "10:20" },
      { startTime: "10:20", endTime: "11:15" },
      { startTime: "11:45", endTime: "12:40" },
      { startTime: "12:40", endTime: "13:35" },
      { startTime: "13:35", endTime: "14:30" },
    ];

    const days = [1, 2, 3, 4, 5].map(dayOfWeek => ({
      dayOfWeek,
      classes: slots.map((slot, idx) => ({
        startTime: slot.startTime,
        endTime: slot.endTime,
        subject: subjects[(dayOfWeek * 2 + idx) % subjects.length],
        room: `Aula ${dayOfWeek}`
      }))
    }));

    const templateSchedule: WeeklySchedule = { days };
    const targetEmail = studentEmail || targetStudentEmail || getUserEmail(uid);

    try {
      const studentDocRef = doc(db, 'users', uid);
      await setDoc(studentDocRef, { schedule: templateSchedule, email: targetEmail }, { merge: true });
      await setDoc(doc(db, 'user_directory', uid), { hasSchedule: true }, { merge: true });

      if (uid === targetStudentUid) {
        setTargetUserCurrentSchedule(templateSchedule);
      }
      setScheduleSuccess(`✅ Horario (${type.toUpperCase()}) asignado exitosamente a ${targetEmail}`);
    } catch (err: any) {
      console.error(err);
      setScheduleError(err.message || 'Error al asignar la plantilla.');
    } finally {
      setIsProcessingSchedule(false);
    }
  };

  // Global Menu upload
  const handleGlobalMenuUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingMenu(true);
    setMenuError(null);
    setMenuSuccess(null);

    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64 = (event.target?.result as string).split(',')[1];
      try {
        const response = await fetch('/api/process-menu', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pdfBase64: base64 }),
        });

        if (!response.ok) {
          const errData = await response.json().catch(() => ({}));
          throw new Error(errData.error || 'Error procesando el menú escolar.');
        }

        const parsedMenu = await response.json();
        await setDoc(doc(db, 'shared_resources', 'menu'), parsedMenu);
        setGlobalMenuData(parsedMenu);
        setMenuSuccess(`✅ Menú de ${parsedMenu.month} ${parsedMenu.year} publicado con éxito.`);
      } catch (err: any) {
        console.error(err);
        setMenuError(err.message || 'Error al publicar el menú global.');
      } finally {
        setIsProcessingMenu(false);
      }
    };
    reader.readAsDataURL(file);
  };

  // Save school announcement
  const handleSaveAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!announcementTitle.trim() || !announcementMessage.trim()) return;

    setSavingAnnouncement(true);
    try {
      const announcementData: SchoolAnnouncement = {
        title: announcementTitle.trim(),
        message: announcementMessage.trim(),
        priority: announcementPriority,
        active: announcementActive,
        date: new Date().toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' }),
        author: 'DesarrolloHub / Dirección Litterator'
      };

      // 1. Save to shared_resources for active banner
      await setDoc(doc(db, 'shared_resources', 'announcement'), announcementData);

      // 2. Save to announcements collection for permanent board
      await addDoc(collection(db, 'announcements'), {
        ...announcementData,
        createdAt: serverTimestamp()
      });

      setCurrentAnnouncement(announcementData);
      alert('¡Aviso escolar publicado con éxito!');
    } catch (err) {
      console.error(err);
      alert('Error guardando el anuncio escolar.');
    } finally {
      setSavingAnnouncement(false);
    }
  };

  // Quick announcement templates
  const applyTemplate = (type: 'nieve' | 'festivo' | 'examenes' | 'reunion') => {
    if (type === 'nieve') {
      setAnnouncementTitle('Aviso Meteorológico: Suspensión de clases presenciales');
      setAnnouncementMessage('Debido a las fuertes nevadas y heladas en la comarca de Aranjuez, las clases presenciales quedan suspendidas durante el día de hoy. Las actividades continuarán de forma telemática.');
      setAnnouncementPriority('alert');
    } else if (type === 'festivo') {
      setAnnouncementTitle('Festivo Escolar: Próximo día no lectivo');
      setAnnouncementMessage('Recordamos a toda la comunidad educativa del Colegio Litterator que el próximo viernes es festivo local. No habrá actividad lectiva ni servicio de comedor.');
      setAnnouncementPriority('info');
    } else if (type === 'examenes') {
      setAnnouncementTitle('Periodo de Evaluaciones Trimestrales');
      setAnnouncementMessage('La próxima semana inician los exámenes trimestrales. Por favor revisad el calendario de vuestro curso y recordad llegar con puntualidad a las aulas asignadas.');
      setAnnouncementPriority('important');
    } else if (type === 'reunion') {
      setAnnouncementTitle('Reunión Informativa con Familias');
      setAnnouncementMessage('Convocatoria para la reunión general con los tutores de grupo el próximo jueves a las 17:30h en el salón de actos del colegio.');
      setAnnouncementPriority('info');
    }
    setAnnouncementActive(true);
  };

  // FEATURE: Delete active announcement
  const handleClearActiveAnnouncement = async () => {
    if (!window.confirm('¿Deseas retirar el aviso activo del inicio de los alumnos?')) return;
    try {
      await deleteDoc(doc(db, 'shared_resources', 'announcement'));
      setCurrentAnnouncement(null);
      setAnnouncementActive(false);
      alert('Aviso activo retirado del inicio.');
    } catch (err: any) {
      console.error(err);
      alert('Error al retirar aviso: ' + err.message);
    }
  };

  // FEATURE: Delete any announcement from historical board
  const handleDeleteAnnouncement = async (announcementId?: string, title?: string) => {
    if (!window.confirm('¿Estás seguro de eliminar este aviso permanentemente?')) return;
    setDeletingAnnouncementId(announcementId || 'active');

    try {
      if (announcementId) {
        await deleteDoc(doc(db, 'announcements', announcementId));
      }
      // If matches active announcement title, remove it from shared_resources too
      if (currentAnnouncement && (currentAnnouncement.title === title || !announcementId)) {
        await deleteDoc(doc(db, 'shared_resources', 'announcement'));
        setCurrentAnnouncement(null);
      }
      alert('Aviso eliminado correctamente de la base de datos.');
    } catch (err: any) {
      console.error(err);
      alert('Error al eliminar el aviso.');
    } finally {
      setDeletingAnnouncementId(null);
    }
  };

  // School Calendar: Add event
  const handleAddCalendarEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCalTitle.trim() || !newCalDate) return;
    setSavingCalendarEvent(true);

    try {
      const newEvent: SchoolCalendarEvent = {
        id: `cal-${Date.now()}`,
        title: newCalTitle.trim(),
        date: newCalDate,
        type: newCalType,
        description: newCalDesc.trim() || undefined
      };

      const updated = [...calendarEvents, newEvent].sort((a, b) => a.date.localeCompare(b.date));
      await setDoc(doc(db, 'shared_resources', 'school_calendar'), { events: updated });
      setCalendarEvents(updated);
      setNewCalTitle('');
      setNewCalDate('');
      setNewCalDesc('');
      alert('Evento añadido al calendario oficial de todos los alumnos.');
    } catch (err) {
      console.error(err);
      alert('Error guardando evento.');
    } finally {
      setSavingCalendarEvent(false);
    }
  };

  // School Calendar: Delete event
  const handleDeleteCalendarEvent = async (eventId: string) => {
    if (!window.confirm('¿Eliminar este evento del calendario escolar?')) return;
    try {
      const updated = calendarEvents.filter(e => e.id !== eventId);
      await setDoc(doc(db, 'shared_resources', 'school_calendar'), { events: updated });
      setCalendarEvents(updated);
    } catch (err) {
      console.error(err);
    }
  };

  // Export full system backup (JSON)
  const handleDownloadBackup = () => {
    const backupData = {
      exportedAt: new Date().toISOString(),
      school: "Colegio Litterator Aranjuez",
      totalUsersDetected: allKnownUsers.length,
      users: allKnownUsers,
      activeAnnouncement: currentAnnouncement,
      announcementsHistory: allAnnouncements,
      schoolCalendarEvents: calendarEvents,
      globalMenu: globalMenuData
    };

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backupData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `litterator_backup_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Chat actions
  const usersWithChats = Array.from(new Set(messages.map(m => m.userId as string).filter(Boolean))).map((uid: string) => {
    const userMsgs = messages.filter(m => m.userId === uid);
    const email = getUserEmail(uid);
    const lastMsg = userMsgs[0];
    return { uid, email, lastMsg };
  });

  const selectedUserMessages = messages.filter(m => m.userId === selectedUserId).reverse();

  const sendReply = async (textToSend?: string) => {
    const content = textToSend || replyText;
    if (!content.trim() || !selectedUserId) return;
    
    try {
      await addDoc(collection(db, 'support_messages'), {
        text: content.trim(),
        senderEmail: 'Desarrollo Hub',
        userId: selectedUserId,
        isAdminReply: true,
        createdAt: serverTimestamp(),
      });
      if (!textToSend) setReplyText('');
    } catch (err) {
      console.error(err);
      alert('Error al enviar respuesta');
    }
  };

  const deleteMsg = async (id: string) => {
    if (window.confirm('¿Borrar este mensaje?')) {
      await deleteDoc(doc(db, 'support_messages', id));
    }
  };

  const handleClearConversation = async () => {
    if (!selectedUserId) return;
    if (!window.confirm('¿Deseas vaciar todos los mensajes de esta conversación?')) return;
    try {
      const msgsToDelete = messages.filter(m => m.userId === selectedUserId);
      for (const m of msgsToDelete) {
        await deleteDoc(doc(db, 'support_messages', m.id));
      }
      alert('Conversación limpiada.');
    } catch (err) {
      console.error(err);
      alert('Error al limpiar mensajes.');
    }
  };

  return (
    <div className="space-y-6 md:space-y-8">
      {/* Header */}
      <header className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-gradient-to-br from-indigo-600 to-slate-900 text-white rounded-2xl shadow-lg shadow-indigo-100 dark:shadow-none">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl md:text-3xl font-black text-slate-900 dark:text-white tracking-tight font-display">
                Desarrollo Hub
              </h1>
              <span className="px-2.5 py-0.5 bg-indigo-600 text-white text-[10px] font-black rounded-full uppercase tracking-wider">
                Admin Center
              </span>
            </div>
            <p className="text-slate-500 dark:text-slate-400 text-xs md:text-sm">
              Panel institucional y de control para el Colegio Litterator.
            </p>
          </div>
        </div>

        {/* Sub Navigation */}
        <div className="flex items-center bg-white dark:bg-slate-900 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-x-auto scrollbar-hide">
          {[
            { id: 'schedules', label: 'Horarios', icon: Calendar },
            { id: 'announcements', label: 'Avisos y Eliminación', icon: Megaphone },
            { id: 'analytics', label: 'Monitor Alumnos', icon: BarChart3 },
            { id: 'calendar', label: 'Calendario Escolar', icon: CalendarDays },
            { id: 'menu', label: 'Menú Masivo', icon: Utensils },
            { id: 'chat', label: 'Soporte y Chat', icon: MessageSquare, badge: usersWithChats.length > 0 },
            { id: 'backup', label: 'Copia Seguridad', icon: Download }
          ].map(tab => {
            const Icon = tab.icon;
            const isSelected = activeSubTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveSubTab(tab.id as any)}
                className={cn(
                  "flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap",
                  isSelected 
                    ? "bg-slate-900 dark:bg-indigo-600 text-white shadow-sm" 
                    : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
                )}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                )}
              </button>
            );
          })}
        </div>
      </header>

      {/* SUBTAB 1: ASIGNAR HORARIOS */}
      {activeSubTab === 'schedules' && (
        <div className="space-y-6">
          <div className="bg-indigo-50/70 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 p-6 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-black text-indigo-950 dark:text-indigo-200 font-display">
                Subida de Horario a Alumno Específico
              </h2>
              <p className="text-indigo-700 dark:text-indigo-400 text-xs md:text-sm mt-1">
                Elige cualquier alumno de la lista y sube su PDF de horario o asígnale una plantilla instantánea.
              </p>
            </div>
            <div className="flex items-center gap-2 bg-white dark:bg-slate-900 px-4 py-2 rounded-2xl shadow-sm border border-indigo-100 dark:border-slate-800 text-xs font-bold text-indigo-900 dark:text-indigo-300">
              <Users className="w-4 h-4 text-indigo-600" />
              <span>{allKnownUsers.length} Alumnos detectados</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left: Search & Select Alumno */}
            <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-4">
              <h3 className="font-bold text-base text-slate-800 dark:text-white">1. Selecciona el Alumno</h3>
              
              <div className="relative">
                <input
                  type="text"
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  placeholder="Buscar por email o ID..."
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-2xl pl-9 pr-4 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              </div>

              <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
                {filteredUsers.map(userItem => {
                  const isSelected = targetStudentUid === userItem.uid;
                  return (
                    <button
                      key={userItem.uid}
                      onClick={() => handleSelectStudentForSchedule(userItem.uid, userItem.email)}
                      className={cn(
                        "w-full text-left p-3 rounded-2xl border transition-all flex items-center justify-between group",
                        isSelected 
                          ? "border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/50 shadow-sm" 
                          : "border-slate-100 dark:border-slate-800 hover:border-indigo-200 bg-white dark:bg-slate-900"
                      )}
                    >
                      <div className="min-w-0 flex-1 pr-2">
                        <div className="flex items-center gap-1.5">
                          <Mail className={cn("w-3.5 h-3.5 flex-shrink-0", isSelected ? "text-indigo-600" : "text-slate-400")} />
                          <p className="font-bold text-xs text-slate-900 dark:text-white truncate">
                            {userItem.email}
                          </p>
                        </div>
                        <p className="text-[10px] text-slate-400 font-mono truncate ml-5">
                          UID: {userItem.uid.slice(0, 10)}...
                        </p>
                      </div>
                      <ChevronRight className={cn("w-4 h-4 flex-shrink-0 transition-transform", isSelected ? "text-indigo-600 translate-x-1" : "text-slate-300 dark:text-slate-600")} />
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Right: Upload & Actions */}
            <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm col-span-1 lg:col-span-2 space-y-6">
              {!targetStudentUid ? (
                <div className="h-64 flex flex-col items-center justify-center text-center text-slate-400">
                  <User className="w-12 h-12 mb-3 text-slate-200 dark:text-slate-700" />
                  <p className="font-bold text-sm text-slate-600 dark:text-slate-300">Selecciona un alumno a la izquierda</p>
                  <p className="text-xs text-slate-400 mt-0.5">Podrás subir su PDF de horario o asignarle una plantilla.</p>
                </div>
              ) : (
                <>
                  <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <span className="text-[10px] font-black uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                        Alumno Seleccionado
                      </span>
                      <p className="font-bold text-slate-900 dark:text-white text-sm mt-0.5 flex items-center gap-1.5">
                        <Mail className="w-4 h-4 text-indigo-500" />
                        <span>{targetStudentEmail}</span>
                      </p>
                      <p className="text-[10px] text-slate-400 font-mono">UID: {targetStudentUid}</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={cn(
                        "px-3 py-1 rounded-xl text-xs font-bold",
                        targetUserCurrentSchedule 
                          ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300" 
                          : "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300"
                      )}>
                        {loadingTargetSchedule ? 'Cargando...' : targetUserCurrentSchedule ? 'Horario Activo' : 'Sin Horario'}
                      </span>
                    </div>
                  </div>

                  {scheduleSuccess && (
                    <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-bold rounded-2xl flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span>{scheduleSuccess}</span>
                    </div>
                  )}

                  {scheduleError && (
                    <div className="p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-200 text-xs font-bold rounded-2xl flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-rose-500" />
                      <span>{scheduleError}</span>
                    </div>
                  )}

                  {/* Upload PDF */}
                  <div className="border-2 border-dashed border-slate-200 dark:border-slate-700 hover:border-indigo-400 rounded-3xl p-8 flex flex-col items-center justify-center text-center group cursor-pointer transition-colors bg-slate-50/50 dark:bg-slate-800/20">
                    {isProcessingSchedule ? (
                      <div className="flex flex-col items-center gap-3">
                        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
                        <p className="text-xs font-bold text-slate-700 dark:text-slate-300">
                          Procesando PDF del horario con IA...
                        </p>
                      </div>
                    ) : (
                      <label className="cursor-pointer flex flex-col items-center gap-2">
                        <div className="p-3.5 bg-indigo-50 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 rounded-2xl group-hover:scale-110 transition-transform">
                          <Upload className="w-6 h-6" />
                        </div>
                        <p className="text-sm font-bold text-slate-800 dark:text-slate-200">
                          Subir PDF oficial del alumno
                        </p>
                        <p className="text-xs text-slate-400">
                          Se procesará y se guardará directamente en su cuenta
                        </p>
                        <input
                          type="file"
                          accept="application/pdf"
                          className="hidden"
                          onChange={handleScheduleUpload}
                        />
                      </label>
                    )}
                  </div>

                  {/* Quick Templates */}
                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block mb-3">
                      Asignación Instantánea de Plantilla (1 Clic)
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <button
                        type="button"
                        onClick={() => assignTemplateSchedule('eso')}
                        disabled={isProcessingSchedule}
                        className="p-3.5 bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 text-slate-800 dark:text-slate-200 hover:text-indigo-600 rounded-2xl text-xs font-bold border border-slate-200 dark:border-slate-700 transition-all text-center"
                      >
                        Plantilla ESO (1º-4º)
                      </button>
                      <button
                        type="button"
                        onClick={() => assignTemplateSchedule('bach')}
                        disabled={isProcessingSchedule}
                        className="p-3.5 bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 text-slate-800 dark:text-slate-200 hover:text-indigo-600 rounded-2xl text-xs font-bold border border-slate-200 dark:border-slate-700 transition-all text-center"
                      >
                        Plantilla Bachillerato (1º-2º)
                      </button>
                      <button
                        type="button"
                        onClick={() => assignTemplateSchedule('primaria')}
                        disabled={isProcessingSchedule}
                        className="p-3.5 bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 text-slate-800 dark:text-slate-200 hover:text-indigo-600 rounded-2xl text-xs font-bold border border-slate-200 dark:border-slate-700 transition-all text-center"
                      >
                        Plantilla Primaria
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 2: GESTOR DE AVISOS Y ELIMINACIÓN */}
      {activeSubTab === 'announcements' && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left: Create Announcement Form */}
            <div className="bg-white dark:bg-slate-900 p-6 md:p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-6">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 rounded-2xl">
                  <Megaphone className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white font-display">
                    Publicar Aviso Oficial
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Aparecerá en el inicio de todos los alumnos en tiempo real.
                  </p>
                </div>
              </div>

              {/* Quick Template Buttons */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                  Plantillas Rápidas:
                </span>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => applyTemplate('nieve')}
                    className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-rose-50 dark:hover:bg-rose-950/40 hover:text-rose-600 text-[11px] font-bold rounded-lg transition-colors"
                  >
                    ❄️ Temporal/Nieve
                  </button>
                  <button
                    type="button"
                    onClick={() => applyTemplate('festivo')}
                    className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 hover:text-indigo-600 text-[11px] font-bold rounded-lg transition-colors"
                  >
                    🎉 Festivo Local
                  </button>
                  <button
                    type="button"
                    onClick={() => applyTemplate('examenes')}
                    className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-amber-50 dark:hover:bg-amber-950/40 hover:text-amber-600 text-[11px] font-bold rounded-lg transition-colors"
                  >
                    📝 Exámenes
                  </button>
                  <button
                    type="button"
                    onClick={() => applyTemplate('reunion')}
                    className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 hover:text-emerald-600 text-[11px] font-bold rounded-lg transition-colors"
                  >
                    👥 Familias
                  </button>
                </div>
              </div>

              <form onSubmit={handleSaveAnnouncement} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                    Título del Aviso *
                  </label>
                  <input
                    type="text"
                    required
                    value={announcementTitle}
                    onChange={(e) => setAnnouncementTitle(e.target.value)}
                    placeholder="Ej. Recordatorio: Festivo escolar el próximo lunes"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                    Mensaje Detallado *
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={announcementMessage}
                    onChange={(e) => setAnnouncementMessage(e.target.value)}
                    placeholder="Escribe las instrucciones para los alumnos..."
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                      Nivel de Importancia
                    </label>
                    <select
                      value={announcementPriority}
                      onChange={(e) => setAnnouncementPriority(e.target.value as any)}
                      className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl px-4 py-3 text-sm font-medium"
                    >
                      <option value="info">🔵 Informativo (Azul)</option>
                      <option value="important">🟡 Importante (Ámbar)</option>
                      <option value="alert">🔴 Urgente / Alerta (Rojo)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                      Estado del Aviso
                    </label>
                    <button
                      type="button"
                      onClick={() => setAnnouncementActive(!announcementActive)}
                      className={cn(
                        "w-full px-4 py-3 rounded-xl text-sm font-bold border transition-all text-left flex items-center justify-between",
                        announcementActive 
                          ? "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800" 
                          : "bg-slate-50 dark:bg-slate-800 text-slate-500 border-slate-200 dark:border-slate-700"
                      )}
                    >
                      <span>{announcementActive ? 'Activo en Inicio' : 'Desactivado'}</span>
                      <span className={cn("w-3 h-3 rounded-full", announcementActive ? "bg-emerald-500" : "bg-slate-400")} />
                    </button>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end">
                  <button
                    type="submit"
                    disabled={savingAnnouncement}
                    className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm rounded-xl shadow-md transition-all flex items-center gap-2"
                  >
                    <Megaphone className="w-4 h-4" />
                    <span>{savingAnnouncement ? 'Guardando...' : 'Publicar a Todos los Alumnos'}</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Right: Active Preview & Clear */}
            <div className="space-y-6">
              <div className="bg-white dark:bg-slate-900 p-6 md:p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Aviso actualmente activo en el inicio
                  </span>
                  {currentAnnouncement && (
                    <button
                      type="button"
                      onClick={handleClearActiveAnnouncement}
                      className="text-xs text-rose-600 dark:text-rose-400 hover:underline font-bold flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Retirar aviso activo</span>
                    </button>
                  )}
                </div>
                
                {currentAnnouncement && currentAnnouncement.active ? (
                  <div className={cn(
                    "p-6 rounded-3xl border relative overflow-hidden transition-all",
                    currentAnnouncement.priority === 'alert' 
                      ? "bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900 text-rose-950 dark:text-rose-100" 
                      : currentAnnouncement.priority === 'important' 
                      ? "bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900 text-amber-950 dark:text-amber-100" 
                      : "bg-indigo-50 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-900 text-indigo-950 dark:text-indigo-100"
                  )}>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className={cn(
                        "px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider",
                        currentAnnouncement.priority === 'alert' ? "bg-rose-600 text-white" : currentAnnouncement.priority === 'important' ? "bg-amber-600 text-white" : "bg-indigo-600 text-white"
                      )}>
                        {currentAnnouncement.priority === 'alert' ? 'Aviso Urgente' : currentAnnouncement.priority === 'important' ? 'Importante' : 'Comunicado'}
                      </span>
                      <span className="text-[10px] opacity-70 font-bold">{currentAnnouncement.date}</span>
                    </div>
                    <h4 className="text-xl font-black font-display tracking-tight mb-2">
                      {currentAnnouncement.title}
                    </h4>
                    <p className="text-sm leading-relaxed opacity-90">
                      {currentAnnouncement.message}
                    </p>
                    <div className="mt-4 pt-3 border-t border-black/5 dark:border-white/10 flex items-center justify-between">
                      <span className="text-[10px] opacity-60 font-bold">
                        {currentAnnouncement.author || 'Dirección Litterator'}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleDeleteAnnouncement(currentAnnouncement.id, currentAnnouncement.title)}
                        className="text-xs text-rose-600 dark:text-rose-400 font-bold hover:underline flex items-center gap-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Eliminar definitivamente</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="p-8 text-center bg-slate-50 dark:bg-slate-800/50 border border-dashed border-slate-200 dark:border-slate-700 rounded-3xl text-slate-400 text-xs">
                    No hay ningún aviso activo en la pantalla de inicio.
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* HISTORIAL COMPLETO DE AVISOS CON BOTÓN DE ELIMINACIÓN */}
          <div className="bg-white dark:bg-slate-900 p-6 md:p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black text-slate-900 dark:text-white font-display">
                  Historial y Gestión de Avisos Publicados ({allAnnouncements.length})
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Puedes borrar cualquier aviso de la base de datos escolar de forma permanente.
                </p>
              </div>
            </div>

            {allAnnouncements.length === 0 ? (
              <p className="text-xs text-slate-400 py-6 text-center">
                No hay avisos en el historial.
              </p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {allAnnouncements.map((item) => (
                  <div 
                    key={item.id || item.title}
                    className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col justify-between space-y-3"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-1.5">
                        <span className={cn(
                          "px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-wider",
                          item.priority === 'alert' ? "bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300" : item.priority === 'important' ? "bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300" : "bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300"
                        )}>
                          {item.priority}
                        </span>
                        <span className="text-[10px] text-slate-400 font-bold">{item.date}</span>
                      </div>
                      <h4 className="font-bold text-sm text-slate-900 dark:text-white">{item.title}</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">{item.message}</p>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
                      <span className="text-[10px] text-slate-400 font-mono">
                        {item.id ? `ID: ${item.id.slice(0, 8)}...` : 'ID automático'}
                      </span>
                      <button
                        type="button"
                        disabled={deletingAnnouncementId === item.id}
                        onClick={() => handleDeleteAnnouncement(item.id, item.title)}
                        className="px-3 py-1.5 bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-300 hover:bg-rose-100 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Eliminar aviso</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 3: MONITOR Y ESTADÍSTICAS DEL ALUMNADO (NUEVA FUNCIÓN ADMIN) */}
      {activeSubTab === 'analytics' && (
        <div className="space-y-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm">
              <div className="p-3 bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 rounded-2xl w-fit mb-3">
                <Users className="w-6 h-6" />
              </div>
              <p className="text-3xl font-black text-slate-900 dark:text-white font-display">
                {allKnownUsers.length}
              </p>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-1">
                Alumnos Registrados
              </p>
            </div>

            <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm">
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 rounded-2xl w-fit mb-3">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <p className="text-3xl font-black text-emerald-600 font-display">
                {allKnownUsers.filter(u => u.hasSchedule).length}
              </p>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-1">
                Con Horario Asignado
              </p>
            </div>

            <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm">
              <div className="p-3 bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 rounded-2xl w-fit mb-3">
                <AlertCircle className="w-6 h-6" />
              </div>
              <p className="text-3xl font-black text-amber-600 font-display">
                {allKnownUsers.filter(u => !u.hasSchedule).length}
              </p>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-1">
                Pendientes de Horario
              </p>
            </div>

            <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm">
              <div className="p-3 bg-pink-50 dark:bg-pink-950 text-pink-600 dark:text-pink-400 rounded-2xl w-fit mb-3">
                <MessageSquare className="w-6 h-6" />
              </div>
              <p className="text-3xl font-black text-pink-600 font-display">
                {usersWithChats.length}
              </p>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-1">
                Chats de Soporte
              </p>
            </div>
          </div>

          {/* Table & Fast Actions */}
          <div className="bg-white dark:bg-slate-900 p-6 md:p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="font-bold text-lg text-slate-900 dark:text-white">
                  Directorio de Cuentas y Asignación Rápida
                </h3>
                <p className="text-xs text-slate-400">
                  Control en tiempo real de los alumnos del Colegio Litterator.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setAnalyticsFilter('all')}
                  className={cn(
                    "px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors",
                    analyticsFilter === 'all' 
                      ? "bg-slate-900 dark:bg-indigo-600 text-white border-transparent" 
                      : "text-slate-500 border-slate-200 dark:border-slate-700"
                  )}
                >
                  Todos ({allKnownUsers.length})
                </button>
                <button
                  type="button"
                  onClick={() => setAnalyticsFilter('no_schedule')}
                  className={cn(
                    "px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors",
                    analyticsFilter === 'no_schedule' 
                      ? "bg-slate-900 dark:bg-indigo-600 text-white border-transparent" 
                      : "text-slate-500 border-slate-200 dark:border-slate-700"
                  )}
                >
                  Sin Horario ({allKnownUsers.filter(u => !u.hasSchedule).length})
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 font-bold uppercase tracking-wider">
                    <th className="pb-3 px-2">Correo del Alumno</th>
                    <th className="pb-3 px-2">Identificador (UID)</th>
                    <th className="pb-3 px-2">Estado Horario</th>
                    <th className="pb-3 px-2 text-right">Acción Rápida</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {allKnownUsers
                    .filter(u => analyticsFilter === 'all' || !u.hasSchedule)
                    .map(u => (
                      <tr key={u.uid} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                        <td className="py-3 px-2 font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                          <Mail className="w-3.5 h-3.5 text-indigo-500" />
                          <span>{u.email}</span>
                        </td>
                        <td className="py-3 px-2 font-mono text-slate-400">
                          {u.uid.slice(0, 14)}...
                        </td>
                        <td className="py-3 px-2">
                          <span className={cn(
                            "px-2 py-0.5 rounded-md text-[10px] font-bold",
                            u.hasSchedule 
                              ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300" 
                              : "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300"
                          )}>
                            {u.hasSchedule ? 'Configurado' : 'Sin horario'}
                          </span>
                        </td>
                        <td className="py-3 px-2 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => assignTemplateSchedule('eso', u.uid, u.email)}
                              className="px-2 py-1 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-300 rounded-lg text-[11px] font-bold"
                            >
                              + ESO
                            </button>
                            <button
                              type="button"
                              onClick={() => assignTemplateSchedule('bach', u.uid, u.email)}
                              className="px-2 py-1 bg-purple-50 dark:bg-purple-950/60 hover:bg-purple-100 text-purple-700 dark:text-purple-300 rounded-lg text-[11px] font-bold"
                            >
                              + Bach
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 4: CALENDARIO ESCOLAR Y FESTIVOS (NUEVA FUNCIÓN ADMIN) */}
      {activeSubTab === 'calendar' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="bg-white dark:bg-slate-900 p-6 md:p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm col-span-1 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-amber-50 dark:bg-amber-950/40 text-amber-600 rounded-2xl">
                <CalendarDays className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white font-display">Añadir Evento</h3>
                <p className="text-xs text-slate-400">Aparecerá en la agenda de todos los alumnos.</p>
              </div>
            </div>

            <form onSubmit={handleAddCalendarEvent} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
                  Título del Evento *
                </label>
                <input
                  type="text"
                  required
                  value={newCalTitle}
                  onChange={(e) => setNewCalTitle(e.target.value)}
                  placeholder="Ej. Fiesta de San Fernando (Festivo local)"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl px-3 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
                  Fecha *
                </label>
                <input
                  type="date"
                  required
                  value={newCalDate}
                  onChange={(e) => setNewCalDate(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl px-3 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
                  Tipo
                </label>
                <select
                  value={newCalType}
                  onChange={(e) => setNewCalType(e.target.value as any)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl px-3 py-2.5 text-xs"
                >
                  <option value="festivo">🎉 Festivo / No lectivo</option>
                  <option value="evaluacion">📝 Exámenes / Evaluación</option>
                  <option value="evento">🏫 Evento Escolar</option>
                  <option value="vacaciones">🏖️ Vacaciones</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
                  Descripción (Opcional)
                </label>
                <input
                  type="text"
                  value={newCalDesc}
                  onChange={(e) => setNewCalDesc(e.target.value)}
                  placeholder="Instrucciones para el alumnado..."
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl px-3 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <button
                type="submit"
                disabled={savingCalendarEvent}
                className="w-full py-3 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>{savingCalendarEvent ? 'Añadiendo...' : 'Añadir al Calendario'}</span>
              </button>
            </form>
          </div>

          <div className="bg-white dark:bg-slate-900 p-6 md:p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm col-span-1 lg:col-span-2 space-y-4">
            <h3 className="font-bold text-lg text-slate-900 dark:text-white">
              Fechas Oficiales del Centro ({calendarEvents.length})
            </h3>
            {calendarEvents.length === 0 ? (
              <p className="text-xs text-slate-400 py-8 text-center">
                No hay festivos ni eventos globales configurados.
              </p>
            ) : (
              <div className="space-y-2.5">
                {calendarEvents.map((evt) => (
                  <div
                    key={evt.id}
                    className="p-3.5 rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 flex items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black text-slate-900 dark:text-white">
                          {evt.title}
                        </span>
                        <span className="px-2 py-0.2 bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 rounded text-[9px] font-bold uppercase">
                          {evt.type}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        📅 {evt.date} {evt.description ? `• ${evt.description}` : ''}
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleDeleteCalendarEvent(evt.id)}
                      className="text-slate-400 hover:text-rose-600 p-1.5 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                      title="Eliminar evento"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 5: MENÚ MASIVO */}
      {activeSubTab === 'menu' && (
        <div className="bg-white dark:bg-slate-900 p-6 md:p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-6 max-w-3xl">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-orange-50 dark:bg-orange-950/40 text-orange-600 rounded-2xl">
              <Utensils className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white font-display">Subida Masiva del Menú</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Se sincronizará automáticamente para todas las cuentas del colegio.
              </p>
            </div>
          </div>

          {menuSuccess && (
            <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-bold rounded-2xl flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>{menuSuccess}</span>
            </div>
          )}

          {menuError && (
            <div className="p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-200 text-xs font-bold rounded-2xl flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-500" />
              <span>{menuError}</span>
            </div>
          )}

          <div className="p-10 border-2 border-dashed border-orange-200 dark:border-orange-900/50 bg-orange-50/20 dark:bg-orange-950/10 rounded-3xl flex flex-col items-center justify-center text-center">
            {isProcessingMenu ? (
              <div className="flex flex-col items-center gap-3">
                <Loader2 className="w-10 h-10 text-orange-500 animate-spin" />
                <p className="text-sm font-bold text-slate-700 dark:text-slate-200">Procesando y publicando menú masivo...</p>
                <p className="text-xs text-slate-400">Extrayendo los platos de cada día con IA.</p>
              </div>
            ) : (
              <label className="cursor-pointer group flex flex-col items-center gap-3">
                <div className="w-14 h-14 rounded-2xl bg-orange-50 dark:bg-orange-900/40 text-orange-600 flex items-center justify-center group-hover:scale-110 transition-transform shadow-sm">
                  <Upload className="w-7 h-7" />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-800 dark:text-slate-200">Selecciona el PDF mensual del comedor</p>
                  <p className="text-xs text-slate-400 mt-1">Se publicará de forma instantánea a todos los alumnos.</p>
                </div>
                <span className="px-5 py-2.5 bg-orange-600 text-white rounded-xl text-xs font-bold group-hover:bg-orange-700 shadow-md transition-all">
                  Subir Menú Masivamente
                </span>
                <input
                  type="file"
                  accept="application/pdf"
                  className="hidden"
                  onChange={handleGlobalMenuUpload}
                />
              </label>
            )}
          </div>

          {globalMenuData && (
            <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Menú Global Activo</span>
                <p className="font-bold text-slate-800 dark:text-slate-200 text-sm">{globalMenuData.month} {globalMenuData.year}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">{globalMenuData.items?.length || 0} días cargados</p>
              </div>
              <span className="px-3 py-1 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-xs font-bold rounded-xl">
                Sincronizado a Todos
              </span>
            </div>
          )}
        </div>
      )}

      {/* SUBTAB 6: CHAT Y SOPORTE */}
      {activeSubTab === 'chat' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Lista de Alumnos con chats */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm col-span-1 h-[650px] flex flex-col">
            <h2 className="font-bold text-lg text-slate-800 dark:text-white mb-4">
              Conversaciones ({usersWithChats.length})
            </h2>
            <div className="overflow-y-auto flex-1 space-y-2 pr-2">
              {usersWithChats.length === 0 ? (
                <p className="text-sm text-slate-400">No hay chats activos todavía.</p>
              ) : (
                usersWithChats.map(u => (
                  <button
                    key={u.uid}
                    onClick={() => setSelectedUserId(u.uid as string)}
                    className={cn(
                      "w-full text-left p-4 rounded-2xl border transition-all",
                      selectedUserId === u.uid 
                        ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-950/50 shadow-sm" 
                        : "border-slate-100 dark:border-slate-800 hover:border-indigo-200 bg-white dark:bg-slate-900"
                    )}
                  >
                    <div className="flex items-center gap-1.5 mb-1">
                      <Mail className="w-3.5 h-3.5 text-indigo-600 flex-shrink-0" />
                      <p className="font-bold text-xs text-slate-900 dark:text-white truncate">
                        {u.email}
                      </p>
                    </div>
                    <p className="text-[10px] text-slate-400 font-mono truncate ml-5">
                      UID: {String(u.uid).slice(0, 12)}...
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-1 ml-5">
                      {u.lastMsg?.isAdminReply ? 'Tú: ' : ''}{u.lastMsg?.text}
                    </p>
                  </button>
                ))
              )}
            </div>
          </div>

          {/* Chat Activo & Respuestas Rápidas */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm col-span-1 lg:col-span-2 h-[650px] flex flex-col">
            {!selectedUserId ? (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-400">
                <User className="w-16 h-16 mb-4 text-slate-200 dark:text-slate-700" />
                <p className="font-bold text-sm text-slate-600 dark:text-slate-300">Ninguna conversación seleccionada</p>
                <p className="text-xs text-slate-400 mt-1">Selecciona un alumno para ver su historial y responder.</p>
              </div>
            ) : (
              <>
                <div className="mb-3 pb-3 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider">Conversación con alumno</span>
                    <h3 className="font-black text-slate-900 dark:text-white text-base flex items-center gap-2 mt-0.5">
                      <Mail className="w-4 h-4 text-indigo-600" />
                      <span>{getUserEmail(selectedUserId, usersWithChats.find(u => u.uid === selectedUserId)?.email)}</span>
                    </h3>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleClearConversation}
                      className="text-xs font-bold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 px-3 py-2 rounded-xl transition-colors flex items-center gap-1"
                      title="Limpiar todos los mensajes de este alumno"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Vaciar chat</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const email = getUserEmail(selectedUserId, usersWithChats.find(u => u.uid === selectedUserId)?.email);
                        setTargetStudentUid(selectedUserId);
                        setTargetStudentEmail(email);
                        setActiveSubTab('schedules');
                      }}
                      className="text-xs font-bold text-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 px-3.5 py-2 rounded-xl hover:bg-indigo-100 transition-colors flex items-center gap-1.5"
                    >
                      <Calendar className="w-3.5 h-3.5" />
                      <span>Asignar Horario</span>
                    </button>
                  </div>
                </div>

                {/* Respuestas rápidas */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-2 scrollbar-hide text-[11px] font-bold">
                  <span className="text-[10px] text-slate-400 uppercase mr-1">Rápidas:</span>
                  {[
                    "👋 ¡Hola! Ya hemos revisado tu consulta.",
                    "📅 Ya tienes tu horario de clases cargado.",
                    "🍽️ El menú escolar ya está activo para este mes.",
                    "👍 ¡Gracias por avisarnos! Saludos."
                  ].map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => sendReply(preset)}
                      className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 text-slate-600 dark:text-slate-300 hover:text-indigo-600 rounded-lg transition-colors whitespace-nowrap flex-shrink-0"
                    >
                      {preset}
                    </button>
                  ))}
                </div>

                <div className="flex-1 overflow-y-auto space-y-3 pr-2 mb-3">
                  {selectedUserMessages.map(msg => {
                    const isSoporte = msg.isAdminReply;
                    return (
                      <div key={msg.id} className={cn("flex flex-col group", isSoporte ? "items-end" : "items-start")}>
                        <div className={cn("max-w-[80%] p-3 rounded-2xl relative", isSoporte ? "bg-indigo-600 text-white rounded-br-none" : "bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-bl-none")}>
                          <p className="text-sm leading-relaxed">{msg.text}</p>
                          <button 
                            type="button" 
                            onClick={() => deleteMsg(msg.id)} 
                            className="absolute -top-2 -right-2 p-1 text-red-500 bg-white dark:bg-slate-900 rounded-full shadow-sm opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <Trash className="w-3 h-3" />
                          </button>
                        </div>
                        <span className="text-[10px] text-slate-400 mt-1 mx-1 font-medium">
                          {isSoporte ? "🛡️ Desarrollo Hub" : `📧 Alumno`}
                        </span>
                      </div>
                    );
                  })}
                </div>

                <form onSubmit={(e) => { e.preventDefault(); sendReply(); }} className="flex gap-2">
                  <input
                    type="text"
                    value={replyText}
                    onChange={e => setReplyText(e.target.value)}
                    placeholder="Escribir respuesta al alumno..."
                    className="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-sm"
                  />
                  <button type="submit" className="bg-indigo-600 text-white px-5 py-3 rounded-xl hover:bg-indigo-700 transition-colors flex items-center justify-center">
                    <Send className="w-5 h-5" />
                  </button>
                </form>
              </>
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 7: COPIA DE SEGURIDAD (NUEVA FUNCIÓN ADMIN) */}
      {activeSubTab === 'backup' && (
        <div className="bg-white dark:bg-slate-900 p-6 md:p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm max-w-2xl space-y-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 rounded-2xl">
              <Download className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white font-display">
                Copia de Seguridad Institucional
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Descarga un respaldo íntegro en formato JSON con toda la información de alumnos, avisos y menús.
              </p>
            </div>
          </div>

          <div className="p-5 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2 text-xs text-slate-600 dark:text-slate-300">
            <p className="font-bold text-slate-800 dark:text-white">Elementos incluidos en el respaldo:</p>
            <ul className="list-disc list-inside space-y-1 text-slate-500 dark:text-slate-400">
              <li>Directorio de {allKnownUsers.length} cuentas y correos de alumnos</li>
              <li>Historial de {allAnnouncements.length} comunicados escolares</li>
              <li>Eventos del calendario escolar oficial</li>
              <li>Menú de comedor activo</li>
            </ul>
          </div>

          <button
            type="button"
            onClick={handleDownloadBackup}
            className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>Descargar Archivo JSON de Seguridad</span>
          </button>
        </div>
      )}
    </div>
  );
}
