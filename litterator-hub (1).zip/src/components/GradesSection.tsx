import React, { useState } from 'react';
import { Plus, Trash2, Calculator, TrendingUp } from 'lucide-react';
import type { AppState, Grade } from '../types';
import { cn } from '../lib/utils';

interface GradesSectionProps {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
}

export default function GradesSection({ state, setState }: GradesSectionProps) {
  const [newGrade, setNewGrade] = useState({ subject: '', score: '', weight: '100' });

  const addGrade = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGrade.subject || !newGrade.score) return;

    const grade: Grade = {
      id: crypto.randomUUID(),
      subject: newGrade.subject,
      score: parseFloat(newGrade.score),
      weight: parseFloat(newGrade.weight)
    };

    setState(prev => ({
      ...prev,
      grades: [...prev.grades, grade]
    }));
    setNewGrade({ subject: '', score: '', weight: '100' });
  };

  const removeGrade = (id: string) => {
    setState(prev => ({
      ...prev,
      grades: prev.grades.filter(g => g.id !== id)
    }));
  };

  const average = state.grades.length > 0 
    ? (state.grades.reduce((acc, g) => acc + (g.score * (g.weight / 100)), 0) / (state.grades.reduce((acc, g) => acc + (g.weight / 100), 0))).toFixed(2)
    : '0.00';

  return (
    <div className="space-y-8 pb-20">
      <header className="flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Calculadora de Notas</h1>
          <p className="text-slate-500 mt-1">Lleva un control de tu rendimiento académico.</p>
        </div>
        <div className="bg-indigo-600 text-white px-6 py-4 rounded-[24px] shadow-lg shadow-indigo-100 flex items-center gap-3">
          <Calculator className="w-6 h-6" />
          <div className="flex flex-col">
            <span className="text-[10px] font-bold uppercase tracking-wider opacity-70 leading-none">Media Actual</span>
            <span className="text-2xl font-black">{average}</span>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Form Column */}
        <div className="lg:col-span-1">
          <form onSubmit={addGrade} className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm space-y-4 sticky top-8">
            <h2 className="font-bold text-slate-800 mb-2">Añadir Nueva Nota</h2>
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest block mb-1">Asignatura</label>
                <input
                  type="text"
                  placeholder="Ej: Matemáticas"
                  className="w-full px-4 py-3 rounded-xl bg-slate-50 border-none text-sm focus:ring-2 focus:ring-indigo-500"
                  value={newGrade.subject}
                  onChange={e => setNewGrade({...newGrade, subject: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest block mb-1">Nota (0-10)</label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    max="10"
                    placeholder="8.5"
                    className="w-full px-4 py-3 rounded-xl bg-slate-50 border-none text-sm focus:ring-2 focus:ring-indigo-500"
                    value={newGrade.score}
                    onChange={e => setNewGrade({...newGrade, score: e.target.value})}
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest block mb-1">Peso (%)</label>
                  <input
                    type="number"
                    placeholder="100"
                    className="w-full px-4 py-3 rounded-xl bg-slate-50 border-none text-sm focus:ring-2 focus:ring-indigo-500"
                    value={newGrade.weight}
                    onChange={e => setNewGrade({...newGrade, weight: e.target.value})}
                  />
                </div>
              </div>
              <button 
                type="submit"
                className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-slate-800 transition-all active:scale-95"
              >
                <Plus className="w-5 h-5" />
                Añadir Nota
              </button>
            </div>
          </form>
        </div>

        {/* List Column */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-[32px] border border-slate-100 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-50 bg-slate-50/50">
              <h2 className="font-bold text-slate-800">Historial de Calificaciones</h2>
            </div>
            
            <div className="divide-y divide-slate-50">
              {state.grades.length > 0 ? (
                state.grades.map((grade) => (
                  <div key={grade.id} className="p-6 flex items-center justify-between group hover:bg-slate-50 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className={cn(
                        "w-12 h-12 rounded-2xl flex items-center justify-center font-black text-lg",
                        grade.score >= 5 ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600"
                      )}>
                        {grade.score}
                      </div>
                      <div>
                        <h3 className="font-bold text-slate-800">{grade.subject}</h3>
                        <p className="text-xs text-slate-400 font-medium">Peso: {grade.weight}%</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => removeGrade(grade.id)}
                      className="p-2 text-slate-300 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-all"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                ))
              ) : (
                <div className="py-20 flex flex-col items-center text-center">
                  <TrendingUp className="w-12 h-12 text-slate-200 mb-3" />
                  <p className="text-slate-500 font-bold">No hay notas registradas</p>
                  <p className="text-xs text-slate-400 mt-1">Empieza a añadir tus resultados para ver tu media.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
