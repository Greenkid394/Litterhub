import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  projectId: "litterator-hub",
  appId: "1:1009883519822:web:6a1ec3558dce1b19b09c1f",
  apiKey: "AIzaSyDcWjqGpi2xqRbCBmtes1NdmEdDWhpOL8s",
  authDomain: "litterator-hub.firebaseapp.com",
  firestoreDatabaseId: "ai-studio-litteratorhub-6cbf890f-c027-4fef-92f3-8c3698f2e168",
  storageBucket: "litterator-hub.firebasestorage.app",
  messagingSenderId: "1009883519822",
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
