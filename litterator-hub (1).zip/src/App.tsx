import React, { useState, useEffect, useMemo } from 'react';
import { 
  Calendar, 
  Clock, 
  Utensils, 
  BookOpen, 
  Settings as SettingsIcon, 
  LayoutDashboard,
  Timer as TimerIcon,
  CalendarDays,
  CloudSun,
  PenTool,
  Calculator as CalculatorIcon,
  ShieldCheck,
  Megaphone,
  Moon,
  Sun,
  Loader2 as SyncLoader
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';
import type { AppState, SchoolAnnouncement } from './types';

// Components
import Dashboard from './components/Dashboard';
import AnnouncementsSection from './components/AnnouncementsSection';
import AgendaCalendarSection from './components/AgendaCalendarSection';
import MenuSection from './components/MenuSection';
import ScheduleSection from './components/ScheduleSection';
import AssignmentsSection from './components/AssignmentsSection';
import WeatherSection from './components/WeatherSection';
import StudySection from './components/StudySection';
import SettingsSection from './components/SettingsSection';
import GradesSection from './components/GradesSection';
import DrawingSection from './components/DrawingSection';
import CalculatorSection from './components/CalculatorSection';
import AdminHub from './components/AdminHub';

import { useAuth } from './hooks/useAuth';
import Auth from './components/Auth';
import { db } from './lib/firebase';
import { doc, getDoc, setDoc, onSnapshot, serverTimestamp } from 'firebase/firestore';

export default function App() {
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState<
    'dashboard' | 'announcements' | 'agenda' | 'schedule' | 'menu' | 'weather' | 'drawing' | 'study' | 'grades' | 'calculator' | 'settings' | 'admin_hub'
  >('dashboard');
  const [isSyncing, setIsSyncing] = useState(false);
  const [activeAnnouncement, setActiveAnnouncement] = useState<SchoolAnnouncement | null>(null);
  
  const [state, setState] = useState<AppState>(() => {
    const saved = localStorage.getItem('litterator-hub-state');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return {
          menu: parsed.menu || null,
          schedule: parsed.schedule || null,
          assignments: parsed.assignments || [],
          grades: parsed.grades || [],
          agendaEvents: parsed.agendaEvents || [],
          dismissedAnnouncementIds: parsed.dismissedAnnouncementIds || [],
          theme: parsed.theme || { darkMode: false, backgroundColor: '#f8fafc' }
        };
      } catch (e) {}
    }
    return {
      menu: null,
      schedule: null,
      assignments: [],
      grades: [],
      agendaEvents: [],
      dismissedAnnouncementIds: [],
      theme: { darkMode: false, backgroundColor: '#f8fafc' }
    };
  });

  const isDark = Boolean(state.theme?.darkMode);

  // Sync html.dark class with state theme
  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDark);
  }, [isDark]);

  // Sync with Firestore when logged in
  useEffect(() => {
    if (!user) return;

    setIsSyncing(true);

    // Register user in user_directory for admin management
    setDoc(doc(db, 'user_directory', user.uid), {
      uid: user.uid,
      email: user.email,
      displayName: user.displayName || user.email?.split('@')[0],
      hasSchedule: Boolean(state.schedule?.days?.length),
      lastActive: serverTimestamp()
    }, { merge: true }).catch(() => {});
    
    // Load initial data from Firestore
    const loadData = async () => {
      try {
        const docRef = doc(db, 'users', user.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const cloudData = docSnap.data() as AppState;
          if (JSON.stringify(cloudData) !== JSON.stringify(state)) {
            setState(prev => ({
              ...prev,
              ...cloudData,
              theme: {
                ...(prev.theme || {}),
                ...(cloudData.theme || {})
              }
            }));
          }
        }
      } catch (err) {
        console.error('Error loading from Firestore:', err);
      } finally {
        setIsSyncing(false);
      }
    };

    loadData();

    // Real-time listener for user personal data (including schedule assigned by admin!)
    const unsubscribeUser = onSnapshot(doc(db, 'users', user.uid), (docSnap) => {
      if (docSnap.exists() && !docSnap.metadata.hasPendingWrites) {
        const cloudData = docSnap.data() as AppState;
        if (JSON.stringify(cloudData) !== JSON.stringify(state)) {
          setState(prev => ({ ...prev, ...cloudData }));
        }
      }
    });

    // Real-time listener for global shared menu
    const unsubscribeGlobalMenu = onSnapshot(doc(db, 'shared_resources', 'menu'), (docSnap) => {
      if (docSnap.exists()) {
        const globalMenu = docSnap.data();
        setState(prev => {
          if (JSON.stringify(prev.menu) !== JSON.stringify(globalMenu)) {
            return { ...prev, menu: globalMenu as any };
          }
          return prev;
        });
      }
    });

    // Real-time listener for active announcement
    const unsubscribeAnnouncement = onSnapshot(doc(db, 'shared_resources', 'announcement'), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data() as SchoolAnnouncement;
        if (data.active) {
          setActiveAnnouncement(data);
        } else {
          setActiveAnnouncement(null);
        }
      } else {
        setActiveAnnouncement(null);
      }
    });

    return () => {
      unsubscribeUser();
      unsubscribeGlobalMenu();
      unsubscribeAnnouncement();
    };
  }, [user?.uid]);

  // Persist to LocalStorage AND Firestore
  useEffect(() => {
    localStorage.setItem('litterator-hub-state', JSON.stringify(state));

    if (user) {
      const timer = setTimeout(async () => {
        try {
          await setDoc(doc(db, 'users', user.uid), { ...state, email: user.email }, { merge: true });
        } catch (err) {
          console.error('Error saving to Firestore:', err);
        }
      }, 1200); // Debounce
      return () => clearTimeout(timer);
    }
  }, [state, user?.uid]);

  // Check if active announcement is unread/undismissed
  const hasUnreadAnnouncement = useMemo(() => {
    if (!activeAnnouncement || !activeAnnouncement.active) return false;
    const key = activeAnnouncement.id || `${activeAnnouncement.title}_${activeAnnouncement.date}`;
    try {
      const stored = localStorage.getItem('litterator_dismissed_announcements');
      const localList: string[] = stored ? JSON.parse(stored) : [];
      const stateList = state.dismissedAnnouncementIds || [];
      return !localList.includes(key) && !stateList.includes(key);
    } catch {
      return true;
    }
  }, [activeAnnouncement, state.dismissedAnnouncementIds]);

  const toggleDarkMode = () => {
    setState(prev => {
      const nextDark = !prev.theme?.darkMode;
      return {
        ...prev,
        theme: {
          ...(prev.theme || {}),
          darkMode: nextDark,
          backgroundColor: nextDark ? '#0b0f19' : '#f8fafc'
        }
      };
    });
  };

  const adminEmails = [
    'desarrolohub@colegiolitterator.com', 
    'desarrollohub@colegiolitterator.com',
    'lcdfernando2017@gmail.com'
  ];
  const isAdmin = user?.email && adminEmails.includes(user.email.toLowerCase());

  const baseTabs = [
    { id: 'dashboard', label: 'Inicio', icon: LayoutDashboard },
    { id: 'announcements', label: 'Avisos', icon: Megaphone },
    { id: 'agenda', label: 'Agenda', icon: CalendarDays },
    { id: 'schedule', label: 'Horario', icon: Calendar },
    { id: 'menu', label: 'Comedor', icon: Utensils },
    { id: 'weather', label: 'El Tiempo', icon: CloudSun },
    { id: 'drawing', label: 'Pizarra', icon: PenTool },
    { id: 'study', label: 'Estudio', icon: TimerIcon },
    { id: 'grades', label: 'Notas', icon: BookOpen }, 
    { id: 'calculator', label: 'Calculadora', icon: CalculatorIcon },
    { id: 'settings', label: 'Ajustes', icon: SettingsIcon },
  ] as const;

  const tabs = isAdmin 
    ? [...baseTabs, { id: 'admin_hub', label: 'Admin Hub', icon: ShieldCheck } as const] 
    : baseTabs;

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user) {
    return <Auth />;
  }

  const customBg = state.theme?.backgroundImageUrl;
  const overlayOpacity = (state.theme?.bgOpacity ?? (isDark ? 40 : 25)) / 100;
  const overlayBlur = state.theme?.bgBlur ?? 0;

  const appStyle: React.CSSProperties = {
    backgroundColor: isDark ? (state.theme?.backgroundColor || '#0b0f19') : (state.theme?.backgroundColor || '#f8fafc'),
    backgroundImage: customBg ? `url(${customBg})` : 'none',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundAttachment: 'fixed',
  };

  return (
    <div className="min-h-screen text-slate-900 dark:text-slate-100 font-sans flex flex-col md:flex-row transition-colors relative" style={appStyle}>
      {/* Background Mask Overlay for legibility if custom background is used */}
      {customBg && (
        <div 
          className="fixed inset-0 pointer-events-none transition-all"
          style={{
            backgroundColor: isDark ? `rgba(11, 15, 25, ${overlayOpacity})` : `rgba(248, 250, 252, ${overlayOpacity})`,
            backdropFilter: overlayBlur > 0 ? `blur(${overlayBlur}px)` : 'none'
          }}
        />
      )}

      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex flex-col w-72 bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl border-r border-slate-200 dark:border-slate-800 p-6 shadow-xl h-screen sticky top-0 z-30 transition-colors">
        <div className="flex items-center justify-between gap-3 mb-8 px-2">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 overflow-hidden rounded-2xl flex items-center justify-center shadow-md border border-slate-100 dark:border-slate-800 bg-white">
              <img 
                src="https://colegiolitterator.com/wp-content/uploads/2023/12/ColegioLitterator.svg" 
                alt="Litterator" 
                className="w-full h-full object-cover" 
              />
            </div>
            <div>
              <h1 className="font-black text-xl tracking-tight font-display text-slate-900 dark:text-white leading-none">Litterator</h1>
              <div className="flex items-center gap-1.5 mt-1">
                <p className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">Hub Escolar</p>
                {isSyncing && <SyncLoader className="w-2.5 h-2.5 text-indigo-500 animate-spin" />}
              </div>
            </div>
          </div>

          {/* Quick Dark Mode toggle in sidebar */}
          <button
            type="button"
            onClick={toggleDarkMode}
            className="p-2 rounded-xl text-slate-400 hover:text-amber-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={isDark ? "Cambiar a modo claro" : "Cambiar a modo oscuro"}
          >
            {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>

        {/* Navigation links with comfortable scrolling */}
        <nav className="flex-1 space-y-1.5 overflow-y-auto pr-1 scrollbar-hide">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={cn(
                  "w-full flex items-center gap-3.5 px-4 py-3 rounded-2xl transition-all duration-200 font-bold text-xs group relative",
                  isSelected 
                    ? "bg-slate-900 dark:bg-indigo-600 text-white shadow-lg shadow-slate-200 dark:shadow-none" 
                    : "text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white hover:bg-slate-100/70 dark:hover:bg-slate-800/70"
                )}
              >
                <Icon className={cn("w-4 h-4 transition-colors", isSelected ? "text-indigo-400 dark:text-white" : "text-slate-400 group-hover:text-slate-700 dark:group-hover:text-slate-200")} />
                <span className="truncate">{tab.label}</span>
                {tab.id === 'announcements' && hasUnreadAnnouncement && (
                  <span className="ml-auto w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                )}
                {tab.id === 'admin_hub' && (
                  <span className="ml-auto w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Bottom Card */}
        <div className="mt-auto pt-4 border-t border-slate-100 dark:border-slate-800">
          <div className="p-4 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-2xl border border-indigo-100/50 dark:border-indigo-900/40">
            <p className="text-[11px] font-bold text-indigo-950 dark:text-indigo-200 mb-1">Colegio Litterator</p>
            <p className="text-[10px] text-indigo-700/80 dark:text-indigo-400 leading-relaxed font-medium">
              Aranjuez • Horario, Comedor y Agenda 2024-2025
            </p>
          </div>
        </div>
      </aside>

      {/* Mobile Top Header */}
      <header className="md:hidden flex items-center justify-between p-4 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border-b border-slate-200 dark:border-slate-800 sticky top-0 z-50 shadow-sm">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 overflow-hidden rounded-xl flex items-center justify-center shadow-sm">
            <img 
              src="https://colegiolitterator.com/wp-content/uploads/2023/12/ColegioLitterator.svg" 
              alt="Litterator" 
              className="w-full h-full object-cover" 
            />
          </div>
          <div>
            <h1 className="font-black text-base tracking-tight font-display text-slate-900 dark:text-white">Litterator Hub</h1>
            <p className="text-[8px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">Aranjuez</p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button 
            type="button"
            onClick={toggleDarkMode}
            className="p-2 text-slate-500 dark:text-slate-400 hover:text-amber-500 rounded-xl"
            title="Modo Oscuro"
          >
            {isDark ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5" />}
          </button>
          <button 
            onClick={() => setActiveTab('settings')} 
            className="p-2 bg-slate-50 dark:bg-slate-800 rounded-xl text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700"
            title="Ajustes"
          >
            <SettingsIcon className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 p-4 sm:p-6 md:p-10 overflow-y-auto pb-28 md:pb-12 relative z-10">
        <div className="max-w-6xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
            >
              {activeTab === 'dashboard' && <Dashboard state={state} setState={setState} onNavigate={setActiveTab} />}
              {activeTab === 'announcements' && <AnnouncementsSection />}
              {activeTab === 'agenda' && <AgendaCalendarSection state={state} setState={setState} />}
              {activeTab === 'schedule' && <ScheduleSection state={state} />}
              {activeTab === 'menu' && <MenuSection state={state} />}
              {activeTab === 'weather' && <WeatherSection />}
              {activeTab === 'drawing' && <DrawingSection />}
              {activeTab === 'study' && <StudySection />}
              {activeTab === 'grades' && <GradesSection state={state} setState={setState} />}
              {activeTab === 'calculator' && <CalculatorSection />}
              {activeTab === 'settings' && <SettingsSection state={state} setState={setState} />}
              {activeTab === 'admin_hub' && <AdminHub />}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border-t border-slate-200 dark:border-slate-800 flex overflow-x-auto no-scrollbar p-2 pb-5 z-50 shadow-2xl">
        <div className="flex items-center justify-around min-w-full px-1 gap-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={cn(
                  "p-2.5 rounded-xl transition-all flex flex-col items-center justify-center flex-shrink-0 min-w-[52px]",
                  isSelected 
                    ? "bg-slate-900 dark:bg-indigo-600 text-white shadow-sm" 
                    : "text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
                )}
                title={tab.label}
              >
                <div className="relative">
                  <Icon className="w-5 h-5" />
                  {tab.id === 'announcements' && hasUnreadAnnouncement && (
                    <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-rose-500" />
                  )}
                </div>
                <span className="text-[8px] font-bold mt-0.5 truncate max-w-[50px]">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
