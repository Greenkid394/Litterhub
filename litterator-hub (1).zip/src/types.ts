export interface MenuItem {
  day: number;
  date: string;
  firstCourse: string;
  secondCourse: string;
  dessert: string;
  observations?: string;
}

export interface MenuMonth {
  month: string;
  year: number;
  items: MenuItem[];
}

export interface ScheduleClass {
  startTime: string;
  endTime: string;
  subject: string;
  room?: string;
}

export interface DaySchedule {
  dayOfWeek: number; // 0-6
  classes: ScheduleClass[];
}

export interface WeeklySchedule {
  days: DaySchedule[];
}

export interface Assignment {
  id: string;
  title: string;
  dueDate: string;
  type: 'trabajo' | 'examen';
  description?: string;
  completed: boolean;
}

export interface Grade {
  id: string;
  subject: string;
  score: number;
  weight: number; // 0-100
}

export interface AgendaEvent {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  time?: string; // HH:mm optional
  type: 'tarea' | 'examen' | 'trabajo' | 'actividad' | 'recordatorio';
  subject?: string;
  description?: string;
  completed: boolean;
  priority?: 'baja' | 'media' | 'alta';
}

export interface SchoolAnnouncement {
  id?: string;
  title: string;
  message: string;
  date: string;
  priority: 'info' | 'important' | 'alert';
  active: boolean;
  author?: string;
  createdAt?: any;
}

export interface SchoolCalendarEvent {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  type: 'festivo' | 'evaluacion' | 'evento' | 'vacaciones';
  description?: string;
}

export interface AppState {
  menu: MenuMonth | null;
  schedule: WeeklySchedule | null;
  assignments: Assignment[];
  grades: Grade[];
  agendaEvents?: AgendaEvent[];
  dismissedAnnouncementIds?: string[];
  theme?: {
    darkMode?: boolean;
    backgroundColor?: string;
    backgroundImageUrl?: string;
    bgOpacity?: number;
    bgBlur?: number;
  };
}
